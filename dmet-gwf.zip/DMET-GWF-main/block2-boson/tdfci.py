# RK4 Algorithm is needed

import numpy as np
from pyscf.fci import direct_ep
import direct_ep_cmplx

def evol(ket, tau, t, u, g, hpp, nsite, nelec, nphonon):
    # RK4 
    k1 = -1.0j * direct_ep_cmplx.contract_all(t, u, g, hpp, ket, 
    nsite, nelec, nphonon)
    k2 = -1.0j * direct_ep_cmplx.contract_all(t, u, g, hpp, ket+.5*tau*k1,
    nsite, nelec, nphonon)
    k3 = -1.0j * direct_ep_cmplx.contract_all(t, u, g, hpp, ket+.5*tau*k2,
    nsite, nelec, nphonon)
    k4 = -1.0j * direct_ep_cmplx.contract_all(t, u, g, hpp, ket+1.*tau*k3,
    nsite, nelec, nphonon)

    newket = ket + 1/6*tau*(k1 + 2.*k2 + 2.*k3 + k4)
    return newket

class HH_Model:

    def __init__(self, t, u, g, omega, nsite, ket=None):

        self.nsite = nsite
        self.nelec = nsite
        self.nphonon = nsite

        self.t = t
        self.u = u
        self.g = g
        self.hpp = np.eye(self.nphonon) * omega
        self.ket = ket
        self.energy = None

    def gs_kernel(self):
        e, ket = direct_ep.kernel(self.t, self.u, self.g, self.hpp, 
        self.nelec, self.nphonon)

        self.energy = e
        self.ket = ket

    def tdfci(self, delta_t, target_t):
        for i in range(int(target_t / delta_t)):
            self.ket = evol(self.ket, delta_t, self.t, self.u, self.g,
            self.hpp, self.nsite, self.nelec, self.nphonon)

    def get_energy(self):
        hc = direct_ep.contract_all(self.t, self.u, self.g, self.hpp,
        self.ket, self.nsite, self.nelec, self.nphonon)
        return np.dot(self.ket.conj().reshape(-1), hc.reshape(-1))

    def get_phonon_energy(self):
        hc = direct_ep_cmplx.contract_pp(self.hpp, self.ket, 
        self.nsite, self.nelec, self.nphonon)
        return np.dot(self.ket.conj().reshape(-1), hc.reshape(-1))

L = 4
t = np.zeros((L, L))
idx = np.arange(L-1)
t[idx+1,idx] = t[idx,idx+1] = -1
U = 0.
g = 0.
hpp = np.eye(L) * 1.
e, ket = direct_ep.kernel(t, U, g, hpp, L, L, L)
print(e)

t = np.zeros((L, L), dtype=np.complex128)
idx = np.arange(L-1)
t[idx+1,idx] = t[idx,idx+1] = -1+0j

hpp = np.eye(L, dtype=np.complex128) * 1+0j

model = HH_Model(t, 0+0j, 1+0j, hpp, L, ket=ket.astype(np.complex128))



for i in range(4000):
    phon_e = model.get_phonon_energy()
    print(phon_e.real)

    model.tdfci(delta_t = 5E-4, target_t = 5E-3)
