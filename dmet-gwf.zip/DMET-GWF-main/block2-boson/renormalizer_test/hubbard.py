# Hubbard Model

from renormalizer.utils import Quantity
from renormalizer import Model, Mpo, Mps, optimize_mps
from renormalizer.model.basis import BasisSimpleElectron, BasisSHO, Op
import numpy as np

L = 4
t = 1.
U = 2.

basis = []
ham = []

for imol in range(2 * L):
    basis.append(BasisSimpleElectron(imol))

# hopping_term
hop_term_index = np.array([[[i, i + 2], [i + 2, i]] for i in range(2 * (L - 1))]).reshape(-1,2)

# interaction_term
int_term_index = np.array([[2 * i, 2 * i, 2 * i + 1, 2 * i + 1] for i in range(L)]).reshape(-1,4)

for imol, jmol in hop_term_index:
    hop_term = Op(r"a^\dagger a", [imol, jmol], -t)
    ham.append(hop_term)

for imol, jmol, kmol, lmol in int_term_index:
    n_up = Op(r"a^\dagger a", [imol, jmol], U)
    n_dn = Op(r"a^\dagger a", [kmol, lmol], 1.)

    int_term = n_up * n_dn
    ham.append(int_term)

model = Model(basis, ham_terms=ham)
mpo = Mpo(model)

M = 400
procedure = [[M, 0.4], [M, 0.2], [M, 0.1], [M, 0], [M, 0], [M,0], [M,0]]
mps = Mps.random(model, L//2, M)

mps.optimize_config.procedure = procedure

energies, mps = optimize_mps(mps.copy(), mpo)
print(min(energies))
