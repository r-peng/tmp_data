from renormalizer.utils import Quantity
from renormalizer import Model, Mpo, Mps, optimize_mps
from renormalizer.model.basis import BasisSimpleElectron, BasisSHO, Op
import numpy as np

# Hubbard-Holstein Model
L = 2
t = 1.
U = 2.
omega = 5.0
lamb = 3.6
g = np.sqrt(lamb * omega / 2)
nphonon = [3] * L

basis = []

# Electron Basis
for imol in range(2 * L):
    basis.append(BasisSimpleElectron(imol))

# Phonon Basis
for isite, iph in enumerate(range(L)):
    basis.append(BasisSHO((iph, 0), omega, nphonon[isite]))

ham = []

# electron hopping term

hop_term_index = np.array([[[i, i + 2], [i + 2, i]] for i in range(2 * (L - 1))]).reshape(-1,2)
for imol, jmol in hop_term_index:
    hop_term = Op(r"a^\dagger a", [imol, jmol], -t)
    ham.append(hop_term)

# electron interaction term
int_term_index = np.array([[2 * i, 2 * i, 2 * i + 1, 2 * i + 1] for i in range(L)]).reshape(-1,4)
for imol, jmol, kmol, lmol in int_term_index:
    n_up = Op(r"a^\dagger a", [imol, jmol], U)
    n_dn = Op(r"a^\dagger a", [kmol, lmol], 1.)
    int_term = n_up * n_dn
    ham.append(int_term)

# phonon energy term \omega b_i^\dagger b_i

for isite, iph in enumerate(range(L)):
    cre = Op(r"b^\dagger", (iph, 0), omega)
    des = Op(r"b", (iph, 0), 1.)
    ham.append(cre * des)


# electron-phonon coupling term
for isite, (imol, jmol, kmol, lmol) in enumerate(int_term_index):
    iph = range(L)[isite]
    n_up = Op(r"a^\dagger a", [imol, jmol], 1.)
    n_dn = Op(r"a^\dagger a", [kmol, lmol], 1.)
    cre = Op(r"b^\dagger", (iph, 0), g)
    des = Op(r"b", (iph, 0), g)
    ham.append(n_up * cre)
    ham.append(n_dn * cre)
    ham.append(n_up * des)
    ham.append(n_dn * des)

model = Model(basis, ham_terms=ham)
print(model.nsite)
mpo = Mpo(model)

M = 800
procedure = [[M, 0.4], [M, 0.2], [M, 0.1], [M, 0], [M, 0], [M,0], [M,0]]
mps = Mps.random(model, L, M)   # 4 is the electron number
mps.optimize_config.procedure = procedure
energies, mps = optimize_mps(mps.copy(), mpo)
print(min(energies))