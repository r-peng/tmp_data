# An extension to spin Hubbard model

import numpy as np
from pyscf import gto, ao2mo, fci, lib
from pyscf.scf import hf, ghf
from pyscf.lib import logger
from itertools import product
from functools import reduce
from pyscf.fci import fci_slow
import scipy

def get_hcore_2dobc(lx, ly, t):
    
    hcore = np.zeros((lx,ly,lx,ly))

    for i in range(lx):
        for j in range(ly):
            if i+1 in range(lx): hcore[i,j,i+1,j] = -t
            if i-1 in range(lx): hcore[i,j,i-1,j] = -t
            if j+1 in range(ly): hcore[i,j,i,j+1] = -t
            if j-1 in range(ly): hcore[i,j,i,j-1] = -t

    hcore = hcore.reshape((lx*ly, lx*ly))

    return hcore

def get_hcore_2dpbc(lx, ly, t):

    hcore = np.zeros((lx, ly, lx, ly))

    for i in range(lx):
        for j in range(ly):
            hcore[i,j,(i+1)%lx,j] = -t
            hcore[i,j,(i-1)%lx,j] = -t
            hcore[i,j,i,(j+1)%ly] = -t
            hcore[i,j,i,(j-1)%ly] = -t

    hcore = hcore.reshape((lx*ly, lx*ly))

    return hcore

def get_hcore_1dobc(lx,t):

    hcore = np.zeros((lx,lx))
    for i in range(lx):
        if i+1 in range(lx): hcore[i,i+1] = -t
        if i-1 in range(lx): hcore[i,i-1] = -t

    return hcore

def get_hcore_1dpbc(lx,t):
    hcore = np.zeros((lx,lx))
    for i in range(lx):
        hcore[i,(i+1)%lx] = -t
        hcore[i,(i-1)%lx] = -t
        
    return hcore

def energy_tot(mf, dm=None, h1e=None, vhf=None):
    return hf.energy_elec(mf, dm, h1e, vhf)[0]


class HubbardMole(gto.Mole):

    def __init__(self, lx, ly, t, U):
        super(HubbardMole, self).__init__()

        self.t = t
        self.U = U
        self.lx = lx
        self.ly = ly

        self.nao = lx * ly

class RHF_SpinHubbard(hf.RHF):
    def __init__(self, mol:HubbardMole):
        super(RHF_SpinHubbard, self).__init__(mol)

        n = mol.lx * mol.ly

        self.pbc = False    # Whether periodic bound condition is used

        try:    
            eri = np.zeros((n,n,n,n))
            for i in range(n): eri[i,i,i,i] = mol.U
            self._eri = ao2mo.restore(8, eri, n)
        except: pass

    def get_hcore(self, mol=None):

        if mol is None: mol = self.mol

        if mol.lx == 1:
            if not self.pbc: return get_hcore_1dobc(mol.ly, mol.t)
            else: return get_hcore_1dpbc(mol.ly, mol.t) 
        elif mol.ly == 1:
            if not self.pbc: return get_hcore_1dobc(mol.lx, mol.t)
            else: return get_hcore_1dpbc(mol.lx, mol.t) 
        else:
            if not self.pbc: return get_hcore_2dobc(mol.lx, mol.ly, mol.t)
            else: return get_hcore_2dpbc(mol.lx, mol.ly, mol.t)

    def get_ovlp(self, mol=None):
        if mol is None: mol = self.mol
        return np.eye(mol.lx*mol.ly)

    def get_veff(self, mol=None, dm=None, dm_last=0, vhf_last=0, hermi=1):
        if mol is None: mol = self.mol
        if dm is None: dm = self.make_rdm1()
        if self._eri is not None or not self.direct_scf:
            vhf = np.diag(np.diag(dm)) * mol.U * .5
        else:
            ddm = np.asarray(dm) - np.asarray(dm_last)
            vhf = np.diag(np.diag(ddm)) * mol.U * .5
            vhf += np.asarray(vhf_last)

        return vhf

    energy_tot = energy_tot

class GHF_SpinHubbard(ghf.GHF):
    def __init__(self, mol:HubbardMole):
        super(GHF_SpinHubbard, self).__init__(mol)
        n = mol.lx * mol.ly

        self.pbc = False

        try:
            eri = np.zeros((2*n, 2*n, 2*n, 2*n))
            for i in range(n):
                eri[i, i, i+n, i+n] += mol.U
                eri[i+n, i+n, i, i] += mol.U
            self._eri = ao2mo.restore(8, eri, 2*n)
        except: pass

    def get_ovlp(self, mol=None):
        if mol is None: mol = self.mol
        return np.eye(2*mol.lx*mol.ly)

    def get_hcore(self, mol=None):
        if mol is None: mol = self.mol

        hcore = RHF_SpinHubbard.get_hcore(self, mol)
        return scipy.linalg.block_diag(hcore, hcore)

    def energy_tot(self):
        return self.energy_elec()

def _get_boson_number(iconf, nbcuts):
    # 
    numlst = []
    s = iconf
    for iph, nbcut in enumerate(nbcuts[::-1]):

        quot = s // nbcut
        res  = s % nbcut
        s = quot
        numlst.append(res)

    return np.array(numlst)[::-1]


def hop_ph(c, omegalst, nbcuts, boson_numbers=None):
    # \sum\limits_i \omega_i \hat b^\dagger_i \hat b_i
      
    if boson_numbers is None:
        boson_numbers = np.array([_get_boson_number(iconf, nbcuts) for iconf in range(np.prod(nbcuts))])
    coefs = np.einsum("i,ji->j", omegalst, boson_numbers)
    hc = coefs * c
    return hc

def hop_pp(c, omegalst, nbcuts, nelec, norb_fermion, boson_numbers=None):
    if boson_numbers is None:
        boson_numbers = np.array([_get_boson_number(iconf, nbcuts) for iconf in range(np.prod(nbcuts))])

    neleca, nelecb = nelec
    na = fci.cistring.num_strings(norb_fermion, neleca)
    nb = fci.cistring.num_strings(norb_fermion, nelecb)

    ci0 = c.reshape(na*nb, len(boson_numbers))
    hc = np.zeros_like(ci0)

    nof = na*nb
    
    for j in range(nof):
        hc[j,:] += hop_ph(ci0[j,:], omegalst, nbcuts, boson_numbers)

    return hc.reshape(-1)

def hop_eph(c, glst, norb_fermion, norb_boson, nelec, nbcuts, boson_numbers=None):
    neleca, nelecb = nelec
    na = fci.cistring.num_strings(norb_fermion, neleca)
    nb = fci.cistring.num_strings(norb_fermion, nelecb)

    if boson_numbers is None:
        boson_numbers = np.array([_get_boson_number(iconf, nbcuts) for iconf in range(np.prod(nbcuts))])

    cut_prod = np.cumprod(nbcuts[::-1])[::-1]
    cut_prod = np.array(list(cut_prod) + [1])   # [N1...Nn, N2...Nn, ..., Nn, 1] (n+1) array

    ci0 = c.reshape(na*nb, len(boson_numbers))  # reshape to fermi_config * boson_config
    hc = np.zeros_like(ci0)

    for iph, nph in enumerate(boson_numbers):

        for j in range(norb_boson): # idx of Boson sites
            gj = glst[:,:,j]
            c_temp = fci_slow.contract_1e(gj, ci0[:,iph].reshape((na,nb)), norb_fermion, nelec).ravel()

            number_ph = nph[j]

            idxb_shift_j = cut_prod[j + 1]
            if number_ph != nbcuts[j] - 1:
                cre_config = iph + idxb_shift_j # |... I_j ...> -> |... I_j+1 ...>
                hc[:,cre_config] += c_temp * np.sqrt(number_ph + 1)

            if number_ph != 0:
                des_config = iph - idxb_shift_j # |... I_j ...> -> |... I_j-1 ...>
                hc[:,des_config] += c_temp * np.sqrt(number_ph)

    return hc.reshape(-1)



def hop_epc(c, nelec, norb_fermion, norb_boson, nbcuts, omegalst, glst, h2e, 
link_index=None, boson_numbers=None):
    """
    h2e: contracted 2e-hamiltonian tensor

    """
    neleca, nelecb = nelec
    na = fci.cistring.num_strings(norb_fermion, neleca)
    nb = fci.cistring.num_strings(norb_fermion, nelecb)

    if boson_numbers is None:
        boson_numbers = np.array([_get_boson_number(iconf, nbcuts) for iconf in range(np.prod(nbcuts))])
    cut_prod = np.cumprod(nbcuts[::-1])[::-1]
    cut_prod = np.array(list(cut_prod) + [1])   # [N1...Nn, N2...Nn, ..., Nn, 1] (n+1) array

    ci0 = c.reshape(na*nb, len(boson_numbers))  # reshape to fermi_config * boson_config
    nof, nob = ci0.shape        # number of fermion and boson config
    hc = np.zeros_like(ci0)

    for i in range(nob):
        hc[:,i] += fci_slow.contract_2e(h2e, ci0[:,i].reshape((na, nb)), norb_fermion, nelec, link_index).ravel()

    hc = hc.reshape(-1)

    hc += hop_pp(c, omegalst, nbcuts, nelec, norb_fermion, boson_numbers)
    hc += hop_eph(c, glst, norb_fermion, norb_boson, nelec, nbcuts, boson_numbers)

    return hc.reshape(-1)

def make_hdiag(h1e, eri, norb_fermion, nelec, nbcuts, omegalst, boson_numbers=None):

    if boson_numbers is None:
        boson_numbers = np.array([_get_boson_number(iconf, nbcuts) for iconf in range(np.prod(nbcuts))])
    coefs_ph = np.einsum("i,ji->j", omegalst, boson_numbers)
    nob = np.prod(nbcuts)
    hdiag_elec = fci_slow.make_hdiag(h1e, eri, norb_fermion, nelec[0]+nelec[1])

    neleca, nelecb = nelec
    na = fci.cistring.num_strings(norb_fermion, neleca)
    nb = fci.cistring.num_strings(norb_fermion, nelecb)
    hdiag = np.zeros((na*nb, nob))   

    for i in range(nob):
        hdiag[:,i] += hdiag_elec
    for j in range(na*nb):
        hdiag[j,:] += coefs_ph

    return hdiag.reshape(-1)

class FCI_HubbardHolstein:

    def __init__(self, mf:RHF_SpinHubbard, omega, g, nbcuts):

        self._scf = mf
        h_ao = self._scf.get_hcore()
        mo_c = self._scf.mo_coeff
        
        self.norb_fermion = mo_c.shape[1]
        self.norb_boson = self.norb_fermion
        self.nbcuts = nbcuts
        self.omega = [omega] * self.norb_boson

        self.h1e = h_ao
        self.eri = self._scf._eri
        self.nelec = self._scf.mol.nelec
 
        self.boson_numbers = np.array([_get_boson_number(iconf, self.nbcuts) for iconf in range(np.prod(self.nbcuts))])
        neleca, nelecb = self.nelec
        na = fci.cistring.num_strings(self.norb_fermion, neleca)
        nb = fci.cistring.num_strings(self.norb_fermion, nelecb)
        nob = self.boson_numbers.shape[0]

        self.nconfig_fermion = na * nb
        self.nconfig_boson = nob

        self.g = np.zeros((self.norb_fermion, self.norb_fermion, self.norb_boson))
        for i in range(self.norb_fermion):
            self.g[i,i,i] += g

        self.eci = None
        self.ci = None

    def kernel(self):

        h2e = fci_slow.absorb_h1e(self.h1e, self.eri, self.norb_fermion, self.nelec, 0.5)

        linkidx_a = fci.cistring.gen_linkstr_index(range(self.norb_fermion), self.nelec[0])
        linkidx_b = fci.cistring.gen_linkstr_index(range(self.norb_fermion), self.nelec[1])
        linkidx = (linkidx_a, linkidx_b)

        def hop_here(c):
            return hop_epc(c, nelec=self.nelec, norb_fermion=self.norb_fermion, 
            norb_boson=self.norb_boson, nbcuts=self.nbcuts, 
            omegalst=self.omega, glst=self.g, h2e=h2e, 
            link_index=linkidx, boson_numbers=self.boson_numbers)


        hdiag = make_hdiag(h1e=self.h1e, eri=self.eri, norb_fermion=self.norb_fermion,
        nelec=self.nelec, nbcuts=self.nbcuts, 
        omegalst=self.omega, boson_numbers=self.boson_numbers)  
        print(hdiag.shape)
        
        """
        from pyscf.fci import direct_ep
        hdiag = direct_ep.make_hdiag(t=self._scf.get_hcore(), u=self._scf.mol.U, g=self.g[0,0,0],
        hpp = np.diag(np.array(self.omega)), nsite=self.norb_fermion, nelec=self.nelec[0]+self.nelec[1], nphonon=self.nbcuts[0]+1)
        print(hdiag.shape)
        """

        precond = lambda x, e, *args: x/(hdiag-e+1e-5)

        self.hop = hop_here
        self.precond = precond

        c0 = np.zeros(self.nconfig_fermion * self.nconfig_boson)
        c0[0] = 1.
        self.eci, self.ci = lib.davidson(hop_here, c0, precond)

        return self.eci, self.ci

if __name__ == "__main__":


    from pyscf.fci import fci_slow, direct_ep

    L = 2
    t = 1
    U = 2
    omega = 5.0
    lamb = 3.6
    nphonon = 2
    g = np.sqrt(lamb * omega / 2)

    mol = HubbardMole(L, 1, t, U)
    mol.nelectron = L
    mf = RHF_SpinHubbard(mol)
    mf.kernel()

    nbcuts = np.array([nphonon+1] * L)

    # test sanity of Hc

    na = fci.cistring.num_strings(L, L//2)
    nb = fci.cistring.num_strings(L, L//2)
    nof = na * nb
    nob = np.prod(nbcuts)

    rand_ci0 = np.random.random((nof * nob))
    print(rand_ci0.shape)
    myhc0_pp = hop_pp(rand_ci0, [omega] * L, nbcuts, (L//2, L//2),
    L, boson_numbers=None)

    hishc0_pp = direct_ep.contract_pp(np.eye(L)*omega, rand_ci0,
    L, L, nphonon)

    glst = np.zeros((L, L, L))
    for i in range(L): glst[i,i,i] += g

    myhc0_ep = hop_eph(rand_ci0, glst, L, L, (L//2, L//2), nbcuts)

    hishc0_ep = direct_ep.contract_ep(g, rand_ci0, L, L, nphonon)

    # electron-phonon coupling term
    assert(np.allclose(myhc0_ep, hishc0_ep))

    # phonon term
    assert(np.allclose(myhc0_pp, hishc0_pp))


    t = np.zeros((L, L))
    idx = np.arange(L-1)
    t[idx+1,idx] = t[idx,idx+1] = -1

    hishh = direct_ep.kernel(t, U, g, np.eye(L)*omega, L, L, nphonon)
    print(hishh[0])
    myhh = FCI_HubbardHolstein(mf, omega, g, nbcuts)
    print(myhh.kernel()[0])
