import sys
sys.path.append("..")

from eomdp import eomdp_slow
import cpskit
from pyscf import gto
from pyscf.scf import hf
from pyscf.dft import RKS
import numpy as np
from dmet.main.solver import DMET_FCI, DMET_SCF
from dmet.main.outer import DMET
import pyscf.tdscf.rks as tddft
from functools import reduce

def make_Hring(l=1.):
    r = l/(2 * np.sin(np.pi / 10))
    atmlst = []
    for i in range(10):
        atmlst.append(['H', (r*np.cos(2. * np.pi/10*i), r*np.sin(2. * np.pi/10*i), 0)])
    mol = gto.Mole()
    mol.atom = atmlst
    mol.basis = 'sto-6g'
    mol.build()
    return mol

def get_sd_ci(mo_coeff, mo_occ, nao, nocc):
    """
    mo_coeff: EO -> MO
    """
    civecs = []

    occidxs = sorted(np.where(mo_occ!=0.)[0])
    viridxs = sorted(np.where(mo_occ==0.)[0])

    mo_c_r = mo_coeff[:,occidxs]
    ci_hf_r = cpskit.fci.ci_slater(nao, (nocc,nocc), (mo_c_r, mo_c_r))

    civecs.append(ci_hf_r)

    for i in range(len(occidxs)):
        for j in range(len(viridxs)):
            # print("occidx = ", occidxs[i], ", viridx = ", viridxs[j])
            idx = occidxs.copy()
            viridx = viridxs[j]
            idx[i] = viridx
            idx = sorted(list(idx)) # sort the occupied index
            # print(idx)
            mo_c = mo_coeff[:,idx]

            ci_hf_alpha = cpskit.fci.ci_slater(nao, (nocc,nocc), (mo_c, mo_c_r))
            ci_hf_beta  = cpskit.fci.ci_slater(nao, (nocc,nocc), (mo_c_r, mo_c))

            civecs.append(ci_hf_alpha * (-1)**(nocc-1-i))
            civecs.append(ci_hf_beta * (-1)**(nocc-1-i))

    return civecs

def eomdp_kernel_cihf(dmet_obj, mode='ecv'):

    cam = dmet_obj._scf.mo_coeff
    mol = dmet_obj._scf.mol

    nao = mol.nao
    nocc = mol.nelec[0]
    nvir = nao - nocc
    h1e_ao = hf.get_hcore(mol)

    h = np.zeros((2*nocc*nvir+1, 2*nocc*nvir+1))
    s = np.zeros((2*nocc*nvir+1, 2*nocc*nvir+1))

    nx = sum(dmet_obj.sym_factor)   # number of impurity

    for sym_idx in range(len(dmet_obj.sym_factor)):

        sym_factor = dmet_obj.sym_factor[sym_idx]
        solver = dmet_obj.dmets[sym_idx]
        ci_dmet = solver.fci_coeff
        na = len(dmet_obj.fragments[sym_idx][0])
        cae = solver.get_ecv_coeff()
        cem = np.dot(np.linalg.inv(cae), cam)
        eri = solver.get_ecv_eri()
        wfnlst = get_sd_ci(cem, dmet_obj._scf.mo_occ, nao, nocc)
        ovlp_factor = sym_factor / nx
        h1e = np.einsum("mj,mn,nk->jk", cae.conj(), h1e_ao, cae)
        hx, sx = eomdp_slow.hs_1imp(wfnlst, na, nocc, nvir, nao, h1e, eri)
        h += hx * sym_factor
        s += sx * ovlp_factor

    assert np.allclose(s, np.eye(2*nocc*nvir+1))
    e, c = hf.eig(h, s)

    print(e + dmet_obj.energy_nuc)
    
    return e + dmet_obj.energy_nuc

frag2 = [[[0,1]], [[2,3]], [[4,5]], [[6,7]], [[8,9]]]
mol = make_Hring(1.0)
mf = RKS(mol, xc='b3lyp'); mf.kernel()
nao = mol.nao
nocc = mol.nelec[0]
na = 2
nvir = nao - nocc

tda = tddft.TDA(mf)
tda.singlet=False
tda.kernel()
print(tda.e)

dmet_ci = DMET(mf, frag2, DMET_SCF)
dmet_ci.kernel_1shot()
for i in range(5):
    dmet_ci.dmets[i].get_hf_cistr()

ci_dmet = dmet_ci.dmets[0].fci_coeff

cae = dmet_ci.dmets[0].get_ecv_coeff()
cem = np.dot(np.linalg.inv(cae), mf.mo_coeff)
h1e_ao = hf.get_hcore(mol)
h1e = np.einsum("mj,mn,nk->jk", cae.conj(), h1e_ao, cae)

eri = dmet_ci.dmets[0].get_ecv_eri()

wfnlst1 = get_sd_ci(cem, mf.mo_occ, nao, nocc)
wfnlst2 = eomdp_slow.gen_wfn_lst_1imp(cem, ci_dmet, nocc, nvir, na, nao)

h2, s2 = eomdp_slow.hs_1imp(wfnlst2, na, nocc, nvir, nao, h1e, eri)

print("s2 = ", s2)
h1, s1 = eomdp_slow.hs_1imp(wfnlst1, na, nocc, nvir, nao, h1e, eri)

print("s1 = ", s1)



np.savetxt("h1.txt", h1)
np.savetxt("h2.txt", h2)

e1, c1 = hf.eig(h1, s1)
print(e1)

e2, c2 = hf.eig(h2, s2)
print(e2)

assert np.allclose(h1, h2)


"""
eomdp_kernel_cihf(dmet_ci)
eomdp_slow.eomdp_kernel(dmet_ci)
"""