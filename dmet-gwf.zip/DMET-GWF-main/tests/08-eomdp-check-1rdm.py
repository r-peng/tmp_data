# Check the correctness of 1RDM

import sys
sys.path.append("..")

from eomdp import rdm34_addons, eomdp_fast, eomdp_slow
from pyscf.fci import cistring, direct_spin1
from pyscf import gto
import numpy as np
from pyscf.scf import hf
from dmet.main.solver import DMET_FCI
from dmet.main.outer import DMET

def make_Hring(l=1.):
    r = l/(2 * np.sin(np.pi / 10))
    atmlst = []
    for i in range(10):
        atmlst.append(['H', (r*np.cos(2. * np.pi/10*i), r*np.sin(2. * np.pi/10*i), 0)])
    mol = gto.Mole()
    mol.atom = atmlst
    mol.basis = 'sto-6g'
    mol.build()
    return mol

frag2 = [[[0,1]], [[2,3]], [[4,5]], [[6,7]], [[8,9]]]
mol = make_Hring(1.0)
mf = hf.RHF(mol); mf.kernel()
nao = mol.nao
nocc = mol.nelec[0]
na = 2
nvir = nao - nocc

dmet_ci = DMET(mf, frag2, DMET_FCI)
dmet_ci.kernel_1shot()

ci_dmet = dmet_ci.dmets[0].fci_coeff

rdm0 = np.einsum("ij,ij->", ci_dmet, ci_dmet)
rdm1, rdm2 = direct_spin1.make_rdm12s(ci_dmet, 2*na, (na,na), reorder=False)
rdm3 = rdm34_addons.make_rdm3s_spin1(ci_dmet, 2*na, (na,na))

dmpack = (rdm0, rdm1, rdm2, rdm3)

cae = dmet_ci.dmets[0].get_ecv_coeff()
cem = np.dot(np.linalg.inv(cae), mf.mo_coeff)
wfnlst = eomdp_slow.gen_wfn_lst_1imp(cem, ci_dmet, nocc, nvir, na, nao)

for j in range(nocc):
    for b in range(nvir):
        wfn_l_alpha = wfnlst[1+2*(j*nocc+b)]
        wfn_l_beta  = wfnlst[2+2*(j*nocc+b)]

        sl = np.einsum("p,q->pq", cem[:,b+nocc], cem[:,j].conj())

        for i in range(nocc):
            for a in range(nvir):
                wfn_r_alpha = wfnlst[1+2*(i*nocc+a)]
                wfn_r_beta  = wfnlst[2+2*(i*nocc+a)]

                sr = np.einsum("p,q->pq", cem[:,a+nocc], cem[:,i].conj())

                rdm_a_aa_a, rdm_a_bb_a = direct_spin1.trans_rdm1s(wfn_l_alpha, wfn_l_beta, nao, (nocc, nocc))
                rdm_a_aa_b, rdm_a_bb_b = direct_spin1.trans_rdm1s(wfn_l_alpha, wfn_l_beta, nao, (nocc, nocc))

                rdm_aa, rdm_ab, rdm_ba, rdm_bb = eomdp_fast.build_rdm1(sl, sr, dmpack, na, nocc, nao)
                print(rdm_a_aa_a[:2*na,])
                print(rdm_aa[0])
                assert np.allclose(rdm_a_aa_a[:2*na,], rdm_aa[0])
                assert np.allclose(rdm_a_bb_a[:2*na,], rdm_aa[1])
                assert np.allclose(rdm_a_aa_b[:2*na,], rdm_ab[0])
                assert np.allclose(rdm_a_bb_b[:2*na,], rdm_ab[1])
