import sys
sys.path.append("..")

from dmet.model import hubbard
from pyscf import fci
from pyscf.scf import hf
from eomdp.fcicis import get_fci_cis_wfns
import numpy as np
from functools import reduce
from pyscf import ao2mo
from pyscf.tdscf import TDA
import json

def hs_1imp(wfnlst, nocc, nvir, h1e, eri):

    h = np.zeros((2*nocc*nvir+1, 2*nocc*nvir+1))
    s = np.zeros((2*nocc*nvir+1, 2*nocc*nvir+1))

    for i in range(2*nocc*nvir+1):

        cibra = wfnlst[i]
        for j in range(2*nocc*nvir+1):

            ciket = wfnlst[j]

            s[i,j] += np.einsum("ij,ij->", cibra.conj(), ciket)
            dm1, dm2 = fci.direct_spin1.trans_rdm12(cibra, ciket, nocc+nvir, (nocc,nocc))
            h[i,j] += np.einsum("ij,ij->", h1e, dm1) + .5 * np.einsum("ijkl,ijkl->", eri, dm2)

    return h, s

def get_site_dm_sz(fcivec, nsite, nelec, mo_coeff):
    # return the z-direction spin of each site
    dm_aa, dm_bb = fci.direct_spin1.make_rdm1s(fcivec, nsite, nelec)
    dm = np.einsum("xi,ij,xj->x", mo_coeff, dm_aa+dm_bb, mo_coeff)
    sz = np.einsum("xi,ij,xj->x", mo_coeff, dm_aa-dm_bb, mo_coeff) * .5
    return dm, sz

def gen_corr_fn(fcivec, nsite, nelec, mo_coeff):
    dm1, dm2 = fci.direct_spin1.make_rdm12(fcivec, nsite, nelec)
    dm = np.einsum("xi,ij,xj->x", mo_coeff, dm1, mo_coeff)

    corr_mat = np.einsum("ijkl,mi,mj,nk,nl->mn", dm2, mo_coeff, mo_coeff, mo_coeff, mo_coeff) - np.einsum("i,j->ij", dm, dm) + np.diag(dm)
    return corr_mat

res = []

def get_ave_corr_fn(corr_mat, dim):
    length = dim // 2 + 1
    corr_fn_lst = []

    for j in range(length):
        corr_f = 0
        for i in range(dim):
            corr_f += corr_mat[i,(i+j)%dim] / (2*dim)
            corr_f += corr_mat[i,(i-j)%dim] / (2*dim)
        corr_fn_lst.append(corr_f)

    return corr_fn_lst

for U in range(1, 13, 1):
    mol = hubbard.HubbardMole(1, 10, 1, U)
    mol.nelectron = 10

    nocc = nvir = 5
    norb = nocc + nvir

    subres = {
        "U": U,
        "DM-CORR-FCI": [],
        "DM-CORR-CISFCI": []
    }

    mf = hubbard.RHF_SpinHubbard(mol)
    mf.pbc = True
    mf.kernel()

    ci_method = fci.FCI(mf)
    eci, ci = ci_method.kernel(nroots=6)
    print(eci)

    wfnlst = get_fci_cis_wfns(ci[0], nocc, nvir)

    h1e = reduce(np.dot, (mf.mo_coeff.T, mf.get_hcore(), mf.mo_coeff))
    eri = ao2mo.kernel(mf._eri, mf.mo_coeff, compact=False)
    eri = eri.reshape(norb,norb,norb,norb)

    h, ovlp = hs_1imp(wfnlst, nocc, nvir, h1e, eri)
    e, c = hf.eig(h, ovlp)

    for i in range(6):

        ext_energy_fci = eci[i]
        ext_energy_cisfci = e[i]
        ci_fci = ci[i]
        ci_cisfci = 0
        for j in range(2*nocc*nvir+1):
            ci_cisfci += wfnlst[j] * c[j,i]

        corr_mat_fci = gen_corr_fn(ci_fci, 10, (5,5), mf.mo_coeff)
        corr_mat_cisfci = gen_corr_fn(ci_cisfci, 10, (5,5), mf.mo_coeff)

        corr_fn_fci = get_ave_corr_fn(corr_mat_fci, 10)
        corr_fn_cisfci = get_ave_corr_fn(corr_mat_cisfci, 10)

        print("FCI Corr FN: ", corr_fn_fci)
        print("CISFCI Corr FN: ", corr_fn_cisfci)

        subres["DM-CORR-FCI"].append(corr_fn_fci)
        subres["DM-CORR-CISFCI"].append(corr_fn_cisfci)

    res.append(subres)

f = open("./10/hubbard-corr.json", "w")
json.dump(res, f)
f.close()
        