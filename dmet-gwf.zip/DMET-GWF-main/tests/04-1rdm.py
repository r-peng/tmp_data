import sys
sys.path.append("..")

from pyscf import gto
from pyscf.scf import hf
import numpy as np
from dmet.main.solver import DMET_SCF, DMET_FCI
from dmet.main.outer import DMET
from cpskit.fci import CPSMethod

def make_Hring(l=1.):
    r = l/(2 * np.sin(np.pi / 10))
    atmlst = []
    for i in range(10):
        atmlst.append(['H', (r*np.cos(2. * np.pi/10*i), r*np.sin(2. * np.pi/10*i), 0)])
    mol = gto.Mole()
    mol.atom = atmlst
    mol.basis = 'sto-6g'
    mol.build()
    return mol

elst = []

def get_e(bl):

    frag2 = [[[0,1], [2,3], [4,5], [6,7], [8,9]]]
    mol = make_Hring(bl)
    mf = hf.RHF(mol); mf.kernel()

    dmet_hf = DMET(mf, frag2, DMET_SCF)
    dmet_ci = DMET(mf, frag2, DMET_FCI)
    dmet_hf.chempot_cycle()
    dmet_ci.chempot_cycle()
    cps = CPSMethod(dmet_hf, dmet_ci, mf)

    mocs = [[DMET_SCF(mf, frag).fbc_coeff for frag in sym_frag] for sym_frag in cps.fragments]

    e = cps.approx_energy(mocs)

    elst.append(e)

bllst = np.linspace(0.5, 2.5, 21)

for bl in bllst: get_e(bl)

elst = np.array(elst)
np.savetxt("app1rdm-e-2H.txt", elst)

