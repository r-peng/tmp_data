# Ground-state energy of CPS wave function from DMET

import sys
sys.path.append("..")

from pyscf import gto
from pyscf.scf import hf
import numpy as np
from dmet.main.solver import DMET_SCF, DMET_FCI, DMET_DMRG
from dmet.main.outer import DMET
from cpskit.fci import CPSMethod

def make_Hring(l=1.):
    r = l/(2 * np.sin(np.pi / 10))
    atmlst = []
    for i in range(10):
        atmlst.append(['H', (r*np.cos(2. * np.pi/10*i), r*np.sin(2. * np.pi/10*i), 0)])
    mol = gto.Mole()
    mol.atom = atmlst
    mol.basis = 'sto-6g'
    mol.build()
    return mol

fragments = [[[x] for x in range(10)]]
mol = make_Hring(1.4)
mf = hf.RHF(mol); mf.kernel()

# One-shot DMET calculation
dmet_ci = DMET(mf, fragments, DMET_FCI)
dmet_ci.chempot_cycle()
print(dmet_ci.kernel_1shot()[0])

dmet_dmrg = DMET(mf, fragments, DMET_DMRG)
dmet_dmrg.chempot_cycle()
print(dmet_dmrg.kernel_1shot()[0])