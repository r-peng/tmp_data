import sys
sys.path.append("..")

from eomdp import eomdp_slow
from pyscf import gto
from pyscf.scf import hf
import numpy as np
from dmet.main.solver import DMET_FCI
from dmet.main.outer import DMET

def make_Hring(l=1.):
    r = l/(2 * np.sin(np.pi / 10))
    atmlst = []
    for i in range(10):
        atmlst.append(['H', (r*np.cos(2. * np.pi/10*i), r*np.sin(2. * np.pi/10*i), 0)])
    mol = gto.Mole()
    mol.atom = atmlst
    mol.basis = 'sto-6g'
    mol.build()
    return mol

frag2 = [[[0,1]], [[2,3]], [[4,5]], [[6,7]], [[8,9]]]

eom_ec = []
eom_ecv = []

def calc(bl, mode="ecv"):

    mol = make_Hring(bl)
    mf = hf.RHF(mol); mf.kernel()
    nao = mol.nao
    nocc = mol.nelec[0]
    na = 2
    nvir = nao - nocc

    dmet_obj = DMET(mf, frag2, DMET_FCI)
    dmet_obj.chempot_cycle()

    print("Calculating mode {}\t for bond length {:.2f} ...".format(mode, bl))
    e = eomdp_slow.eomdp_kernel(dmet_obj, mode=mode)

    return e


for bl in [1.0]: calc(bl, mode='ecv')
