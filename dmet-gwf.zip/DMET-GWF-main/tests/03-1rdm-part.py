import sys
sys.path.append("..")

from pyscf import gto
from pyscf.scf import hf
import numpy as np
from dmet.main.solver import DMET_SCF, DMET_FCI
from dmet.main.outer import DMET
from cpskit.fci import CPSMethod
import pyscf.fci.direct_spin1 as fci
import cpskit
from cpskit import app1rdm

def make_Hring(l=1.):
    r = l/(2 * np.sin(np.pi / 10))
    atmlst = []
    for i in range(10):
        atmlst.append(['H', (r*np.cos(2. * np.pi/10*i), r*np.sin(2. * np.pi/10*i), 0)])
    mol = gto.Mole()
    mol.atom = atmlst
    mol.basis = 'sto-6g'
    mol.build()
    return mol

frag2 = [[[0,1]], [[5,6]], [[2,3,4]], [[7,8,9]]]
mol = make_Hring(1.4)
mf = hf.RHF(mol); mf.kernel()

dmet_hf = DMET(mf, frag2, DMET_SCF)
dmet_ci = DMET(mf, frag2, DMET_FCI)
dmet_hf.chempot_cycle()
dmet_ci.chempot_cycle()
cps = CPSMethod(dmet_hf, dmet_ci, mf)

fci_coeffs = [solver.fci_coeff for solver in dmet_ci.dmets]

projs     = cps.projs


mo_c = cps.mo_coeff[:,np.where(cps.mo_occ!=0.)[0]]

coef_hf = cpskit.fci.ci_slater(mol.nao, mol.nelec, (mo_c, mo_c))

frag_part = [[[2,3,4]],[[7,8,9]]]
ci_part = cpskit.fci.ci_cps(
    mol.nao, mol.nelec, coef_hf, 
    [projs[2],projs[3]], frag_part, normalized=False
    )

ovlp_part = np.dot(ci_part.conj().reshape(-1), ci_part.reshape(-1))

dm_part = fci.make_rdm1(ci_part, mol.nao, mol.nelec)[[2,3,4]][:,[7,8,9]]

print("Off-diagonal 1rdm obtained from FCI = ", dm_part)


na0 = 3
na1 = 3

str_idx_0 = app1rdm.get_str_idx(na0)
str_idx_1 = app1rdm.get_str_idx(na1)

f0a = app1rdm.gaag_info(na0, projs[2], fci_coeffs[2], str_idx_0)
f1a = app1rdm.gaag_info(na1, projs[3], fci_coeffs[3], str_idx_1)

f0b = app1rdm.gabg_info(na0, projs[2], fci_coeffs[2], str_idx_0)
f1b = app1rdm.gabg_info(na1, projs[3], fci_coeffs[3], str_idx_1)

fo0 = app1rdm.gg_info(na0, projs[2], fci_coeffs[2], str_idx_0)
fo1 = app1rdm.gg_info(na1, projs[3], fci_coeffs[3], str_idx_1)

moc0 = dmet_ci.dmets[2].fbc_coeff

newdmet = DMET_SCF(mf, [7,8,9])
moc1 = newdmet.fbc_coeff

ovlp_ao = hf.get_ovlp(mol)

dm = app1rdm.make_dm_odiag(
   (f0a, f0b), (f1a, f1b), 
   (moc0, moc0), (moc1, moc1),
   (na0, na1), mol.nelec[0], ovlp_ao)

ovlp = app1rdm.make_ovlp_odiag(
    fo0, fo1, (moc0, moc0), (moc1, moc1), 
    (na0, na1), mol.nelec[0], ovlp_ao
)

print("Off-diagonal 1rdm from app1rdm = ", dm)
print("Off-diagonal normalized factor from FCI = ", ovlp_part)
print("Off-diagonal normalized factor from app1rdm = ", ovlp)

frag_part = [[[7,8,9]]]

ci_part = cpskit.fci.ci_cps(
    mol.nao, mol.nelec, coef_hf, 
    [projs[3]], frag_part, normalized=False
    )

ovlp_part = np.dot(ci_part.conj().reshape(-1), ci_part.reshape(-1))

dm_part = fci.make_rdm1(ci_part, mol.nao, mol.nelec)[[7,8,9]][:,[7,8,9]]

print("Diagonal 1rdm obtained from FCI = ", dm_part)

dm = app1rdm.make_dm_diag(fci_coeffs[3], na1)
 
print("Diagonal 1rdm obtained from app1rdm = ", dm)

print("Diagonal normalized factor from FCI = ", ovlp_part)

assert np.allclose(ovlp_part, 1)
assert np.allclose(dm_part, dm)

# Bug:  index [7,8,9] -> [8,9,7] , error
#       discontinuous fragment: [5,7,9], error