# The dmet correlator does not fit the local constraint

import sys
sys.path.append("..")

from pyscf import gto
from pyscf.scf import hf
import numpy as np
from dmet.main.solver import DMET_SCF, DMET_FCI
from dmet.main.outer import DMET
from cpskit.fci import CPSMethod
from pyscf.fci import cistring

def make_Hring(l=1.):
    r = l/(2 * np.sin(np.pi / 10))
    atmlst = []
    for i in range(10):
        atmlst.append(['H', (r*np.cos(2. * np.pi/10*i), r*np.sin(2. * np.pi/10*i), 0)])
    mol = gto.Mole()
    mol.atom = atmlst
    mol.basis = 'sto-6g'
    mol.build()
    return mol

frag2 = [[[0,1], [2,3], [4,5], [6,7], [8,9]]]
mol = make_Hring(1.4)
mf = hf.RHF(mol); mf.kernel()

dmet_hf = DMET(mf, frag2, DMET_SCF)
dmet_ci = DMET(mf, frag2, DMET_FCI)
dmet_hf.chempot_cycle()
dmet_ci.chempot_cycle()

cps = CPSMethod(dmet_hf, dmet_ci, mf)

coef_ci = cps.coef_cis[0] # projector :math:`g_{ji}`
coef_hf = cps.coef_hfs[0]   # two spins, :math:`\lambda_{i^\uparrow i^\downarrow} = |\alpha_i^{\uparrow} \alpha_j^{\downarrow} \rangle`

def get_local_dm(coef_ci, coef_hf, na):

    cistr = list(cistring.make_strings(range(2*na), na))
    
    aalst   = []   # :math:`\langle \hat a^\dagger \hat a \rangle`
    aagglst = []   

    for n in range(na):
        hfstr_occ_n = [j for j in range(2**na) if j&(2**n) != 0]
        cistr_occ_n = [cistr.index(j) for j in cistr if j&(2**n) != 0]

        aa = 0
        for idx in hfstr_occ_n:
            aa += np.einsum("i,i->", coef_hf[idx], coef_hf[idx])
        aalst.append(aa)

        aagg = 0
        for idx in cistr_occ_n:
            aagg += np.einsum("i,i->", coef_ci[idx], coef_ci[idx])
        aagglst.append(aagg)


    return (np.array(aalst), np.array(aagglst))

aa, aagg = get_local_dm(coef_ci, coef_hf, 2)

print("aa   = ", aa)
print("aagg = ", aagg)

assert np.allclose(aa, aagg)