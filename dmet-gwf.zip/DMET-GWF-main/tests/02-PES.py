# Ground-state energy of CPS wave function from DMET

import sys
sys.path.append("..")

from pyscf import gto
from pyscf.scf import hf
import numpy as np
from pyscf import fci
from dmet.main.solver import DMET_SCF, DMET_FCI
from dmet.main.outer import DMET
from cpskit.fci import CPSMethod

def make_Hring(l=1.):
    r = l/(2 * np.sin(np.pi / 10))
    atmlst = []
    for i in range(10):
        atmlst.append(['H', (r*np.cos(2. * np.pi/10*i), r*np.sin(2. * np.pi/10*i), 0)])
    mol = gto.Mole()
    mol.atom = atmlst
    mol.basis = 'sto-6g'
    mol.build()
    return mol

frag2 = [[[0,1], [2,3], [4,5], [6,7], [8,9]]]
frag1 = [[[x] for x in range(10)]]

bllst = np.linspace(2.0, 2.5, 6)

summary = []
nr = 10

for bl in bllst:

    alist = [bl]

    mol = make_Hring(bl)
    mf = hf.RHF(mol); mf.kernel()
    fcisolver = fci.FCI(mf)
    e, c = fcisolver.kernel(nroots=nr) 

    print("Bond length = ", bl, ", E(FCI) = ", e)

    dmet_hf = DMET(mf, frag1, DMET_SCF)
    dmet_ci = DMET(mf, frag1, DMET_FCI)
    dmet_hf.chempot_cycle()
    dmet_ci.chempot_cycle()
    cps = CPSMethod(dmet_hf, dmet_ci, mf)

    e1, c1 = cps.eom_fci()

    print("Bond length = ", bl, ", E(CPS-1H) = ", e1[:nr])

    dmet_hf = DMET(mf, frag2, DMET_SCF)
    dmet_ci = DMET(mf, frag2, DMET_FCI)
    dmet_hf.chempot_cycle()
    dmet_ci.chempot_cycle()
    cps = CPSMethod(dmet_hf, dmet_ci, mf)

    e2, c2 = cps.eom_fci()

    print("Bond length = ", bl, ", E(CPS-2H) = ", e2[:nr])

    alist.extend(list(e))
    alist.extend(list(e1[:nr]))
    alist.extend(list(e2[:nr]))

    summary.append(alist)

summary = np.array(summary)
summary.save_txt("PES-Summary.txt")