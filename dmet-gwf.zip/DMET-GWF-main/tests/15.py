import sys
sys.path.append("..")

from dmet.model import hubbard
from pyscf import gto
from pyscf.scf import hf
import numpy as np
from dmet.main.solver import DMET_SCF, DMET_FCI
from dmet.main.outer import DMET
from cpskit.fci import CPSMethod
from cpskit.fci import ci_cps
from pyscf.fci import cistring, direct_spin1
from scipy.optimize import fsolve

# Generate basis sets given 1-site Gutzwiller correlators

def _get_projected_basis_1site(siteidx, ci0, norb, nelec):

    num_string = cistring.num_strings(norb, nelec//2)
    if ci0 is 0: ci0 = np.random.random((num_string, num_string))
    strs = cistring.make_strings(range(norb), nelec//2)

    occidx = np.where(strs & 2**siteidx == 2**siteidx)[0]
    viridx = np.where(strs & 2**siteidx == 0)[0]

    ci_ud = np.zeros_like(ci0)
    ci_ud[np.ix_(occidx, occidx)] += ci0[np.ix_(occidx, occidx)]

    ci_u0 = np.zeros_like(ci0)
    ci_u0[np.ix_(occidx, viridx)] += ci0[np.ix_(occidx, viridx)]

    ci_0d = np.zeros_like(ci0)
    ci_0d[np.ix_(viridx, occidx)] += ci0[np.ix_(viridx, occidx)]

    ci_00 = np.zeros_like(ci0)
    ci_00[np.ix_(viridx, viridx)] += ci0[np.ix_(viridx, viridx)]    

    return ci_ud, ci_u0, ci_0d, ci_00

def trans_energy(h1e, eri, cibra, ciket, norb, nelec, link_index=None):
    '''Compute the FCI electronic energy for given Hamiltonian and FCI vector.
    '''
    h2e = direct_spin1.absorb_h1e(h1e, eri, norb, nelec, .5)
    ci1 = direct_spin1.contract_2e(h2e, ciket, norb, nelec, link_index)
    return np.dot(cibra.reshape(-1), ci1.reshape(-1))

def gwfexact_grad_1site(ci0, norb, nelec, proj, E, h1e, eri):

    fraglst_dg = [[[i] for i in range(1,norb)]]
    fraglst_full = [[[i] for i in range(norb)]]

    ci_g = ci_cps(norb, (nelec//2,nelec//2), ci0, 
    [proj], fraglst_full, normalized=False)
    ci_dg = ci_cps(norb, (nelec//2,nelec//2), ci0,
    [proj], fraglst_dg, normalized=False)
    ci_dgs = _get_projected_basis_1site(0, ci_dg, norb, nelec)

    trans_Hs = [trans_energy(h1e, eri, cibra, ci_g, norb, nelec) for cibra in ci_dgs]
    trans_Ss = [np.dot(cibra.reshape(-1), ci_g.reshape(-1)) for cibra in ci_dgs]

    partial_G = [(trans_Hs[i] - E * trans_Ss[i]) * (2*norb) for i in range(4)]
    partial_E = [1 - np.dot(ci_g.reshape(-1), ci_g.reshape(-1))]

    return np.array(partial_G + partial_E)

def gwfexact_1site(ci0, norb, nelec, proj, E, h1e, eri):
    fraglst_full = [[[i] for i in range(norb)]]
    ci_g = ci_cps(norb, (nelec//2,nelec//2), ci0, 
    [proj], fraglst_full, normalized=False)

    H = direct_spin1.energy(h1e, eri, ci_g, norb, nelec)
    S = np.dot(ci_g.reshape(-1), ci_g.reshape(-1))
    return H - E * (S-1)


def get_gsbasis(ci0, proj, norb, nelec):
    
    gsbasis = []
    gsbasis.append([ci0])
    for i in range(1, 4):
        occs = cistring._gen_occslst(range(norb), i)
        basislst = []
        for occ in occs:
            basislst.append(ci_cps(norb, (nelec//2, nelec//2), 
            ci0, [proj], [[[x] for x in occ]], normalized=False))
        gsbasis.append(basislst)

    return gsbasis


import numdifftools as nd

L = 6; U = 4

mol = hubbard.HubbardMole(lx=L, ly=1, t=1, U=U)
mol.nelectron = L
mf = hubbard.RHF_SpinHubbard(mol); mf.kernel()

h1e = mf.get_hcore()
eri = mf._eri

frag1 = [[[x] for x in range(L)]]
dmet_hf = DMET(mf, frag1, hubbard.DMET_Hubbard_SCF)
dmet_ci = DMET(mf, frag1, hubbard.DMET_Hubbard_FCI)

dmet_hf.chempot_cycle()
dmet_ci.chempot_cycle()

cps = CPSMethod(dmet_hf, dmet_ci, mf)
proj = cps.get_projectors()[0]

print(proj)

ci0 = cps.ci_slater([mf.mo_coeff[:,:L//2], mf.mo_coeff[:,:L//2]])
x0 = np.array(list(proj.reshape(-1)) + [direct_spin1.energy(h1e, eri, ci0, L, L)])

print(x0)


def func(x):
    p0, pu, pd, pud, e = x
    p = np.array([[p0,pu],[pd,pud]])
    return gwfexact_1site(ci0, L, L, p, e, h1e, eri)

def func_deriv(x):
    p0, pu, pd, pud, e = x
    p = np.array([[p0,pu],[pd,pud]])
    return gwfexact_grad_1site(ci0, L, L, p, e, h1e, eri)


print(func_deriv(x0))
num_deriv = nd.Gradient(func, full_output=True)
val, info = num_deriv(x0)
print(val)