import numpy as np
from pyscf.fci.cistring import make_strings, num_strings
from pyscf import lib

def make_hdiag_spinless(h1e, eri, norb, nelec):
    strlst = make_strings(range(norb), nelec)
    h1ediag = np.diag(h1e)
    hdiag = np.zeros_like(strlst)

    num_string = len(strlst)
    for i in range(num_string):
        istr = strlst[i]
        for p in range(norb):
            if istr & 2**p:
                hdiag[i] += h1ediag[p]
                for q in range(norb):
                    if istr & 2**q:
                        hdiag[i] += eri[p,q] * .5
    
    return hdiag

def phase_factor(p:int, q:int, cistr:int):
    # phase factor (or sign) of the matrix element

    def cnt_one(n): 
        # Count number of "1" in a binary numbber
        k = 0
        while n:
            n = n & (n-1)
            k += 1
        return k

    if p==q: return 1
    else:
        a = (2**(min(p,q)+1) * (2**(abs(p-q)-1) - 1)) & cistr
        numelec = cnt_one(a)
        return (-1)**numelec

def excite_str(p:int, q:int, cistr:int):    
    # get the excited CIstring by an operator 
    # <I| -> <I|E_{pq}
    if p==q: return cistr
    else: 
        a = 2**p + 2**q
        return cistr ^ a

def contract_1e_spinless(k1e, ci_coeff, norb, nelec):
    r"""
    Calculate \sum_{J} <I|K|J> C_J (Eq. 11.8.10)
    Ref: Helgaker. T.; Jorgensen. P.; Olsen. J. Molecular Electronic-Structure Theory-John Wiley & Sons (2000), Chapter 11.8.4

    Args:
        k1e: effective one-electron integrals (Eq. 11.8.8)
        ci_coeff: CI coefficient with dimension (num_string, num_string)
    """

    strlst = list(make_strings(range(norb), nelec))

    kc = np.zeros_like(ci_coeff)       
    num_string = len(strlst)
    for i in range(num_string):
        istr = strlst[i]
        for p in range(norb):
            for q in range(norb):
                if istr & 2**p and (p==q or not istr & 2**q):   
                    # p->q transition allowed
                    jidx = strlst.index(excite_str(p,q,istr))
                    pref = k1e[p,q] * phase_factor(p,q,istr)
                    kc[i] += pref * ci_coeff[jidx]
    return kc

def contract_2e_spinless(eri, ci_coeff, norb, nelec):
    r"""
    .. math::
        \sigma_I^{(2)} = \dfrac{1}{2} \sum\limits_{PQ} \langle I | \hat E_{PP} | I \rangle \langle I | \hat E_{QQ} | I \rangle \tilde g_{PQ} C_I 
    
    """

    print("Execute a contract_2e...")

    strlst = make_strings(range(norb), nelec)

    gc = np.zeros_like(ci_coeff)
    num_string = len(strlst)
    for i in range(num_string):
        istr = strlst[i]
        for p in range(norb):
            for q in range(norb):
                if istr & 2**p and istr & 2**q:
                    gc[i] += .5 * eri[p,q] * ci_coeff[i]
    return gc


def ci_slater(norb, nelec, clm):
        # Get the Full-CI coefficient for Slater determinant in CI.

    print("Construct CI slater...")
    stra = make_strings(range(norb), nelec)

    elidxa = [np.array([x for x in range(norb) if s&2**x]) for s in stra]

    detca = np.array([np.linalg.det(clm[elidx,:]) for elidx in elidxa])
    print("Construct CI of Slater completed.")
    return detca

def kernel_spinless(h1e, eri, norb, nelec, clm):
    na = num_strings(norb, nelec)

    ci0 = ci_slater(norb, nelec, clm)

    def hop(c):
        return contract_1e_spinless(h1e, c, norb, nelec) + contract_2e_spinless(eri, c, norb, nelec)

    hdiag = make_hdiag_spinless(h1e, eri, norb, nelec)
    precond = lambda x, e, *args: x/(hdiag-e+1e-4)

    e, c = lib.davidson(hop, ci0, precond, verbose=9)
    print(e)
    return e, c

if __name__ == "__main__":

    # for 4*5 spinless Hubbard problem, it is hard to be directly solved

    from hf_hubbard import HubbardMole, RHF_SpinlessHubbard

    mol = HubbardMole(4, 3, 1, .1)
    mol.nelectron = 12
    mol.verbose = 5
    mf = RHF_SpinlessHubbard(mol)
    mf.kernel()
    print(mf.mo_coeff)
    kernel_spinless(mf.get_hcore(), mf._eri, 12, 6, mf.mo_coeff[:,mf.mo_occ>0])
