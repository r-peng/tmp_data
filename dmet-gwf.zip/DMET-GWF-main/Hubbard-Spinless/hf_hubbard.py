import numpy as np
from pyscf import gto
from pyscf.scf import hf
from pyscf.lib import logger

"""
Reconstruction of SCF method
        mf.get_init_guess   
        mf.get_hcore        Completed
        mf.get_ovlp         Completed
        mf.get_veff         Completed
        mf.get_fock         Completed
        mf.get_grad         Completed
        mf.eig              Completed
        mf.get_occ          Completed
        mf.make_rdm1        Completed
        mf.energy_tot       Completed
        mf.dump_chk         
"""

def get_hcore_2dobc(lx, ly, t):
    
    hcore = np.zeros((lx,ly,lx,ly))

    for i in range(lx):
        for j in range(ly):
            if i+1 in range(lx): hcore[i,j,i+1,j] = -t
            if i-1 in range(lx): hcore[i,j,i-1,j] = -t
            if j+1 in range(ly): hcore[i,j,i,j+1] = -t
            if j-1 in range(ly): hcore[i,j,i,j-1] = -t

    hcore = hcore.reshape((lx*ly, lx*ly))

    return hcore


def get_eri_2dobc(lx, ly, U):

    # g_{iijj} = 2U

    eri = np.zeros((lx,ly,lx,ly))

    for i in range(lx):
        for j in range(ly):
            if i+1 in range(lx): eri[i,j,i+1,j] = 2 * U
            if j+1 in range(ly): eri[i,j,i,j+1] = 2 * U

    eri = eri.reshape((lx*ly, lx*ly))

    return eri

def get_full_eri_2dobc(lx, ly, U):

    eri = get_eri_2dobc(lx,ly,U)

    erinew = np.zeros((lx*ly, lx*ly, lx*ly, lx*ly))

    for i in range(eri.shape[0]):
        for j in range(eri.shape[1]):
            erinew[i,i,j,j] = eri[i,j]
    return erinew

def get_jk(dm, eri):

    eri = eri + eri.T   # g_{\mu\nu} -> g_{\mu\nu} + g_{\nu\mu} 

    j = np.diag(np.einsum("nn,mn->m", dm, eri))
    k = dm * eri
    return j, k

def get_occ(mf, mo_energy=None, mo_coeff=None):

    if mo_energy is None: mo_energy = mf.mo_energy
    e_idx = np.argsort(mo_energy)
    e_sort = mo_energy[e_idx]
    nmo = mo_energy.size
    mo_occ = np.zeros(nmo)
    nocc = mf.mol.nelectron
    mo_occ[e_idx[:nocc]] = 1
    if mf.verbose >= logger.INFO and nocc < nmo:
        if e_sort[nocc-1]+1e-3 > e_sort[nocc]:
            logger.warn(mf, 'HOMO %.15g == LUMO %.15g',
                        e_sort[nocc-1], e_sort[nocc])
        else:
            logger.info(mf, '  HOMO = %.15g  LUMO = %.15g',
                        e_sort[nocc-1], e_sort[nocc])

    if mf.verbose >= logger.DEBUG:
        np.set_printoptions(threshold=nmo)
        logger.debug(mf, '  mo_energy =\n%s', mo_energy)
        np.set_printoptions(threshold=1000)
    return mo_occ

def energy_tot(mf, dm=None, h1e=None, vhf=None):
    return hf.energy_elec(mf, dm, h1e, vhf)[0]


class HubbardMole(gto.Mole):

    def __init__(self, lx, ly, t, U):
        super(HubbardMole, self).__init__()

        self.t = t
        self.U = U
        self.lx = lx
        self.ly = ly


class RHF_SpinlessHubbard(hf.RHF):

    def __init__(self, mol:HubbardMole):
        super(RHF_SpinlessHubbard, self).__init__(mol)

        self._eri = get_eri_2dobc(mol.lx, mol.ly, mol.U)

    def eig(self, h, s):
        # eigenvalue solver since orbitals are orthornomal.
        e, c = np.linalg.eig(h)
        idx = np.argmax(abs(c.real), axis=0)
        c[:,c[idx,np.arange(len(e))].real<0] *= -1
        return e, c

    def get_hcore(self, mol=None):
        if mol is None: mol = self.mol
        return get_hcore_2dobc(mol.lx, mol.ly, mol.t)

    def get_full_eri(self, mol=None):
        if mol is None: mol = self.mol
        return get_full_eri_2dobc(mol.lx, mol.ly, mol.U)

    def get_ovlp(self, mol=None):
        if mol is None: mol = self.mol
        return np.eye(mol.lx*mol.ly)

    def get_veff(self, mol=None, dm=None, dm_last=0, vhf_last=0, hermi=1):
        if mol is None: mol = self.mol
        if dm is None: dm = self.make_rdm1()
        if self.direct_scf:
            ddm = np.asarray(dm) - dm_last
            vj, vk = get_jk(ddm, self._eri)
            return vhf_last + vj * .5 - vk * .5
        else:
            vj, vk = get_jk(dm, self._eri)
            return vj * .5 - vk * .5

    def get_grad(self, mo_coeff, mo_occ, fock=None):
        # ???
        if fock is None:
            dm1 = self.make_rdm1(mo_coeff, mo_occ)
            fock = self.get_hcore(self.mol) + self.get_veff(self.mol, dm1)
        return hf.get_grad(mo_coeff, mo_occ, fock) / 2

    get_occ = get_occ
    energy_tot = energy_tot

if __name__ == "__main__":

    """
    problem: when U/t > 0.4, the energy is different from Eric's result.
    """

    dm = None
    U = np.linspace(0.1, 2, 39)
    for u in U:
        mol = HubbardMole(4, 5, 1, u)
        mol.nelectron = 10
        mf = RHF_SpinlessHubbard(mol)
        if u != .1: 
            mf.kernel(dm)
        else:
            mf.kernel()

        dm = mf.make_rdm1()