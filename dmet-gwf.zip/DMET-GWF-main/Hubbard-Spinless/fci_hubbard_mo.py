import numpy as np
from pyscf import lib
from pyscf import ao2mo
from pyscf.fci import cistring, fci_slow

# iminating fci_slow.py in PySCF
# spinless

def make_hdiag(h1e, eri, norb, nelec):
    occlst = cistring._gen_occslst(range(norb), nelec)
    eri = ao2mo.restore(1, eri, norb)

    diagj = np.einsum("iijj->ij", eri)
    diagk = np.einsum("ijji->ij", eri)
    hdiag = []
    for occ in occlst:
        e1 = h1e[occ,occ].sum()
        e2 = diagj[occ][:,occ].sum() - diagk[occ][:,occ].sum()
        hdiag.append(e1 + e2 * .5)

    return np.array(hdiag)

def contract_1e_spinless(f1e, fcivec, norb, nelec):

    link_index = cistring.gen_linkstr_index(range(norb), nelec)
    n = cistring.num_strings(norb, nelec)
    t1 = np.zeros((norb, norb, n))
    for str0, tab in enumerate(link_index):
        for a, i, str1, sgn in tab:
            t1[a,i,str1] += sgn * fcivec[str0]

    fcinew = np.dot(f1e.reshape(-1), t1.reshape(-1,n))
    return fcinew

def contract_2e_spinless(eri, fcivec, norb, nelec, opt=None):

    link_index = cistring.gen_linkstr_index(range(norb), nelec)
    n = cistring.num_strings(norb, nelec)
    t1 = np.zeros((norb,norb,n))
    for str0, tab in enumerate(link_index):
        for a, i, str1, sign in tab:
            t1[a,i,str1] += sign * fcivec[str0] 

    t1 = lib.einsum("bjai,aiA->bjA", eri.reshape([norb]*4), t1)

    fcinew = np.zeros_like(fcivec)

    for str0, tab in enumerate(link_index):
        for a, i, str1, sgn in tab:
            fcinew[str1] += sgn * t1[a,i,str0]

    return fcinew

def kernel_spinless(h1e, eri, norb, nelec, ecore=0):
    h2e = fci_slow.absorb_h1e(h1e, eri, norb, nelec, .5)

    n = cistring.num_strings(norb, nelec)
    ci0 = np.zeros(n); ci0[0] = 1

    def hop(c):
        return [contract_2e_spinless(h2e, ci, norb, nelec) for ci in c]

    hdiag = make_hdiag(h1e, eri, norb, nelec)
    precond = lambda x, e, *args: x/(hdiag-e+1e-4)

    e, c = lib.davidson1(hop, [ci0], precond, verbose=9)
    print("FCI Energy = ", e)
    return e + ecore

if __name__ == "__main__":
    from functools import reduce
    from hf_hubbard import HubbardMole, RHF_SpinlessHubbard

    mol = HubbardMole(4, 3, 1, .1)
    mol.nelectron = 6
    mol.verbose = 5
    mf = RHF_SpinlessHubbard(mol)
    mf.kernel()
    norb = mol.lx * mol.ly
    nelec = mol.nelectron

    h1e = reduce(np.dot, (mf.mo_coeff.T, mf.get_hcore(), mf.mo_coeff))

    eri = ao2mo.kernel(mf.get_full_eri(), mf.mo_coeff, compact=False)
    eri.reshape(norb,norb,norb,norb)
    kernel_spinless(h1e, eri, norb, nelec)
