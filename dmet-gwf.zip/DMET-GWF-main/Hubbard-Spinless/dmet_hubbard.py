import dmet_old as dmet
import hf_hubbard, fci_hubbard_lo

class DMET_Hubbard(dmet.DMET_SCF):
    def __init__(self, mf:hf_hubbard.RHF_SpinlessHubbard, fragments, mu_glob=0):
        dmet.DMET_SCF.__init__(self, mf, fragments, mu_glob)

    

if __name__ == "__main__":

    mol = hf_hubbard.HubbardMole(4, 5, 1, .1)
    mol.nelectron = 10
    mf = hf_hubbard.RHF_SpinlessHubbard(mol)
    mf.kernel()

    DMET_Hubbard(mf, [1,2,3])
