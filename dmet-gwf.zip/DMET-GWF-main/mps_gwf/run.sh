for x in 8 6 4 2
do  
    echo ${x}
    python exact-TN-klabel.py 18 ${x} 4
done