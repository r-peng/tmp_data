import numpy as np
import sys
from pyblock2.driver.core import DMRGDriver, SymmetryTypes
from pyblock3.block2.io import MPSTools
from pyblock3.algebra.core import SparseTensor


def get_klabel(length, u, nr):

    L = length
    N = L
    TWOSZ = 0
    t = 1
    U = u
    nroots = nr

    driver = DMRGDriver(scratch="./tmp", symm_type=SymmetryTypes.SZ, n_threads=4)
    driver.initialize_system(n_sites=L, n_elec=N, spin=TWOSZ)

    b = driver.expr_builder()

    # hopping term
    b.add_term("cd",
        np.array([[[i, (i+1)%L], [(i+1)%L, i]] for i in range(L)]).flatten(),
        [-t] * 2 * (L))
    b.add_term("CD",
        np.array([[[i, (i+1)%L], [(i+1)%L, i]] for i in range(L)]).flatten(),
        [-t] * 2 * (L))

    # onsite term
    b.add_term("cdCD",
        np.array([[i, ] * 4 for i in range(L)]).flatten(),
        [U] * L)

    mpo = driver.get_mpo(b.finalize(), iprint=2, add_ident=False)
    ket = driver.get_random_mps(tag="KET", bond_dim=400, nroots=nroots)

    def run_dmrg(driver, mpo):
        bond_dims = [200] * 4 + [400] * 4
        noises = [1e-4] * 4 + [1e-5] * 4 + [0]
        thrds = [1e-10] * 8
        return driver.dmrg(
            mpo,
            ket,
            n_sweeps=10,
            bond_dims=bond_dims,
            noises=noises,
            thrds=thrds,
            iprint=2,
        )

    energies = run_dmrg(driver, mpo)

    np.savetxt("energies-{}-{}-{}.txt".format(L, U, nroots), np.array(energies))


    def calc_trans_mps(mps, nelec=None):

        t = mps.tensors
        norb = len(t)
        if nelec is None: nelec = norb

        res = SparseTensor._tensordot(t[0], t[1], axes=([2],[0]))
        res = SparseTensor._tensordot(res, t[0], axes=([2],[1]))
        res = SparseTensor._tensordot(res, t[2], axes=([2],[0]))
        res = SparseTensor._tensordot(res, t[1], axes=([3,4],[0,1]))
        for i in range(2, norb-1):
            res = SparseTensor._tensordot(res, t[i+1], axes=([3],[0]))
            res = SparseTensor._tensordot(res, t[i], axes=([3,4],[0,1]))

        # Phase Factor of moving the last to first
        t2 = mps.copy().tensors
        t2[norb-1].blocks[1] *= -1**(nelec-1)
        t2[norb-1].blocks[2] *= -1**(nelec-1)

        res = SparseTensor._tensordot(res, t2[norb-1], axes=([4,1,3],[0,1,2]))
        return res.blocks[0].reshape(-1)[0]

    # multi-mps

    chars = []

    for i in range(nroots):
        theket = driver.split_mps(ket, iroot=i, tag="EXT-{}".format(i+1))
        dasket = driver.adjust_mps(theket, dot=1)[0]
        pyket = MPSTools.from_block2(dasket)
        chars.append(calc_trans_mps(pyket))

    chars = np.array(chars)

    np.savetxt("chars-{}-{}-{}.txt".format(L, U, nroots), chars)

if __name__ == '__main__':
    """
    Usage: (for L=50, U=2, 60 states)
    python exact-klabel.py 50 2 60
    """
    try:
        l, u, n = sys.argv[1:4]
        l = eval(l); u = eval(u); n = eval(n)
        get_klabel(l,u,n)
    except Exception as e:
        print(sys.argv)
        print(e)