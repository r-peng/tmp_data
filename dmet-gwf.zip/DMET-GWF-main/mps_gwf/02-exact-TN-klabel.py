#Block2
import numpy as np
from pyscf.scf import hf
from pyblock2.driver.core import DMRGDriver, SymmetryTypes
from pyblock3.block2.io import MPSTools, MPOTools
from pyblock3.algebra.core import SparseTensor, SubTensor
import sys

def exact_TN(L, U, n_threads):
    N = L
    TWOSZ = 0

    driver = DMRGDriver(scratch="./tmp", symm_type=SymmetryTypes.SZ, n_threads=n_threads)
    driver.initialize_system(n_sites=L, n_elec=N, spin=TWOSZ)

    t = 1

    b = driver.expr_builder()

    # hopping term
    b.add_term("cd", 
        np.array([[[i, (i+1)%L], [(i+1)%L, i]] for i in range(L)]).flatten(),
        [-t] * 2 * (L))
    b.add_term("CD",
        np.array([[[i, (i+1)%L], [(i+1)%L, i]] for i in range(L)]).flatten(),
        [-t] * 2 * (L))

    # onsite term
    b.add_term("cdCD",
        np.array([[i, ] * 4 for i in range(L)]).flatten(),
        [U] * L)

    mpo = driver.get_mpo(b.finalize(), iprint=2, add_ident=False)

    try: ket = driver.load_mps(tag="KET-{}-{}".format(L,U))
    except: 

        ket = driver.get_random_mps(tag="KET", bond_dim=400, nroots=1)

        def run_dmrg(driver, mpo):
            bond_dims = [200] * 4 + [400] * 4
            noises = [1e-4] * 4 + [1e-5] * 4 + [0]
            thrds = [1e-10] * 8
            return driver.dmrg(
                mpo,
                ket,
                n_sweeps=25,
                bond_dims=bond_dims,
                noises=noises,
                thrds=thrds,
                iprint=2,
            )

        energies = run_dmrg(driver, mpo)
    
    def calc_trans_mps(mps, mpsr, nelec=None):
        t = mps.tensors
        tr = mpsr.tensors
        norb = len(t)
        if nelec is None: nelec = norb

        res = SparseTensor._tensordot(t[0], t[1], axes=([2],[0]))
        res = SparseTensor._tensordot(res, tr[0], axes=([2],[1]))
        res = SparseTensor._tensordot(res, t[2], axes=([2],[0]))
        res = SparseTensor._tensordot(res, tr[1], axes=([3,4],[0,1]))
        for i in range(2, norb-1):
            res = SparseTensor._tensordot(res, t[i+1], axes=([3],[0]))
            res = SparseTensor._tensordot(res, tr[i], axes=([3,4],[0,1]))

        # Phase Factor
        t2 = mpsr.copy().tensors
        t2[norb-1].blocks[1] *= -1**(nelec-1)
        t2[norb-1].blocks[2] *= -1**(nelec-1)

        res = SparseTensor._tensordot(res, t2[norb-1], axes=([4,1,3],[0,1,2]))
        return res.blocks[0].reshape(-1)[0]

    mps = driver.adjust_mps(ket, dot=1)[0]
    pympo = MPOTools.from_block2(mpo.prim_mpo)

    pyket = MPSTools.from_block2(mps)
    wfnlst = [pyket]

    # the civec with the corresponding configuration
    qnlst = ((2,0), (1,1), (1,-1), (0,0))
    for i in range(L):
        for qn in qnlst:
            mps2 = pyket.copy()
            for j, block in enumerate(mps2.tensors[i].blocks):
                ql = block.q_labels
                if ql[1].n != qn[0] or ql[1].twos != qn[1]:
                    zeroblock = SubTensor(np.zeros_like(np.asarray(block)), q_labels=ql)
                    mps2.tensors[i].blocks[j] = zeroblock
            wfnlst.append(mps2)
    exact_H = np.zeros((len(wfnlst), len(wfnlst)))
    exact_S = np.zeros((len(wfnlst), len(wfnlst)))
    exact_C = np.zeros((len(wfnlst), len(wfnlst)))

    for i, wfni in enumerate(wfnlst[1:5]):
        for j, wfnj in enumerate(wfnlst[1:]):
            print(i, j)
            h = wfni @ (pympo @ wfnj)
            s = wfni @ wfnj
            c = calc_trans_mps(wfni, wfnj)
            for k in range(N):
                exact_S[(i+4*k)%(4*N)+1,(j+4*k)%(4*N)+1] += s
                exact_H[(i+4*k)%(4*N)+1,(j+4*k)%(4*N)+1] += h
                exact_C[(i+4*k)%(4*N)+1,(j+4*k)%(4*N)+1] += c

    for i, wfni in enumerate(wfnlst[1:]):
        print(i)
        s = wfnlst[0] @ wfni
        h = wfnlst[0] @ (pympo @ wfni)
        c = calc_trans_mps(wfnlst[0], wfni)
        exact_S[0,i+1] += s
        exact_S[i+1,0] += s
        exact_H[0,i+1] += h
        exact_H[i+1,0] += h
        exact_C[i+1,0] += c
        exact_C[0,i+1] += c
    
    exact_S[0,0] += wfnlst[0] @ wfnlst[0]
    exact_H[0,0] += wfnlst[0] @ (pympo @ wfnlst[0])
    exact_C[0,0] += calc_trans_mps(wfnlst[0], wfnlst[0])

    exact_H = (exact_H + exact_H.T) / 2
    exact_S = (exact_S + exact_S.T) / 2
    exact_C = (exact_C + exact_C.T) / 2

    wS_exact, vS_exact = np.linalg.eig(exact_S)
    mask = wS_exact > 1e-5
    S_proj = vS_exact.T[mask] @ (exact_S+exact_S.T)/2 @ vS_exact[:,mask]
    print(np.diag(S_proj))
    H_proj = vS_exact.T[mask] @ (exact_H+exact_H.T)/2 @ vS_exact[:,mask]

    wHp_exact, vHp_exact = hf.eig(H_proj, S_proj)   # solve in truncated area
    coeff_in_basis = vS_exact[:,mask] @ vHp_exact

    """
    char = []

    for i in range(coeff_in_basis.shape[1]):
        coeff = coeff_in_basis[:,i]
        themps = 0
        print("i")
        for j in range(coeff_in_basis.shape[0]):
            themps += coeff[j] * wfnlst[j]
        char.append(calc_trans_mps(themps, themps).real)
    """

    char = np.einsum("ik,ij,jk->k", coeff_in_basis.conj(), exact_C, coeff_in_basis)
    print(wHp_exact)
    print(np.array(char))
    np.savetxt("./results/energy-exactTN-{}-{}.txt".format(L, U), wHp_exact)
    np.savetxt("./results/char-exactTN-{}-{}.txt".format(L, U), np.array(char))

if __name__ == "__main__":
    try: 
        l, u, n_threads = sys.argv[1:4]
        l = eval(l); u = eval(l); n_threads = eval(n_threads)
        exact_TN(l, u, n_threads)
    except:
        l, u = sys.argv[1:3]
        l = eval(l); u = eval(u)
        exact_TN(l, u, n_threads=4)
