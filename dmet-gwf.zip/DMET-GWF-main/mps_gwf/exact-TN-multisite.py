#Block2
import numpy as np
from pyscf.scf import hf
from pyblock2.driver.core import DMRGDriver, SymmetryTypes
from pyblock3.block2.io import MPSTools, MPOTools
from pyblock3.algebra.core import SparseTensor, SubTensor
import sys

def gen_partial_wfn(pyket, sites):
    mps_zero = pyket.copy() # generate a sitewise-zero mps first
    for isite, site in enumerate(sites):
        for j, block in enumerate(mps_zero.tensors[site].blocks):
            ql = block.q_labels
            zeroblock = SubTensor(np.zeros_like(np.asarray(block)),
            q_labels=ql)
            mps_zero.tensors[site].blocks[j] = zeroblock
    kets = []
    qnlst = ((2,0), (1,1), (1,-1), (0,0))
    for i in range(len(qnlst)**len(sites)):
        ket = mps_zero.copy()
        isite = 0
        numconfig = i
        while isite != len(sites):
            iqn = numconfig % len(qnlst)
            n, twos = qnlst[iqn]
            numconfig = numconfig // len(qnlst)
            for j, block in enumerate(pyket.tensors[sites[isite]].blocks):
                qnj = block.q_labels[1]
                if n == qnj.n and twos == qnj.twos:
                    ket.tensors[sites[isite]].blocks[j] = block
            isite += 1

        kets.append(ket)
    return kets

def calc_trans_mps(mps, mpsr, nelec=None):
    t = mps.tensors
    tr = mpsr.tensors
    norb = len(t)
    if nelec is None: nelec = norb

    res = SparseTensor._tensordot(t[0], t[1], axes=([2],[0]))
    res = SparseTensor._tensordot(res, tr[0], axes=([2],[1]))
    res = SparseTensor._tensordot(res, t[2], axes=([2],[0]))
    res = SparseTensor._tensordot(res, tr[1], axes=([3,4],[0,1]))
    for i in range(2, norb-1):
        res = SparseTensor._tensordot(res, t[i+1], axes=([3],[0]))
        res = SparseTensor._tensordot(res, tr[i], axes=([3,4],[0,1]))

    # Phase Factor
    t2 = mpsr.copy().tensors
    t2[norb-1].blocks[1] *= -1**(nelec-1)
    t2[norb-1].blocks[2] *= -1**(nelec-1)

    res = SparseTensor._tensordot(res, t2[norb-1], axes=([4,1,3],[0,1,2]))
    return res.blocks[0].reshape(-1)[0]

def exact_TN_2site(L,U,n_threads):
    N = L
    TWOSZ = 0

    driver = DMRGDriver(scratch="./exact-TN-ket-18", symm_type=SymmetryTypes.SZ, n_threads=n_threads)
    driver.initialize_system(n_sites=L, n_elec=N, spin=TWOSZ)

    t = 1

    b = driver.expr_builder()

    # hopping term
    b.add_term("cd",
        np.array([[[i, (i+1)%L], [(i+1)%L, i]] for i in range(L)]).flatten(),
        [-t] * 2 * (L))
    b.add_term("CD",
        np.array([[[i, (i+1)%L], [(i+1)%L, i]] for i in range(L)]).flatten(),
        [-t] * 2 * (L))

    # onsite term
    b.add_term("cdCD",
        np.array([[i, ] * 4 for i in range(L)]).flatten(),
        [U] * L)

    mpo = driver.get_mpo(b.finalize(), iprint=2, add_ident=False)
    ket = driver.load_mps(tag="KET-{}-{}".format(L,U))
    mps = driver.adjust_mps(ket, dot=1)[0]
    pympo = MPOTools.from_block2(mpo.prim_mpo)
    pyket = MPSTools.from_block2(mps)

    wfnlst = [pyket]
    for i in range(L-1): wfnlst.extend(gen_partial_wfn(pyket, [i,i+1]))

    exact_H = np.zeros((16*L+1, 16*L+1))
    exact_S = np.zeros_like(exact_H)
    exact_C = np.zeros_like(exact_H)
    for i, wfni in enumerate(wfnlst[1:17]):
        for j, wfnj in enumerate(wfnlst[1:97]):
            print(i,j)
            h = wfni @ (pympo @ wfnj)
            s = wfni @ wfnj
            c = calc_trans_mps(wfni, wfnj)
            for k in range(N):
                exact_S[(i+16*k)%(16*N)+1,(j+16*k)%(16*N)+1] += s
                exact_H[(i+16*k)%(16*N)+1,(j+16*k)%(16*N)+1] += h
                exact_C[(i+16*k)%(16*N)+1,(j+16*k)%(16*N)+1] += c

                if j >= 17 and j <= 80:
                    exact_S[(j+16*k)%(16*N)+1, (i+16*k)%(16*N)+1] += s
                    exact_H[(j+16*k)%(16*N)+1, (i+16*k)%(16*N)+1] += h
                    exact_C[(j+16*k)%(16*N)+1, (i+16*k)%(16*N)+1] += c
    
    for i, wfni in enumerate(wfnlst[1:17]):
        print(i)
        s = wfnlst[0] @ wfni
        h = wfnlst[0] @ (pympo @ wfni)
        c = calc_trans_mps(wfnlst[0], wfni)
        for k in range(N):
            exact_S[0,(i+16*k)%(16*N)+1] += s
            exact_S[(i+16*k)%(16*N)+1,0] += s
            exact_H[0,(i+16*k)%(16*N)+1] += h
            exact_H[(i+16*k)%(16*N)+1,0] += h
            exact_C[0,(i+16*k)%(16*N)+1] += c
            exact_C[(i+16*k)%(16*N)+1,0] += c
    
    exact_S[0,0] += wfnlst[0] @ wfnlst[0]
    exact_H[0,0] += wfnlst[0] @ (pympo @ wfnlst[0])
    exact_C[0,0] += calc_trans_mps(wfnlst[0], wfnlst[0])

    exact_H = (exact_H + exact_H.T) / 2
    exact_S = (exact_S + exact_S.T) / 2
    exact_C = (exact_C + exact_C.T) / 2

    wS_exact, vS_exact = np.linalg.eig(exact_S)
    mask = wS_exact > 1e-5
    S_proj = vS_exact.T[mask] @ (exact_S+exact_S.T)/2 @ vS_exact[:,mask]
    print(np.diag(S_proj))
    H_proj = vS_exact.T[mask] @ (exact_H+exact_H.T)/2 @ vS_exact[:,mask]

    wHp_exact, vHp_exact = hf.eig(H_proj, S_proj)   # solve in truncated area
    coeff_in_basis = vS_exact[:,mask] @ vHp_exact

    char = np.einsum("ik,ij,jk->k", coeff_in_basis.conj(), exact_C, coeff_in_basis)
    print(wHp_exact)
    print(np.array(char))
    np.savetxt("./results/energy-exactTN2-{}-{}.txt".format(L, U), wHp_exact)
    np.savetxt("./results/char-exactTN2-{}-{}.txt".format(L, U), np.array(char))

if __name__ == "__main__":
    try: 
        l, u, n_threads = sys.argv[1:4]
        l = eval(l); u = eval(l); n_threads = eval(n_threads)
        exact_TN_2site(l, u, n_threads)
    except:
        l, u = sys.argv[1:3]
        l = eval(l); u = eval(u)
        exact_TN_2site(l, u, n_threads=4)
