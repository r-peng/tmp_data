"""
eomdp_slow.py
EOM Excited States + Democratic Partitioning

GLOSSARY

ecv: Embedding+Core+Virtural orbital basis for a specific single-impurity DMET wave function.
na: number of electrons in the impurity
nao: number of orbitals in the molecular
nocc: number of occupied electron in each spin

Expansion in Full-CI basis, so very slow.
"""

from pyscf.fci import cistring
from pyscf.fci import direct_spin1 as fci
from pyscf.scf import hf
from functools import reduce
import numpy as np

def get_ci_1imp_ecv(ci_dmet, na, nao, nocc, 
cistr_emb=None, cistr_ecv=None):
    """
    Return the FCI coeff of 1imp DMET wave function in ecv basis
    """
    if cistr_emb is None: 
        cistr_emb = list(cistring.make_strings(range(2*na), na))
    if cistr_ecv is None:
        cistr_ecv = list(cistring.make_strings(range(nao), nocc))

    nc = nocc - na

    pf = (-1) ** (nc*na)
    addon_str = (2**nc - 1) * (2**(2*na))    # 11...100...0

    civec = np.zeros((len(cistr_ecv), len(cistr_ecv)))
    
    for i in range(len(cistr_emb)):
        
        embstr_alpha = cistr_emb[i]
        ecvstr_alpha = embstr_alpha + addon_str
        # print(bin(embstr_alpha), bin(addon_str))
        idx_alpha = cistr_ecv.index(ecvstr_alpha)

        for j in range(len(cistr_emb)):

            embstr_beta = cistr_emb[j]
            ecvstr_beta = embstr_beta + addon_str
            idx_beta = cistr_ecv.index(ecvstr_beta)

            civec[idx_alpha, idx_beta] = pf * ci_dmet[i,j]

    return civec

def ci_1imp_ee_aa(ci_dmet, ovlp_ee, ovlp_cc, 
na, nocc, nao, mode="ec", 
cistr_emb=None, cistr_ecv=None, linkstr=None):
    """
    :math:`p^\dagger q | \Psi^x \rangle`, p, q are emb. 
    """

    if cistr_emb is None: 
        cistr_emb = list(cistring.make_strings(range(2*na), na))
    if cistr_ecv is None:
        cistr_ecv = list(cistring.make_strings(range(nao), nocc))
    if linkstr is None:
        linkstr = cistring.gen_linkstr_index(range(2*na), na)

    ci_1imp = np.zeros_like(ci_dmet)

    for i in range(len(cistr_emb)):
        lkstr = linkstr[i]
        for p, q, bra, sign in lkstr:
            s = ovlp_ee[p,q]
            for j in range(len(cistr_emb)):
                coef = ci_dmet[i,j]
                ci_1imp[bra,j] += s * sign * coef

    # Absorb trivial core->core part 
    if "c" in mode.lower():
        ci_1imp += ci_dmet * np.einsum("ii->", ovlp_cc)

    return get_ci_1imp_ecv(ci_1imp, na, nao, nocc, cistr_emb, cistr_ecv)

def ci_1imp_ce_aa(ci_dmet, ovlp_ce, na, nao, nocc, 
cistr_emb=None, cistr_cre=None, cistr_ecv=None, crestr=None):

    nc = nocc - na
    addon_str_full = (2**(nocc-na) - 1) * (2**(2*na))

    if cistr_emb is None: 
        cistr_emb = list(cistring.make_strings(range(2*na), na))
    if cistr_cre is None:
        cistr_cre = list(cistring.make_strings(range(2*na), na+1))
    if cistr_ecv is None:
        cistr_ecv = list(cistring.make_strings(range(nao), nocc))
    if crestr is None:
        crestr = cistring.gen_cre_str_index(range(2*na), na)

    civec = np.zeros((len(cistr_ecv), len(cistr_ecv)))

    for i in range(len(cistr_emb)):
        crstr = crestr[i]

        for p, zero, bra, sign in crstr:
            
            embstr_alpha = cistr_cre[bra]

            for j in range(len(cistr_emb)):
                coef = ci_dmet[i,j]
                embstr_beta = cistr_emb[j]
                ecvstr_beta = embstr_beta + addon_str_full
                idx_beta = cistr_ecv.index(ecvstr_beta)

                for q in range(nc):
                    s = ovlp_ce[p,q]
                    # pf = sign * (-1)**(na+nc*na+q) 
                    pf = sign * (-1)**(nc*na+q)
                    addon_str_alpha = addon_str_full - 2**(q+2*na)
                    ecvstr_alpha = embstr_alpha + addon_str_alpha
                    idx_alpha = cistr_ecv.index(ecvstr_alpha)

                    civec[idx_alpha, idx_beta] += coef * s * pf

    return civec

def ci_1imp_ev_aa(ci_dmet, ovlp_ev, na, nao, nocc, 
cistr_emb=None, cistr_des=None, cistr_ecv=None, desstr=None):

    if cistr_emb is None: 
        cistr_emb = list(cistring.make_strings(range(2*na), na))
    if cistr_des is None:
        cistr_des = list(cistring.make_strings(range(2*na), na-1))
    if cistr_ecv is None:
        cistr_ecv = list(cistring.make_strings(range(nao), nocc))
    if desstr is None:
        desstr = cistring.gen_des_str_index(range(2*na), na)

    civec = np.zeros((len(cistr_ecv), len(cistr_ecv)))
    addon_str_full = (2**(nocc-na) - 1) * (2**(2*na))

    nc = nocc - na
    nv = nao - nocc - na

    for i in range(len(cistr_emb)):
        destr = desstr[i]

        for zero, q, bra, sign in destr:

            embstr_alpha = cistr_des[bra]

            for j in range(len(cistr_emb)):
                coef = ci_dmet[i,j]
                embstr_beta = cistr_emb[j]
                ecvstr_beta = embstr_beta + addon_str_full
                idx_beta = cistr_ecv.index(ecvstr_beta)

                for p in range(nv):
                    s = ovlp_ev[p,q]

                    # pf = sign * (-1)**(nocc-1+na*(nocc-na))
                    pf = sign * (-1)**(nc+na*(nocc-na))

                    addon_str_alpha = addon_str_full + 2**(p+nocc+na)
                    ecvstr_alpha = embstr_alpha + addon_str_alpha
                    idx_alpha = cistr_ecv.index(ecvstr_alpha)

                    civec[idx_alpha, idx_beta] += coef * s * pf
    
    return civec

def ci_1imp_cv_aa(ci_dmet, ovlp_cv, na, nao, nocc, 
cistr_emb=None, cistr_ecv=None):
    
    nc = nocc - na
    nv = nao - nocc - na

    if cistr_emb is None: 
        cistr_emb = list(cistring.make_strings(range(2*na), na))
    if cistr_ecv is None:
        cistr_ecv = list(cistring.make_strings(range(nao), nocc))

    addon_str_full = (2**(nocc-na) - 1) * (2**(2*na))
    civec = np.zeros((len(cistr_ecv), len(cistr_ecv)))

    for j in range(len(cistr_emb)):
        
        embstr_beta = cistr_emb[j]
        ecvstr_beta = embstr_beta + addon_str_full
        idx_beta = cistr_ecv.index(ecvstr_beta)

        for i in range(len(cistr_emb)):

            embstr_alpha = cistr_emb[i]
            coef = ci_dmet[i,j]

            for q in range(nc):

                pf = (-1)**(nc*na+nc-1+q)

                for p in range(nv):
                    
                    s = ovlp_cv[p,q]
                    addon_str = addon_str_full - 2**(2*na+q) + 2**(2*na+nc+p)
                    ecvstr_alpha = embstr_alpha + addon_str
                    idx_alpha = cistr_ecv.index(ecvstr_alpha)
                    civec[idx_alpha, idx_beta] += coef * s * pf

    return civec


def gen_wfn_lst_1imp(cem, ci_dmet, 
nocc, nvir, na, nao, mode="ecv", 
cistr_emb=None, cistr_ecv=None, cistr_des=None, 
cistr_cre=None, desstr=None, crestr=None, linkstr=None):
    """
    Return (2*nocc*nvir + 1)
    """

    if cistr_emb is None:
        cistr_emb = list(cistring.make_strings(range(2*na), na))
    if cistr_ecv is None:
        cistr_ecv = list(cistring.make_strings(range(nao), nocc))
    if cistr_des is None:
        cistr_des = list(cistring.make_strings(range(2*na), na-1))
    if cistr_cre is None:
        cistr_cre = list(cistring.make_strings(range(2*na), na+1))
    if desstr is None:
        desstr = cistring.gen_des_str_index(range(2*na), na)
    if crestr is None:
        crestr = cistring.gen_cre_str_index(range(2*na), na)
    if linkstr is None:
        linkstr = cistring.gen_linkstr_index(range(2*na), na)

    wfnlst = [get_ci_1imp_ecv(ci_dmet, na, nao, nocc, cistr_emb, cistr_ecv)]

    for i in range(nocc):
        for a in range(nvir):
            ovlp_ecv = np.einsum("p,q->pq", cem[:,a+nocc], cem[:,i].conj())

            ovlp_ee = ovlp_ecv[:2*na,:2*na]                 # e <- e
            ovlp_cc = ovlp_ecv[2*na:nocc+na,2*na:nocc+na]   # c <- c
            ovlp_ce = ovlp_ecv[:2*na,2*na:nocc+na]          # e <- c
            ovlp_ev = ovlp_ecv[nocc+na:,:2*na]              # v <- e
            ovlp_cv = ovlp_ecv[nocc+na:,2*na:nocc+na]       # v <- c

            civec_alpha = 0
            civec_beta = 0

            if "e" in mode.lower():
                civec_alpha += ci_1imp_ee_aa(ci_dmet, ovlp_ee, ovlp_cc, 
                na, nocc, nao, mode, cistr_emb, cistr_ecv, linkstr)
                civec_beta += ci_1imp_ee_aa(ci_dmet.T, ovlp_ee, ovlp_cc, 
                na, nocc, nao, mode, cistr_emb, cistr_ecv, linkstr).T
                
            if "c" in mode.lower():
                civec_alpha += ci_1imp_ce_aa(ci_dmet, ovlp_ce, 
                na, nao, nocc, cistr_emb, cistr_cre, cistr_ecv, crestr)
                civec_beta += ci_1imp_ce_aa(ci_dmet.T, ovlp_ce, 
                na, nao, nocc, cistr_emb, cistr_cre, cistr_ecv, crestr).T

            if "v" in mode.lower():
                civec_alpha += ci_1imp_ev_aa(ci_dmet, ovlp_ev, 
                na, nao,nocc, cistr_emb, cistr_des, cistr_ecv, desstr)
                civec_alpha += ci_1imp_cv_aa(ci_dmet, ovlp_cv, 
                na, nao, nocc, cistr_emb, cistr_ecv)
                civec_beta += ci_1imp_ev_aa(ci_dmet.T, ovlp_ev, 
                na, nao,nocc, cistr_emb, cistr_des, cistr_ecv, desstr).T
                civec_beta += ci_1imp_cv_aa(ci_dmet.T, ovlp_cv, 
                na, nao, nocc, cistr_emb, cistr_ecv).T

            wfnlst.append(civec_alpha)
            wfnlst.append(civec_beta)

    return wfnlst

def hs_1imp(wfnlst, na, nocc, nvir, nao, h1e, eri, with_ssq=False):
    """
    Return <L^x|H|R^x> and <L^x|R^x> for single imp
    """

    h = np.zeros((2*nocc*nvir+1, 2*nocc*nvir+1))
    ovlp = np.zeros((2*nocc*nvir+1, 2*nocc*nvir+1))
    ssq = np.zeros((2*nocc*nvir+1, 2*nocc*nvir+1))

    for i in range(2*nocc*nvir+1):

        cibra = wfnlst[i]

        for j in range(2*nocc*nvir+1):

            ciket = wfnlst[j]

            ovlp[i,j] += np.dot(cibra.reshape(-1).conj(), ciket.reshape(-1))    # ovlp

            if not with_ssq:
                rdm1, rdm2 = fci.trans_rdm12(cibra, ciket, nao, (nocc,nocc))

            else: 
                rdm1s, rdm2s= fci.trans_rdm12s(cibra, ciket, nao, (nocc,nocc), reorder=True)

                rdm1a, rdm1b = rdm1s
                rdm2aa, rdm2ab, rdm2ba, rdm2bb = rdm2s

                rdm1 = rdm1a + rdm1b
                rdm2 = rdm2aa + rdm2ab + rdm2ba + rdm2bb

            # 1e Hamiltonian
            h[i,j] += 1. * (
                  np.einsum("ij,ij->", h1e[:na,:], rdm1[:na,:])  
                #+ np.einsum("ij,ij->", h1e[:,:na], rdm1[:,:na])
            )

            # 2e Hamiltonian
            h[i,j] += .5 * (
                  np.einsum("ijkl,ijkl->", eri[:na,:,:,:], rdm2[:na,:,:,:])
                #+ np.einsum("ijkl,ijkl->", eri[:,:na,:,:], rdm2[:,:na,:,:])
                #+ np.einsum("ijkl,ijkl->", eri[:,:,:na,:], rdm2[:,:,:na,:])
                #+ np.einsum("ijkl,ijkl->", eri[:,:,:,:na], rdm2[:,:,:,:na])
            )
            
            if with_ssq: 
                eri_s2 = np.zeros_like(eri)
                for i in range(nao):
                    for j in range(nao):
                        eri_s2[i,j,j,i] = -1.

                ssq[i,j] += np.einsum("ii->", rdm1b[:na,:na]) + np.einsum("ijkl,ijkl->", eri_s2[:na,:,:,:], rdm2ba[:na,:,:,:])

    if with_ssq: return h, ovlp, ssq
    else: return h, ovlp

def calc_ssq(wfnlst, na, nocc, nvir, nao):
    ssq = np.zeros((2*nocc*nvir+1, 2*nocc*nvir+1))

    for i in range(2*nocc*nvir+1):

        cibra = wfnlst[i]

        for j in range(2*nocc*nvir+1):

            ciket = wfnlst[j]

            rdm1s, rdm2s= fci.trans_rdm12s(cibra, ciket, nao, (nocc,nocc), reorder=True)

            rdm1a, rdm1b = rdm1s
            rdm2aa, rdm2ab, rdm2ba, rdm2bb = rdm2s

            eri_s2 = np.zeros((nao, nao, nao, nao))
            for k in range(nao):
                for l in range(nao):
                    eri_s2[k,l,l,k] = -1.

            ssq[i,j] += np.einsum("ii->", rdm1b[:na,:na]) + np.einsum("ijkl,ijkl->", eri_s2[:na,:,:,:], rdm2ba[:na,:,:,:])
            
    return ssq

def eomdp_kernel(dmet_obj, mode="ecv"):

    cam = dmet_obj._scf.mo_coeff
    mol = dmet_obj._scf.mol

    nao = mol.nao
    nocc = mol.nelec[0]
    nvir = nao - nocc
    h1e_ao = dmet_obj._scf.get_hcore()

    h   = np.zeros((2*nocc*nvir+1, 2*nocc*nvir+1))
    ovlp= np.zeros((2*nocc*nvir+1, 2*nocc*nvir+1))
    ssq = np.zeros((2*nocc*nvir+1, 2*nocc*nvir+1))
    nx = sum(dmet_obj.sym_factor)   # number of impurity

    for sym_idx in range(len(dmet_obj.sym_factor)):

        sym_factor = dmet_obj.sym_factor[sym_idx]
        solver = dmet_obj.dmets[sym_idx]
        ci_dmet = solver.fci_coeff
        na = len(dmet_obj.fragments[sym_idx][0])
        cae = solver.get_ecv_coeff()
        cem = np.dot(np.linalg.inv(cae), cam)
        wfnlst = gen_wfn_lst_1imp(cem, ci_dmet, nocc, nvir, na, nao, mode)
        ovlp_factor = sym_factor / nx
        h1e = np.einsum("mj,mn,nk->jk", cae.conj(), h1e_ao, cae)
        eri = solver.get_ecv_eri()
        hx, sx = hs_1imp(wfnlst, na, nocc, nvir, nao, h1e, eri)
        ssqx = calc_ssq(wfnlst, na, nocc, nvir, nao)
        h += hx * sym_factor
        ovlp += sx * ovlp_factor

        ssq += ssqx * sym_factor

    u, sing, v = np.linalg.svd(ovlp)
    print(sing)
    
    e, c = hf.eig(h, ovlp)

    

    print("Final energy result: ")
    print(e + dmet_obj.energy_nuc)
    S_sq = np.einsum("mj,mn,nj->j", c, ssq, c)
    print("Final S^2 result:")
    print(S_sq)
    
    return e + dmet_obj.energy_nuc, S_sq
