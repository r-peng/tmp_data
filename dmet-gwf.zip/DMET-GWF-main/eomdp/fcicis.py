from pyscf.fci import cistring
import numpy as np

def get_fci_cis_wfns(ci0, nocc, nvir):

    link_index = cistring.gen_linkstr_index(range(nocc+nvir), nocc)

    nci = cistring.num_strings(nocc+nvir, nocc)
    wfns_alpha = np.zeros((nocc, nvir, nci, nci))
    wfns_beta  = np.zeros((nocc, nvir, nci, nci))

    for str0, tab in enumerate(link_index):
        for cre, des, str1, sign in tab[nocc:]:
            if des in range(nocc) and cre in range(nocc,nocc+nvir):
                wfns_alpha[des,cre-nocc,str1,:] += sign * ci0[str0,:]
                wfns_beta[des,cre-nocc,:,str1] +=  sign * ci0[:,str0]

    wfnlst = [ci0]

    for i in range(nocc):
        for a in range(nvir):
            wfnlst.append(wfns_alpha[i,a])
            wfnlst.append(wfns_beta[i,a])
    
    return wfnlst

def get_fciao_cis_wfns(ci0, nocc, nvir, mo_coeff):

    link_index = cistring.gen_linkstr_index(range(nocc+nvir), nocc)
    nao = nocc + nvir
    nci = cistring.num_strings(nao, nocc)

    wfns_ao_alpha = np.zeros((nao, nao, nci, nci))
    wfns_ao_beta  = np.zeros((nao, nao, nci, nci))

    for str0, tab in enumerate(link_index):
        for cre, des, str1, sign in tab:    # 
            wfns_ao_alpha[des,cre,str1,:] += sign * ci0[str0,:]
            wfns_ao_beta[des,cre,:,str1] +=  sign * ci0[:,str0]

    wfnlst = [ci0]
    for i in range(nocc):
        for a in range(nvir):
            wfnlst.append(np.einsum("n,m,mnpq->pq", mo_coeff[:,a+nocc], mo_coeff[:,i].conj(), wfns_ao_alpha))
            wfnlst.append(np.einsum("n,m,mnpq->pq", mo_coeff[:,a+nocc], mo_coeff[:,i].conj(), wfns_ao_beta))
    return wfnlst

def get_fciao_cisd_wfns(ci0, nocc, nvir, mo_coeff):

    link_index = cistring.gen_linkstr_index(range(nocc+nvir), nocc)
    nao = norb = nocc + nvir
    nci = cistring.num_strings(nao, nocc)

    wfnlst = [ci0]

    wfns_ao_alpha = np.zeros((nao, nao, nci, nci))
    wfns_ao_beta  = np.zeros((nao, nao, nci, nci))

    for str0, tab in enumerate(link_index):
        for cre, des, str1, sign in tab:    # 
            wfns_ao_alpha[des,cre,str1,:] += sign * ci0[str0,:]
            wfns_ao_beta[des,cre,:,str1] +=  sign * ci0[:,str0]

    for i in range(nocc):
        for a in range(nvir):
            wfnlst.append(np.einsum("n,m,mnpq->pq", mo_coeff[:,a+nocc], mo_coeff[:,i].conj(), wfns_ao_alpha))
            wfnlst.append(np.einsum("n,m,mnpq->pq", mo_coeff[:,a+nocc], mo_coeff[:,i].conj(), wfns_ao_beta))

    wfns_ao_aa = np.zeros((nao, nao, nao, nao, nci, nci))
    wfns_ao_bb = np.zeros((nao, nao, nao, nao, nci, nci))
    wfns_ao_ab = np.zeros((nao, nao, nao, nao, nci, nci))


    for str0, tab in enumerate(link_index):
        for cre, des, str1, sign in tab:    #
            for str0b, tabb in enumerate(link_index):
                for cre2, des2, str2, sign2 in tabb:
                    wfns_ao_ab[des2,cre2,des,cre,str1,str2] += ci0[str0,str0b] * sign * sign2
                
            for cre3, des3, str3, sign3 in link_index[str1]:
                wfns_ao_aa[des3,cre3,des,cre,str3,:] += ci0[str0,:] * sign * sign3 
                wfns_ao_bb[des3,cre3,des,cre,:,str3] += ci0[:,str0] * sign * sign3

    for i in range(nocc):
        for a in range(nvir):
            for j in range(nocc):
                for b in range(nvir):

                    wfnlst.append(np.einsum("n,m,r,s,mnsrpq->pq", mo_coeff[:,a+nocc], mo_coeff[:,i].conj(), mo_coeff[:,b+nocc], mo_coeff[:,j].conj(), wfns_ao_aa))
                    wfnlst.append(np.einsum("n,m,r,s,mnsrpq->pq", mo_coeff[:,a+nocc], mo_coeff[:,i].conj(), mo_coeff[:,b+nocc], mo_coeff[:,j].conj(), wfns_ao_bb))
                    wfnlst.append(np.einsum("n,m,r,s,mnsrpq->pq", mo_coeff[:,a+nocc], mo_coeff[:,i].conj(), mo_coeff[:,b+nocc], mo_coeff[:,j].conj(), wfns_ao_ab))

    return wfnlst

def get_fciao_cisd_aabb_wfns(ci0, nocc, nvir, mo_coeff):
    link_index = cistring.gen_linkstr_index(range(nocc+nvir), nocc)
    nao = norb = nocc + nvir
    nci = cistring.num_strings(nao, nocc)

    wfnlst = [ci0]

    wfns_ao_alpha = np.zeros((nao, nao, nci, nci))
    wfns_ao_beta  = np.zeros((nao, nao, nci, nci))

    for str0, tab in enumerate(link_index):
        for cre, des, str1, sign in tab:    # 
            wfns_ao_alpha[des,cre,str1,:] += sign * ci0[str0,:]
            wfns_ao_beta[des,cre,:,str1] +=  sign * ci0[:,str0]

    for i in range(nocc):
        for a in range(nvir):
            wfnlst.append(np.einsum("n,m,mnpq->pq", mo_coeff[:,a+nocc], mo_coeff[:,i].conj(), wfns_ao_alpha))
            wfnlst.append(np.einsum("n,m,mnpq->pq", mo_coeff[:,a+nocc], mo_coeff[:,i].conj(), wfns_ao_beta))

    wfns_ao_ab = np.zeros((nao, nao, nao, nao, nci, nci))

    for str0, tab in enumerate(link_index):
        for cre, des, str1, sign in tab:    #
            for str0b, tabb in enumerate(link_index):
                for cre2, des2, str2, sign2 in tabb:
                    wfns_ao_ab[des2,cre2,des,cre,str1,str2] += ci0[str0,str0b] * sign * sign2

    for i in range(nocc):
        for a in range(nvir):
            for j in range(nocc):
                for b in range(nvir):
                    wfnlst.append(np.einsum("n,m,r,s,mnsrpq->pq", mo_coeff[:,a+nocc], mo_coeff[:,i].conj(), mo_coeff[:,b+nocc], mo_coeff[:,j].conj(), wfns_ao_ab))

    return wfnlst