from pyscf.fci import cistring
import numpy as np

# For RDM3: the sequence is p^\dagger q r^\dagger s t^\dagger u

def make_rdm3_aaa(civec, norb, nelec, link_str=None):

    neleca, nelecb = nelec

    if link_str is None:
        linkstr_alpha = cistring.gen_linkstr_index(range(norb), neleca)
        linkstr_beta = cistring.gen_linkstr_index(range(norb), nelecb)

    else:
        linkstr_alpha, linkstr_beta = link_str

    dm = np.zeros((norb, norb, norb, norb, norb, norb))

    for str0, tab in enumerate(linkstr_alpha):

        cir = civec[str0,:]
        
        for t, u, str1, sign1 in tab:
            
            for r, s, str2, sign2 in linkstr_alpha[str1]:

                for p, q, str3, sign3 in linkstr_alpha[str2]:

                    sign = sign1 * sign2 * sign3

                    cil = civec[str3,:]

                    dm[p,q,r,s,t,u] += sign * np.einsum("i,i->", cil.conj(), cir) 

    return dm

def make_rdm3_bbb(civec, norb, nelec, link_str=None):
    # p^\dagger q r^\dagger s t^\dagger u
    neleca, nelecb = nelec

    if link_str is None:
        linkstr_alpha = cistring.gen_linkstr_index(range(norb), neleca)
        linkstr_beta = cistring.gen_linkstr_index(range(norb), nelecb)

    else:
        linkstr_alpha, linkstr_beta = link_str

    nelec_t = (nelecb, neleca)

    linkstr_t = (linkstr_beta, linkstr_alpha)

    return make_rdm3_aaa(civec.T, norb, nelec_t, linkstr_t)

def make_rdm3_abb(civec, norb, nelec, link_str=None):
    neleca, nelecb = nelec

    if link_str is None:
        linkstr_alpha = cistring.gen_linkstr_index(range(norb), neleca)
        linkstr_beta = cistring.gen_linkstr_index(range(norb), nelecb)

    else:
        linkstr_alpha, linkstr_beta = link_str

    dm = np.zeros((norb, norb, norb, norb, norb, norb))

    for str0l, tab in enumerate(linkstr_alpha):

        for q, p, str1l, sign1l in tab:   # str1: <p^\dagger q

            for str0r, tabr in enumerate(linkstr_beta):

                cir = civec[str1l,str0r]

                for t, u, str1r, sign1r in tabr:

                    for r, s, str2r, sign2r in linkstr_beta[str1r]:

                        cil = civec[str0l, str2r]

                        pf = sign1l * sign1r * sign2r
                        dm[p,q,r,s,t,u] += cil.conj() * cir * pf

    return dm

def make_rdm3_baa(civec, norb, nelec, link_str=None):

    neleca, nelecb = nelec

    if link_str is None:
        linkstr_alpha = cistring.gen_linkstr_index(range(norb), neleca)
        linkstr_beta = cistring.gen_linkstr_index(range(norb), nelecb)

    else:
        linkstr_alpha, linkstr_beta = link_str

    nelec_t = (nelecb, neleca)

    linkstr_t = (linkstr_beta, linkstr_alpha)

    return make_rdm3_abb(civec.T, norb, nelec_t, linkstr_t)

def make_rdm3s_spin1(civec, norb, nelec, link_str=None):
    
    # rdm3 that are not ordered (p^\dagger q r^\dagger s t^\dagger u)

    aaa = make_rdm3_aaa(civec, norb, nelec, link_str)
    abb = make_rdm3_abb(civec, norb, nelec, link_str)
    baa = make_rdm3_baa(civec, norb, nelec, link_str)
    bbb = make_rdm3_bbb(civec, norb, nelec, link_str)

    return (aaa, abb, baa, bbb)
