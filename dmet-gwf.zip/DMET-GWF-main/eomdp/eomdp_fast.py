import numpy as np

# (a, b) (aa, ab, bb) (aaa, abb, baa, bbb)
# not reordered 

def calc_s_tt_s(slpack, srpack, dmpack, na, nocc, norb):

    slee, slce, slev, slcv = slpack
    sree, srce, srev, srcv = srpack

    dmb, dmab, dmbaa = dmpack

    dmab_cdcd = dmab
    dmab_dccd = - dmab_cdcd.transpose(1,0,2,3)
    for i in range(2*na): dmab_dccd[i,i,:,:] += dmb

    res_a_bb_a = np.zeros((2*na, norb))
    
    ix_ee = np.ix_(range(2*na), range(2*na))
    ix_ec = np.ix_(range(2*na), range(2*na,nocc+na))
    ix_ev = np.ix_(range(2*na), range(nocc+na,norb))

    res_a_bb_a[ix_ee] += np.einsum("PQ,RS,pqQPRS->pq", slee, sree, dmbaa)     # <EE|EE|EE>
    res_a_bb_a[ix_ee] += np.einsum("PR,QR,PQpq->pq",   slce, srce, dmab_dccd) # <CE|EE|CE>
    res_a_bb_a[ix_ee] += np.einsum("RP,RQ,PQpq->pq",   slev, srev, dmab)      # <EV|EE|EV>
    res_a_bb_a[ix_ee] += np.einsum("PQ,PQ->", slcv, srcv) * dmb               # <CV|EE|CV>

    return res_a_bb_a

def calc_s_ss_s(slpack, srpack, dmpack, na, nocc, norb):

    slee, slce, slev, slcv = slpack
    sree, srce, srev, srcv = srpack

    dm0, dma, dmaa, dmaaa = dmpack

    dmaa_cdcd = dmaa

    dma_dc = - dma.T
    for i in range(2*na): dma_dc[i,i] += dm0

    dmaa_dccd = - dmaa_cdcd.transpose(1,0,2,3)
    for i in range(2*na): dmaa_dccd[i,i,:,:] += dma

    dmaa_dcdc = - dmaa_dccd.transpose(0,1,3,2)
    for i in range(2*na): dmaa_dcdc[:,:,i,i] += dma_dc

    dmaa_ccdd = - dmaa_cdcd.transpose(0,2,1,3)
    for i in range(2*na): dmaa_ccdd[:,i,i,:] += dma

    res_a_aa_a = np.zeros((2*na, norb))

    ix_ee = np.ix_(range(2*na), range(2*na))
    ix_ec = np.ix_(range(2*na), range(2*na,nocc+na))
    ix_ev = np.ix_(range(2*na), range(nocc+na,norb))

    res_a_aa_a[ix_ee] += np.einsum("PQ,RS,QPpqRS->pq", slee, sree, dmaaa)     # <EE|EE|EE>
    res_a_aa_a[ix_ev] += np.einsum("PQ,qR,QPpR->pq",   slee, srev, dmaa)      # <EE|EV|EV>
    res_a_aa_a[ix_ec] += np.einsum("Pq,QR,PpQR->pq",   slce, sree, dmaa_dccd) # <CE|EC|EE>
    res_a_aa_a[ix_ee] += np.einsum("PR,QR,PpqQ->pq",   slce, srce, dmaa_dcdc) # <CE|EE|CE>
    res_a_aa_a[ix_ev] += np.einsum("PQ,qQ,Pp->pq",     slce, srcv, dma_dc)    # <CE|EV|CV>
    res_a_aa_a[ix_ee] += np.einsum("QP,SR->", slcv, slcv) * dma                 # <CV|EE|CV>
    res_a_aa_a[ix_ec] -= np.einsum("Qq,QP,pP->pq",     slcv, srev, dma)       # <CV|EC|EV>
    res_a_aa_a[ix_ee] += np.einsum("RP,SQ,PpqQ->pq",   slev, srev, dmaa_ccdd) # <EV|EE|EV>

    return res_a_aa_a

def build_rdm1(sl, sr, dmpack, na, nocc, norb):

    nc = nocc - na
    nv = norb - nc - na

    sl = sl.conj()
    
    srcc = sr[2*na:nocc+na,2*na:nocc+na]   # c <- c
    sree = sr[:2*na,:2*na] + np.eye(2*na) * np.einsum("ii->", srcc) / na
    srce = sr[:2*na,2*na:nocc+na]          # e <- c
    srev = sr[nocc+na:,:2*na]              # v <- e
    srcv = sr[nocc+na:,2*na:nocc+na]       # v <- c

    slcc = sl[2*na:nocc+na,2*na:nocc+na]   # c <- c
    slee = sl[:2*na,:2*na] + np.eye(2*na) * np.einsum("ii->", slcc) / na
    slce = sl[:2*na,2*na:nocc+na]          # e <- c
    slev = sl[nocc+na:,:2*na]              # v <- e
    slcv = sl[nocc+na:,2*na:nocc+na]       # v <- c

    slpack = (slee, slce, slev, slcv)
    srpack = (sree, srce, srev, srcv)

    rdm0, rdm1, rdm2, rdm3 = dmpack
    dma, dmb = rdm1
    dmaa, dmab, dmbb = rdm2
    dmba = dmab.transpose(2,3,0,1)
    dmaaa, dmabb, dmbaa, dmbbb = rdm3

    dmab_cdcd = dmab
    dmab_dccd = - dmab_cdcd.transpose(1,0,2,3)
    for i in range(2*na): dmab_dccd[i,i,:,:] += dmb

    dmba_cdcd = dmba
    dmba_dccd = - dmba_cdcd.transpose(1,0,2,3)
    for i in range(2*na): dmba_dccd[i,i,:,:] += dma

    res_a_aa_a = calc_s_ss_s(slpack, srpack, (rdm0, dma, dmaa, dmaaa), na, nocc, norb)
    res_b_bb_b = calc_s_ss_s(slpack, srpack, (rdm0, dmb, dmbb, dmbbb), na, nocc, norb)

    res_a_bb_a = calc_s_tt_s(slpack, srpack, (dmb, dmab, dmbaa), na, nocc, norb)
    res_b_aa_b = calc_s_tt_s(slpack, srpack, (dma, dmba, dmabb), na, nocc, norb)

    res_a_aa_b = res_a_bb_b = res_b_aa_a = res_b_bb_a = np.zeros((2*na, norb))

    ix_ee = np.ix_(range(2*na), range(2*na))
    ix_ec = np.ix_(range(2*na), range(2*na,nocc+na))
    ix_ev = np.ix_(range(2*na), range(nocc+na,norb))

    res_a_aa_b[ix_ee] += np.einsum("PQ,RS,RSQPpq->pq", slee, sree, dmbaa)     # <EE|EE|EE>
    res_a_aa_b[ix_ec] += np.einsum("Pq,RS,PpRS->pq",   slce, sree, dmab_dccd) # <CE|EC|EE>
    res_b_bb_a[ix_ee] += np.einsum("PQ,RS,RSQPpq->pq", slee, sree, dmabb)
    res_b_bb_a[ix_ec] += np.einsum("Pq,RS,PpRS->pq",   slce, sree, dmba_dccd)

    res_b_aa_a[ix_ee] += np.einsum("PQ,RS,QPpqRS->pq", slee, sree, dmbaa)     # <EE|EE|EE>
    res_b_aa_a[ix_ev] += np.einsum("PQ,qR,QPpR->pq",   slee, srev, dmba)      # <EE|EV|EV>
    res_a_bb_b[ix_ee] += np.einsum("PQ,RS,QPpqRS->pq", slee, sree, dmabb)     
    res_a_bb_b[ix_ev] += np.einsum("PQ,qR,QPpR->pq",   slee, srev, dmab)

    return ((res_a_aa_a, res_a_bb_a), (res_a_aa_b, res_a_bb_b),
    (res_b_aa_a, res_b_bb_a), (res_b_aa_b, res_b_bb_b))
