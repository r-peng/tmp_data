# DMET-GWF

Starting-up project of Graduate

Can we write a wave function for DMET?

Theoretical Connection between DMET, Gutzwiller Wave-function, Tensor Network, and else?

> `dmet/` A simple implementation of DMET
>
> `cpskit/` Code for construction of Correlation Product States
