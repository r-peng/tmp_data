from pyscf.fci import cistring
import numpy as np

def get_str_idx(na, abdict=None):
    if abdict is None: abdict = [2**na-i-1 for i in range(2**na)]

    str_fb      = cistring.make_strings(range(2*na), na)
    idx_fb      = dict(zip(str_fb, np.arange(len(str_fb))))
    str_fs = [cistring.make_strings(range(na), n) for n in range(na+1)]

    str_idx = [] # (ki, jk, ji)
    for n in range(na+1):   
        str_lst_n = str_fs[n]
        for ai in str_lst_n:    # :math:`| \alpha_i^\beta \rangle`
            bi = abdict[ai]     # :math:`| \beta_i^\beta \rangle`
            for ak in str_lst_n:
                bk = abdict[ak]
                ki = idx_fb[(2**na)*bi + ak]  # :math: `| \alpha_k \beta_i \rangle`
                for aj in str_lst_n:
                    jk = idx_fb[(2**na)*bk + aj]  
                    ji = idx_fb[(2**na)*bi + aj]
                    str_idx.append((ki, jk, ji))

    return str_idx

def gaag_info(na, proj, coef_dmet, beta_stridx=None, abdict=None):
    r'''
    
    :math:`\hat G^\dagger_q \hat a^\alpha_q \hat G_q | \Phi \rangle`

    na: number of fragment orbitals

    abdict: :math:`|\alpha_i \rangle \to | \beta_i \rangle`

    Return: Eq. 11 in note
    '''

    if abdict is None: abdict = [2**na-i-1 for i in range(2**na)]

    str_fb_hole = cistring.make_strings(range(2*na), na-1)
    str_fb      = cistring.make_strings(range(2*na), na)
    idx_fb_hole = dict(zip(str_fb_hole, np.arange(len(str_fb_hole))))
    idx_fb      = dict(zip(str_fb, np.arange(len(str_fb))))

    str_fs = [cistring.make_strings(range(na), n) for n in range(na+1)]
    
    res = np.zeros((len(str_fb_hole), len(str_fb), na))

    if beta_stridx is None: beta_stridx = get_str_idx(na, abdict)

    # alpha(spin)
    for n in range(1, na+1):

        des_idx = cistring.gen_des_str_index(range(na), n)
        strlst_f      = str_fs[n]
        strlst_f_hole = str_fs[n-1]

        for j in range(len(des_idx)):
            des_idx_ja = des_idx[j]
            aj = strlst_f[j]            # :math:`| \alpha_j^\alpha \rangle`

            for info in des_idx_ja:
                q, l, sgn = info[1:]
                al = strlst_f_hole[l]   # :math:`| \alpha_l^\alpha \rangle`

                for ak in strlst_f_hole:
                    bk = abdict[ak]
                    lka = idx_fb[(2**na)*bk + al]
                    for ai in strlst_f:
                        bi = abdict[ai]
                        kia = idx_fb_hole[(2**na)*bi + ak]
                        jia = idx_fb[(2**na)*bi + aj]
                        for kib, jkb, jib in beta_stridx:
                            res[kia, kib, q] += proj[lka, jkb] \
                            * coef_dmet[jia, jib] * sgn * (-1) ** n

    return res

def gabg_info(na, proj, coef_dmet, beta_stridx=None, abdict=None):
    r'''
    :math:`\hat G^\dagger_q \hat a^\beta_q \hat G_q | \Phi \rangle`
    '''
    resba = gaag_info(na, proj.T, coef_dmet.T, beta_stridx, abdict)
    return resba.transpose((1,0,2))

def gg_info(na, proj, coef_dmet, stridx=None, abdict=None):

    if abdict is None: abdict = [2**na-i-1 for i in range(2**na)]

    str_fb = cistring.make_strings(range(2*na), na)
    idx_fb = dict(zip(str_fb, np.arange(len(str_fb))))
    str_fs = [cistring.make_strings(range(na), n) for n in range(na+1)]
    res    = np.zeros((len(str_fb), len(str_fb)))

    if stridx is None: stridx = get_str_idx(na)

    for kib, jkb, jib in stridx:
        for kia, jka, jia in stridx:
            res[kia, kib] += coef_dmet[jia, jib] * proj[jka, jkb].conj()

    return res

def make_dm_odiag(fl, fr, mocl, mocr, na, nocc, ovlp_ao):

    r'''
    Off-diagonal block approximated 1RDM
    '''

    fla, flb = fl
    fra, frb = fr
    mocla, moclb = mocl
    mocra, mocrb = mocr

    nal, nar = na
    ncorel = nocc - nal
    ncorer = nocc - nar

    sa = np.einsum("mj,mn,ni->ji", mocla.conj(), ovlp_ao, mocra)
    sb = np.einsum("mj,mn,ni->ji", moclb.conj(), ovlp_ao, mocrb)

    occ_fb_hole_l = cistring._gen_occslst(range(2*nal), nal-1)
    occ_fb_l      = cistring._gen_occslst(range(2*nal), nal)
    occ_co_hole_l = np.array([list(range(2*nal, 2*nal+ncorel))] * len(occ_fb_hole_l))
    occ_co_l      = np.array([list(range(2*nal, 2*nal+ncorel))] * len(occ_fb_l))

    occ_hole_l    = np.hstack((occ_fb_hole_l, occ_co_hole_l))
    occ_l         = np.hstack((occ_fb_l, occ_co_l))

    occ_fb_hole_r = cistring._gen_occslst(range(2*nar), nar-1)
    occ_fb_r      = cistring._gen_occslst(range(2*nar), nar)
    occ_co_hole_r = np.array([list(range(2*nar, 2*nar+ncorer))] * len(occ_fb_hole_r))
    occ_co_r      = np.array([list(range(2*nar, 2*nar+ncorer))] * len(occ_fb_r))
    occ_hole_r    = np.hstack((occ_fb_hole_r, occ_co_hole_r))

    occ_r         = np.hstack((occ_fb_r, occ_co_r))

    Sa = np.zeros((len(occ_hole_l), len(occ_hole_r)))
    Sb = np.zeros((len(occ_l), len(occ_r)))

    for i in range(len(occ_hole_l)):
        for j in range(len(occ_hole_r)):
            saslice = sa[np.ix_(occ_hole_l[i], occ_hole_r[j])]
            Sa[i,j] = np.linalg.det(saslice)

    for i in range(len(occ_l)):
        for j in range(len(occ_r)):
            sbslice = sb[np.ix_(occ_l[i], occ_r[j])]
            Sb[i,j] = np.linalg.det(sbslice)

    # < \hat a_p^{\dagger \alpha} \hat a_q^\alpha >
    dma = np.einsum("ij,kl,ikp,jlq->pq", Sa, Sb, fla.conj(), fra)
    dmb = np.einsum("ij,kl,ikp,jlq->pq", Sb, Sa, flb.conj(), frb)

    # < \hat a_p^{\dagger \beta} \hat a_q^\beta >
    return dma + dmb

def make_ovlp_odiag(fl, fr, mocl, mocr, na, nocc, ovlp_ao):

    mocla, moclb = mocl
    mocra, mocrb = mocr
    nal, nar = na

    ncorel = nocc - nal
    ncorer = nocc - nar

    occ_fb_l = cistring._gen_occslst(range(2*nal), nal)
    occ_co_l = np.array([list(range(2*nal, 2*nal+ncorel))] * len(occ_fb_l))
    occ_l    = np.hstack((occ_fb_l, occ_co_l))

    occ_fb_r = cistring._gen_occslst(range(2*nar), nar)
    occ_co_r = np.array([list(range(2*nar, 2*nar+ncorer))] * len(occ_fb_r))
    occ_r    = np.hstack((occ_fb_r, occ_co_r))

    sa = np.einsum("mj,mn,ni->ji", mocla.conj(), ovlp_ao, mocra)
    sb = np.einsum("mj,mn,ni->ji", moclb.conj(), ovlp_ao, mocrb)

    Sa = np.zeros((len(occ_l), len(occ_r)))
    Sb = np.zeros((len(occ_l), len(occ_r)))

    for i in range(len(occ_l)):
        for j in range(len(occ_r)):
            saslice = sa[np.ix_(occ_l[i], occ_r[j])]
            Sa[i,j] = np.linalg.det(saslice)

    for i in range(len(occ_l)):
        for j in range(len(occ_r)):
            sbslice = sb[np.ix_(occ_l[i], occ_r[j])]
            Sb[i,j] = np.linalg.det(sbslice)

    ovlp = np.einsum("ij,kl,ik,jl->", Sa, Sb, fl, fr)
    return ovlp

def make_dm_diag(co_dmet, na, abdict=None):
    # Eq. 16/17 in doc.

    if abdict is None: abdict = [2**na-i-1 for i in range(2**na)]

    str_fb = cistring.make_strings(range(2*na), na)
    str_fs = [cistring.make_strings(range(na), n) for n in range(na+1)]
    idx_fb = dict(zip(str_fb, np.arange(len(str_fb))))

    dma = np.zeros((na, na))

    for n in range(1, na+1):
        link_idx = cistring.gen_linkstr_index(range(na), n)
        strlst_f = str_fs[n]

        for j in range(len(link_idx)):
            link_idx_ja = link_idx[j]
            aj = strlst_f[j]
            for info in link_idx_ja:
                p, q, l, sign = info
                al = strlst_f[l]
                for ai in strlst_f:
                    bi = abdict[ai]
                    jaia = idx_fb[(2**na)*bi + aj]
                    laia = idx_fb[(2**na)*bi + al]

                    for jbib in range(len(str_fb)):
                        dma[p,q] += sign * co_dmet[jaia,jbib] * co_dmet[laia,jbib].conj()

    return 2. * dma

def build_ovlp(fragments, fci_coeffs, projs, mos, nelec, ovlp_ao, stridxs=None):
    r'''
    mos has the information with all the embedded orbitals
    '''
    nsym = len(fragments)

    ovlp = np.zeros_like(ovlp_ao)

    if stridxs is None: stridxs = [get_str_idx(len(fragments[i][0]), None) for i in range(nsym)]

    # build between different symmetry blocks
    # i, j: index of symmetric fragments
    # ii, jj: index of fragments
    for i in range(nsym):
        nl = len(fragments[i][0])
        stridxl = stridxs[i]
        fo_l = gg_info(nl, projs[i], fci_coeffs[i], None, stridxl)

        for ii in range(len(fragments[i])):
            mo_l = (mos[i][ii], mos[i][ii])
            frag_l = fragments[i][ii]

            for jj in range(ii+1, len(fragments[i])):
                mo_j = (mos[i][jj], mos[i][jj])
                frag_j = fragments[i][jj]

                ovlp_blk = make_ovlp_odiag(fo_l, fo_l, mo_l, mo_j, (nl,nl), nelec, ovlp_ao)
                ovlp[np.ix_(frag_l, frag_j)] = ovlp_blk

        for j in range(i+1, nsym):
            nr = len(fragments[j][0])
            stridxr = stridxs[j]
            fo_r = gg_info(nr, projs[j], fci_coeffs[j], None, stridxr)

            for ii in range(len(fragments[i])):
                mo_l = (mos[i][ii], mos[i][ii])
                frag_l = fragments[i][ii]

                for jj in range(len(fragments[j])):
                    mo_r = (mos[j][jj], mos[j][jj])
                    frag_r = fragments[j][jj]
                    ovlp_blk = make_ovlp_odiag(fo_l, fo_r, mo_l, mo_r, (nl,nr), nelec, ovlp_ao)
                    
                    ovlp[np.ix_(frag_l, frag_r)] = ovlp_blk

    ovlp = ovlp + ovlp.conj().T

    # diagnonal
    for symfrag in fragments:
        for frag in symfrag:
            ovlp[np.ix_(frag, frag)] = 1.

    return ovlp

def build_1rdm(fragments, fci_coeffs, projs, mos, nelec, ovlp_ao, stridxs=None, normalized=False, ovlp=None):

    nsym = len(fragments)
    dm = np.zeros_like(ovlp_ao)

    if stridxs is None: stridxs = [get_str_idx(len(fragments[i][0])) for i in range(nsym)]

    for i in range(nsym):
        nl = len(fragments[i][0])
        stridxl = stridxs[i]

        fola = gaag_info(nl, projs[i], fci_coeffs[i], stridxl)
        folb = gabg_info(nl, projs[i], fci_coeffs[i], stridxl)
        fo_l = (fola, folb)

        for ii in range(len(fragments[i])):
            mo_l = (mos[i][ii], mos[i][ii])
            frag_l = fragments[i][ii]

            for jj in range(ii+1, len(fragments[i])):
                mo_j = (mos[i][jj], mos[i][jj])
                frag_j = fragments[i][jj]

                dm_blk = make_dm_odiag(fo_l, fo_l, mo_l, mo_j, (nl, nl), nelec, ovlp_ao)
                dm[np.ix_(frag_l, frag_j)] = dm_blk

        
        for j in range(i+1, nsym):
            nr = len(fragments[j][0])
            stridxr = stridxs[j]

            fora = gaag_info(nr, projs[j], fci_coeffs[j], stridxr)
            forb = gabg_info(nr, projs[j], fci_coeffs[j], stridxr)
            fo_r = (fora, forb)

            for ii in range(len(fragments[i])):
                mo_l = (mos[i][ii], mos[i][ii])
                frag_l = fragments[i][ii]

                for jj in range(len(fragments[j])):
                    mo_r = (mos[j][jj], mos[j][jj])
                    frag_r = fragments[j][jj]
                    dm_blk = make_dm_odiag(fo_l, fo_r, mo_l, mo_r, (nl,nr), nelec, ovlp_ao)

                    dm[np.ix_(frag_l, frag_r)] = dm_blk

    dm = dm + dm.conj().T

    # diagonal
    for i in range(nsym):
        n = len(fragments[i][0])
        dm_blk = make_dm_diag(fci_coeffs[i], n)
        for frag in fragments[i]:
            dm[np.ix_(frag, frag)] = dm_blk

    if normalized:
        if ovlp is None:
            ovlp = build_ovlp(fragments, fci_coeffs, projs, mos, nelec, ovlp_ao, stridxs)
        return dm / ovlp
    else:
        return dm
