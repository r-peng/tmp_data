import numpy as np
from pyscf import ao2mo
from pyscf.scf import hf
from pyscf.fci.cistring import make_strings
import pyscf.fci.direct_spin1 as fci
from cpskit import app1rdm

def get_ham_elem(h1e, eri, cir, cil, norb, nelec, link_index=None):
    # < cil | H | clr >
    h2e = fci.absorb_h1e(h1e, eri, norb, nelec, .5)
    hcir = fci.contract_2e(h2e, cir, norb, nelec, link_index)
    return np.dot(cil.reshape(-1), hcir.reshape(-1))

def get_ovlp_elem(cir, cil):
    return np.dot(cil.reshape(-1), cir.reshape(-1))

def has_config(fullstr, fragstr, frag, badict):

    # given product state | \psi \rangle (fullstr)
    # and | \beta_i \rangle (fragstr)
    # to evaluate whether \langle \alpha_i | \psi \rangle \ne 0
    
    isconf = True

    beta = fragstr >> len(frag) # | \beta_i >
    alpha = badict[beta]        # | \alpha_i>

    for i in range(len(frag)):
        fidx = frag[i]  # the position of site

        sfullstr = fullstr >> fidx  # shift to the defined site
        sfragstr = alpha >> i  
        # whether the last digit is zero -> site occupation are identical     
        crit = (sfullstr^sfragstr) % 2  
        if crit != 0: 
            # if has difference, then the full string doesn't have config |a_i>.
            isconf = False; break   

    return isconf

def change_config(fullstr, fragstr, frag):
    for i in range(len(frag)):
        fidx = frag[i]

        lowbits = fullstr - ((fullstr >> fidx) << fidx)
        fullstr = (fullstr >> (fidx+1)) << 1
        fullstr += (fragstr>>i)%2   # restore the 
        fullstr = fullstr << fidx
        fullstr += lowbits

    return fullstr

def ci_slater(nao, nelec, clm):
    # Get the Full-CI coefficient for Slater determinant in CI.
    nea, neb = nelec

    clma, clmb = clm    

    stra = make_strings(range(nao), nea)
    strb = make_strings(range(nao), neb)

    elidxa = [np.array(list(reversed([x for x in range(nao) if s&2**x]))) for s in stra]
    elidxb = [np.array(list(reversed([x for x in range(nao) if s&2**x]))) for s in strb]

    detca = np.array([np.linalg.det(clma[elidx,:]) for elidx in elidxa])
    detcb = np.array([np.linalg.det(clmb[elidx,:]) for elidx in elidxb])

    ci = np.einsum("i,j->ij", detca, detcb)

    return ci

def get_hf_coef(ci_slater, nocc):
   
    strab = list(make_strings(range(2*nocc), nocc))
    res = np.zeros((2**nocc, 2**nocc))
    for i in range(2**nocc):

        betaa = 2**nocc - i - 1
        stra = i + 2**nocc*betaa
        stridxa = strab.index(stra)

        for j in range(2**nocc):

            betab = 2**nocc - j - 1
            strb = j + 2**nocc*betab
            stridxb = strab.index(strb)

            c = ci_slater[stridxa, stridxb]
            res[i,j] = c

    return res


def get_proj(ci_slater, ci_dmet, nocc):

    """
    .. math::

        | HF \rangle = \sum\limits_i \lambda_i | \alpha_i \rangle \otimes | \beta_i; \Psi_c \rangle \\

        | DMET \rangle = \sum\limits_{ji} C_{ji} | \alpha_j \rangle \otimes | \beta_i; \Psi_c \rangle \\

        \hat P = \sum\limits_{ji} \dfrac{C_{ji}}{\lambda_i} | \alpha_j \rangle \langle \alpha_i |

    Then the function gives :math:`P_{ji} = \dfrac{C_{ji}}{\lambda_i}`.
    badict: \beta_i -> \alpha_i
    """

    l = np.zeros_like(ci_dmet)  # l_{ji} = \lambda_i
    strab = list(make_strings(range(2*nocc), nocc))

    for i in range(2**nocc):

        betaa = 2**nocc - i - 1
        stra = i + 2**nocc*betaa  # |\alpha_i\rangle \otimes |\beta_i\rangle
        stridxa = strab.index(stra)

        str_betaa = [x for x in strab if x>>nocc == betaa]

        for j in range(2**nocc):
            betab = 2**nocc - j - 1
            strb = j + 2**nocc*betab
            stridxb = strab.index(strb)

            c = ci_slater[stridxa, stridxb]

            str_betab = [x for x in strab if x>>nocc == betab]

            for sa in str_betaa:
                aidx = strab.index(sa)
                for sb in str_betab:
                    bidx = strab.index(sb)

                    l[aidx,bidx] = c
    # print("p = ", ci_dmet / l)
    return ci_dmet / l  # return p_{ji} = c_{ji}/L_{i}

def ci_cps(nao, nelec, ci_slater, p, fraglst, normalized=True):

    # projection operator also arrange as CI coefficient
    
    # fraglst: considering symmetry

    ci = ci_slater.copy()
    nea, neb = nelec

    stra = list(make_strings(range(nao), nea))
    strb = list(make_strings(range(nao), neb))

    for x in range(len(fraglst)):

        proj = p[x]
        sym_frag = fraglst[x]
        badict = [2**len(sym_frag[0])-i-1 for i in range(2**len(sym_frag[0]))]

        for frag in sym_frag:
    
        #frag + bath string
            strx = make_strings(range(2*len(frag)), len(frag))  
            newci = np.zeros_like(ci)

            for a in range(len(strx)):

                strxa = strx[a] # | \alpha_j > * | \beta_i >

                for strfai in stra:
                    if has_config(strfai, strxa, frag, badict):     # |\psi> has | \alpha_i > on site
                        strfaj = change_config(strfai, strxa, frag) # change |\alpha_i> site to |\alpha_j>

                        aiidx = stra.index(strfai)
                        ajidx = stra.index(strfaj)

                        for b in range(len(strx)):
                            pab = proj[a,b]     # p_{ji} | \alpha_j > < \alpha_i |
                            strxb = strx[b]     

                            for strfbi in strb:
                                if has_config(strfbi, strxb, frag, badict):
                                    strfbj = change_config(strfbi, strxb, frag)
                                    biidx = strb.index(strfbi)
                                    bjidx = strb.index(strfbj)
                                    newci[ajidx, bjidx] += pab * ci[aiidx, biidx]  

            ci = newci            

    if normalized: ci /= np.sqrt(np.einsum("ij->", ci**2))    # normalization
    return ci

def dmet_info(dmet_hf, dmet_ci):
    # they have been executed by kernel()

    fragments = dmet_hf.fragments

    k = 0

    p = []
    l = []
    psi = []

    for sym_frag in fragments:
        solver_hf = dmet_hf.dmets[k]
        solver_ci = dmet_ci.dmets[k]

        mo_e, mo_c = solver_hf.mo_energy, solver_hf.mo_coeff

        na = solver_hf.na
        c = mo_c[:,np.argsort(mo_e)[:na]]
        coef_hf = ci_slater(2*na, (na, na), (c, c))
        coef_ci = solver_ci.fci_coeff

        proj = get_proj(coef_hf, coef_ci, na)
        hfexp = get_hf_coef(coef_hf, na)
        p.append(proj)
        l.append(hfexp)
        psi.append(coef_ci)
        k += 1

    return fragments, p, l, psi


class CPSMethod:

    def __init__(self, dmet_hf, dmet_ci, mf):

        self._scf = mf
        self.dmet_ci = dmet_ci
        dmetinfo = dmet_info(dmet_hf, dmet_ci)
        self.fragments, self.projs, self.coef_hfs, self.coef_cis = dmetinfo

        self.mo_energy = mf.mo_energy
        self.mo_occ = mf.mo_occ
        self.e_nuc = dmet_ci.energy_nuc
        cam = mf.mo_coeff
        
        self.mol = self._scf.mol
        self.h1e = np.einsum("mj,mn,nk->jk", dmet_ci.cae.conj(), self._scf.get_hcore(), dmet_ci.cae)
        self.eri = ao2mo.kernel(self._scf._eri, dmet_ci.cae)
        self.mo_coeff = np.dot(np.linalg.inv(dmet_ci.cae), cam) # EO -> MO coefficient

    def get_projectors(self):
        return self.projs

    def get_coef_hf(self):
        return self.coef_hfs

    def ci_slater(self, mo_c):
        return ci_slater(self.mol.nao, self.mol.nelec, mo_c)

    def ci_cps(self, ci0, normalized=True):
        return ci_cps(self.mol.nao, self.mol.nelec,
                      ci0, self.projs, self.fragments, normalized=normalized)
                
    def get_ham_elem(self, cir, cil):
        return get_ham_elem(self.h1e, self.eri, cir, cil,
                            self.mol.nao, self.mol.nelec)

    def get_ground_state(self):
        # CI coefficient in EO basis; energy <\Phi|P^\dagger HP|\Phi>
        if "RHF" in self._scf.__class__.__name__:
            mo_c = self.mo_coeff[:,np.where(self.mo_occ!=0.)[0]]

            # print(mo_c.shape)
            ci_hf = self.ci_slater((mo_c, mo_c))
            ci = self.ci_cps(ci_hf, normalized=True)

            dm = fci.make_rdm1(ci, self.mol.nao, self.mol.nelec)

            e = fci.energy(self.h1e, self.eri, 
                           ci, self.mol.nao, self.mol.nelec) + self.e_nuc
        else:
            raise NotImplementedError("Support RHF guess only.")

        print("CPS Energy = ", e)
        return e, dm, ci            

    def eom_fci(self):

        occidxs = np.where(self.mo_occ!=0.)[0]
        viridxs = np.where(self.mo_occ==0.)[0]
        nov = len(occidxs) * len(viridxs)

        print("Calculating", 2*nov+1, "configurations ...")

        mo_c_r = self.mo_coeff[:,occidxs]
        ci_hf_r = self.ci_slater((mo_c_r, mo_c_r))
        ci_r = self.ci_cps(ci_hf_r, normalized=True)

        ham  = np.zeros((2*nov+1, 2*nov+1))    # <\Phi_i^a|PHP|\Phi_i^a>
        ovlp = np.zeros_like(ham)                # <\Phi_i^a|PP|\Phi_i^a>

        coefs = [ci_r]
        coefa = []
        coefb = []

        for i in range(len(occidxs)):
            occidx = occidxs[i]
            for j in range(len(viridxs)):
                viridx = viridxs[j]
                idx = occidxs.copy()
                idx[i] = viridx     # directly change a occupied idx to a virtual one
                mo_c = self.mo_coeff[:,idx]
                # print("Calculating FCI coefficient", occidx, "->", viridx, "...")
                ci_hf_alpha = self.ci_slater((mo_c, mo_c_r))
                ci_hf_beta  = self.ci_slater((mo_c_r, mo_c))

                ci_alpha = self.ci_cps(ci_hf_alpha, normalized=True)
                ci_beta  = self.ci_cps(ci_hf_beta,  normalized=True)

                coefa.append(ci_alpha)
                coefb.append(ci_beta)

        coefs.extend(coefa)
        coefs.extend(coefb)

        for i in range(2*nov+1):
            cil = coefs[i]
            for j in range(2*nov+1):
                cir = coefs[j]
                # print("Build matrix element ", i, j, "...")
                ham[i,j]  = self.get_ham_elem(cir, cil)
                ovlp[i,j] = get_ovlp_elem(cir, cil)

        e, c = hf.eig(ham, ovlp)
        e += self.e_nuc

        return (e, c)

    def make_approx_ovlp(self, mos):
        # approximate ovlp
        fci_coeffs = [solver.fci_coeff for solver in self.dmet_ci.dmets]

        return app1rdm.build_ovlp(self.fragments, fci_coeffs, self.projs, mos, self.mol.nelec[0], hf.get_ovlp(self.mol))

    def make_approx_rdm1(self, mos, normalized=False, ovlp=None):
        # approximate ovlp
        if normalized: ovlp = self.make_approx_ovlp(mos=mos)
        fci_coeffs = [solver.fci_coeff for solver in self.dmet_ci.dmets]

        return app1rdm.build_1rdm(self.fragments, fci_coeffs, self.projs, mos, self.mol.nelec[0], hf.get_ovlp(self.mol), 
        stridxs=None, normalized=normalized, ovlp=ovlp)

    def approx_energy(self, mos):
        # 1rdm from approx
        # 2rdm from approximate Wick theorem

        dm = self.make_approx_rdm1(mos, normalized=False)
        h2e = ao2mo.restore(1, self.eri.copy(), self._scf.mol.nao)
        h1e_eff = self.h1e + .5 * np.einsum("pqrs,rs->pq", h2e, dm) - .25 * np.einsum("psrq,rs->pq", h2e, dm)

        e = np.einsum("pq,pq->", h1e_eff, dm) + self.e_nuc

        print("Energy from app1rdm = ", e)

        return e

