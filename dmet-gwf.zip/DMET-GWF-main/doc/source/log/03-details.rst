Details of EOMDP
==============================

Representation of wave-function
-----------------------------------------

Define the original CI wave-function in Embedding basis is 

.. math::
    :label: wfn-gs-1imp

    | \Psi_0^{(x)} \rangle = | \mathcal C^\alpha \rangle  \sum\limits_{I^\alpha I^\beta} \psi_{I^\alpha I^\beta} | \mathcal E_{I^\alpha} \rangle \otimes | \mathcal E_{I^\beta} \rangle | \mathcal C^\beta \rangle = | \mathcal C^\alpha \rangle | \psi_0 \rangle | \mathcal C^\beta \rangle = (-)^{N_c^2} | \mathcal C^\beta \rangle | \psi_0 \rangle | \mathcal C^\alpha \rangle 
.. math::
    :label: wfn-1imp

    \begin{aligned}
    | \Psi_{e \to e}^{\alpha} \rangle &= | \mathcal C^\alpha \rangle \sum\limits_{p,q\in \mathcal E} S_{pq}^{e \leftarrow e} \hat a_p^{\dagger \alpha} \hat a_{q}^\alpha | \psi_0 \rangle | \mathcal C^\beta \rangle \\
    | \Psi_{c \to e}^{\alpha} \rangle &= \sum\limits_{q \in \mathcal C, p \in \mathcal E} S_{pq}^{e \leftarrow c} (-)^q | \mathcal C_q ^\alpha \rangle \otimes \hat a^{\dagger \alpha}_p | \psi_0 \rangle \otimes | \mathcal C^\beta \rangle \\
    | \Psi_{e \to v}^{\alpha} \rangle &= \sum\limits_{p \in \mathcal V, q \in \mathcal E} S_{pq}^{v \leftarrow e} (-)^{N_c} | \mathcal V^\alpha_p \mathcal C^\alpha \rangle \otimes \hat a_q^\alpha | \psi_0 \rangle \otimes | \mathcal C^\beta \rangle \\
    | \Psi_{c \to v}^{\alpha} \rangle &= \sum\limits_{p \in \mathcal V, q \in \mathcal C} S_{pq}^{v \leftarrow c} (-)^{q + N_c + 1} | \mathcal V^\alpha_p \mathcal C^\alpha_q \rangle | \psi_0 \rangle | C^\beta \rangle 
    \end{aligned}


For 1-RDM:

.. math::
    :label: eea-eea-eea

    \langle EE^\alpha | EE^\alpha | EE^\alpha \rangle = \sum\limits_{p'q'r's' \in \mathcal E} S_{p'q'}^{e \leftarrow e * } S_{r's'}^{e \leftarrow e} \sum\limits_{pq} D_{pq}^{p'q' | r's'} h_{pq} \\
    
    D_{pq}^{p'q' | r's'} = \langle \psi_0 | \hat q^{'\dagger} \hat p' | \hat p^\dagger \hat q | \hat r^{' \dagger} \hat s | \psi_0 \rangle
.. math::
    :label: cea-eea-cea

    \langle CE^\alpha | EE^\alpha | CE^\alpha \rangle = \sum\limits_{p'q' \in \mathcal E, \, r' \in \mathcal C} S_{p'r'}^{e \leftarrow c * } S_{q'r'}^{e \leftarrow c} \sum\limits_{pq} D_{pq}^{p' | q'} h_{pq} \\
    D_{pq}^{p' | q'} = \langle \psi_0 | \hat p' | \hat p^\dagger \hat q | \hat q' \rangle 

.. math::
    :label: eva-eea-eva

    \langle EV^\alpha | EE^\alpha | EV^\alpha \rangle = \sum\limits_{p'q' \in \mathcal E, \, r' \in \mathcal V} S_{r'p'}^{v \leftarrow e * } S_{r'q'}^{v \leftarrow e} \sum\limits_{pq} D_{pq}^{p' | q'} h_{pq} \\
    D_{pq}^{p' | q'} = \langle \psi_0 | \hat p^{'\dagger} | \hat p^\dagger \hat q | \hat q' | \psi_0 \rangle 

.. math::
    :label: cva-eea-cva

    \langle CV^\alpha | EE^\alpha | CV^\alpha \rangle = \sum\limits_{p' \in \mathcal V, q' \in \mathcal C'} S_{p'q'}^{v \leftarrow c * } S_{p'q'}^{v \leftarrow c} \sum\limits_{pq} D_{pq}^{|} h_{pq}

.. math::
    :label: eea-eva-eva

    \langle EE^\alpha | EV^\alpha | EV^\alpha \rangle = \sum\limits_{p'q' r'\in \mathcal E, p \in \mathcal E, q \in \mathcal V} S_{p'q'}^{e \leftarrow e * } S_{q r'}^{v \leftarrow e} D_p^{p'q' | r'} h_{pq}

.. math::
    :label: cea-eva-cva 

    \langle CE^\alpha | EV^\alpha | CV^\alpha \rangle = \sum\limits_{p' \in \mathcal E, q' \in \mathcal C} \sum\limits_{p \in \mathcal E, q \in \mathcal V} S_{p'q'}^{e \leftarrow c * } S_{qq'}^{v \leftarrow c} D_p^{p' | } h_{pq}

.. math::
    :label: cva-eca-eva

    \langle CV^\alpha | EC^\alpha | EV^\alpha \rangle = - \sum\limits_{q' \in \mathcal V, p' \in \mathcal E} \sum\limits_{p \in \mathcal E, q \in \mathcal C} S_{q' q}^{v \leftarrow c * } S_{q' p'}^{v \leftarrow e} D_p^{| p'} h_{pq}

.. math::
    :label: cea-eca-eea

    \langle CE^\alpha | EC^\alpha | EE^\alpha \rangle = \sum\limits_{p', r', s' \in \mathcal E } \sum\limits_{p \in \mathcal E, q \in \mathcal C} S_{p'q}^* S_{r's'} D^{p'|r's'}_{p} h_{pq}

For :math:`\langle \alpha | ? | \beta \rangle`, only when one civec is :math:`EE` can the element be non-zero.

For 2RDM with different spins, we denote the sequence :math:`\hat p^{\dagger\alpha} \hat s^{\alpha} \hat r^\dagger^{\beta} \hat q^\beta`.

If the civec are alpha excited, then the operator only have type :math:`EY^\alpha CC^\beta`, :math:`EY^\alpha EE^\beta`, :math:`EE^\beta XY^\alpha`. If both are beta excited, the 2rdm operator would be :math:`EE^\alpha XY^\beta`, `EY^\beta CC^\alpha` or `EY^\beta EE^\alpha`.
    
Slow Implementation
----------------------------

Basis Set
+++++++++++++

By writing in the ``emb+core+vir`` basis, the Full-CI expansion of 1-imp wave-function is

.. math::
    :label: wfn-1imp

    | \Psi^{(x)} \rangle = \sum\limits_{\underline{J^\alpha I^\alpha} \underline{J^\beta I^\beta}} (-)^{N_c N_a}\, \psi_{\underline{J^\alpha I^\alpha},\underline{J^\beta I^\beta}} \,| \mathcal F_{J^\alpha}\,\mathcal B_{I^\alpha}\,\mathcal C^\alpha \rangle \otimes | \mathcal F_{J^\beta}\,\mathcal B_{I^\beta}\,\mathcal C^\beta \rangle

in which :math:`(-)^{N_c N_a}` corresponds to the exchange between :math:`| \mathcal C_\alpha \rangle` and :math:`| \mathcal F_{J^\beta} B_{I^\beta} \rangle`. 

the ``emb->emb`` excitation part is

.. math::
    :label: wfn-1imp-e2e

    \begin{aligned}
    | \Psi^{(x)}_{e\to e} \rangle = & \sum\limits_{p,q\in e}  S_{pq}^{e \leftarrow e} \hat a^{\dagger \alpha}_p \hat a_q^\alpha | \Psi^{(x)} \rangle \\ =&  \sum\limits_{p,q\in e} \sum\limits_{\underline{J^\alpha I^\alpha},\underline{J^\beta I^\beta}}  S_{pq}^{e \leftarrow e} \psi_{\underline{J^\alpha I^\alpha},\underline{J^\beta I^\beta}} \,\mathrm{PF}(\underline{J^\alpha I^\alpha}, p, q) \, (-)^{N_c N_a} \\ & | \mathcal E_{ \underline{J^{\alpha'} I^{\alpha '}}(\underline{J^\alpha I^\alpha}, p, q)} \, \mathcal C_\alpha \rangle \otimes | \mathcal E_{\underline{J^\beta I^\beta}} \, \mathcal C_\beta \rangle
    \end{aligned}

the ``core->emb`` excitation part is

.. math::
    :label: wfn-1imp-c2e

    \begin{aligned}
        | \Psi^{(x)}_{c \to e} \rangle = & \sum\limits_{p\in e, q \in c} S_{pq}^{e \leftarrow c} \hat a^{\dagger\alpha}_p \hat a_q^\alpha | \Psi^{(x)} \rangle \\ = & \sum\limits_{p\in e, q \in c} \sum\limits_{\underline{J^\alpha I^\alpha},\underline{J^\beta I^\beta}} S_{pq}^{e \leftarrow c} \, \psi_{\underline{J^\alpha I^\alpha},\underline{J^\beta I^\beta}} \,  \mathrm{PF} (\underline{J^\alpha I^\alpha}, p) (-)^{N_c N_a + q} \\
        & | \mathcal E_{ \underline{J^{\alpha'} I^{\alpha '}}(\underline{J^\alpha I^\alpha}, p)} \, \mathcal C_\alpha^q \rangle \otimes | \mathcal E_{\underline{J^\beta I^\beta}} \, \mathcal C_\beta \rangle
    \end{aligned}

the ``emb->vir`` excitation part is 

.. math:: 
    :label: wfn-1imp-e2v

    \begin{aligned}
        | \Psi^{(x)}_{e \to v} \rangle = & \sum\limits_{p \in v, q \in e} S_{pq}^{v \leftarrow e} \hat a^{\dagger \alpha}_p \hat a_q^\alpha | \Psi^{(x)} \rangle \\ 
        = & \sum\limits_{p \in v, q \in e} \sum\limits_{\underline{J^\alpha I^\alpha},\underline{J^\beta I^\beta}} S_{pq}^{v \leftarrow e} \, \psi_{\underline{J^\alpha I^\alpha},\underline{J^\beta I^\beta}} \, \mathrm{PF}(\underline{J^\alpha I^\alpha}, q) (-)^{N_c N_a + N_c} \\ 
        & | \mathcal E_{ \underline{J^{\alpha'} I^{\alpha '}}(\underline{J^\alpha I^\alpha}, q)} \, \mathcal C_\alpha  \mathcal V_\alpha^p \rangle \otimes | \mathcal E_{\underline{J^\beta I^\beta}} \, \mathcal C_\beta \rangle
    \end{aligned}

the ``core->vir`` excitation part is

.. math::
    :label: wfn-1imp-c2v

    \begin{aligned}
        | \Psi_{c \to v}^{(x)} \rangle = & \sum\limits_{p \in v, q \in c} S_{pq}^{v \leftarrow c} \hat a_p^{\dagger \alpha} \hat a_q^\alpha | \Psi^{(x)} \rangle \\ = & \sum\limits_{p \in v, q \in c} \sum\limits_{\underline{J^\alpha I^\alpha},\underline{J^\beta I^\beta}} S_{pq}^{v \leftarrow c} \, \psi_{\underline{J^\alpha I^\alpha},\underline{J^\beta I^\beta}} \, (-)^{N_c N_a + N_c -1 + q} \\ & | \mathcal E_{\underline{J^\alpha I^\alpha}} \, {\mathcal C}_\alpha^q {\mathcal V}_\alpha^p \rangle \otimes | \mathcal E_{\underline{J^\beta I^\beta}} \, \mathcal{C}_\beta \rangle
    \end{aligned}

also don't forget ``core->core`` excitation part:

.. math::
    :label: wfn-1imp-c2c

    | \Psi_{c\to c}^{(x)} \rangle = \sum\limits_{p \in c} S_{pp}^{c \leftarrow c} | \Psi^{(x)} \rangle

so trivial that it can be absorbed into Eq. :eq:`wfn-1imp-e2e` during the implementation.

Previous Fast Implementation
------------------------------

Rewriting four parts of wave function as

.. math::
    :label: wfn-fast

    \begin{aligned}
        | \Psi_{e\to e}^\alpha \rangle &= \sum\limits_{J^\alpha J^\beta} \psi_{J^\alpha J^\beta}^{e \to e} | \mathcal C_\alpha \mathcal E_{J^\alpha}  \rangle \otimes | \mathcal C_\beta \mathcal E_{J^\beta}  \rangle  \\ 
        | \Psi_{c \to e}^\alpha \rangle &= \sum\limits_{q \in \mathcal C} C_{qi}^* (-)^q  | \mathcal C_\alpha^q \rangle \otimes \sum\limits_{J^\alpha J^\beta} \psi_{J^\alpha J^\beta}^{c \to e} | \mathcal E_{J^\alpha} \rangle \otimes | \mathcal C_\beta  \mathcal E_{J^\beta} \rangle \\
        | \Psi_{e \to v}^{\alpha} \rangle &= \sum\limits_{p\in \mathcal V} C_{pa} (-)^{N_c} | \mathcal V_\alpha^p \mathcal C_\alpha \rangle \otimes  \sum\limits_{J^\alpha J^\beta}\psi_{J^\alpha J^\beta}^{e \to v} | \mathcal E_{J^\alpha} \rangle \otimes |\mathcal C_\beta \mathcal E_{J^\beta}  \rangle \\
        | \Psi_{c \to v}^{\alpha} \rangle &= \sum\limits_{p \in \mathcal V, q \in \mathcal C} S_{pq}^{v \leftarrow e} (-)^{q + N_c - 1} | \mathcal V_\alpha^p \mathcal C_\alpha^q \rangle \otimes \sum\limits_{J^\alpha J^\beta} \psi_{J^\alpha J^\beta}^{c \to v} | \mathcal E_{J^\alpha} \rangle \otimes | \mathcal C_\beta\mathcal E_{J^\beta}  \rangle
    \end{aligned}

in which 

.. math::
    :label: wfn-fast-coeff

    \begin{aligned}
        \psi_{J^\alpha J^\beta}^{e \to e} &= \sum\limits_{p, q \in \mathcal E} S_{pq}^{e \leftarrow e} \psi_{J^{\alpha '}(J^\alpha, p, q), J^\beta} \, \mathrm{PF}(J^\alpha, p, q) \\
        \psi_{J^\alpha J^\beta}^{c \to e} &= \sum\limits_{p \in \mathcal E} C_{pa} \, \mathrm{PF}(J^\alpha, p) \, \psi_{J^{\alpha'}(J^\alpha, p) J^\beta} \\
        \psi_{J^\alpha J^\beta}^{e \to v} &= \sum\limits_{q \in \mathcal E} C_{qi}^* \, \mathrm{PF}(J^\alpha, q) \, \psi_{J^{\alpha'}(J^\alpha, q), J^\beta}  \\
        \psi_{J^\alpha, J^\beta}^{c \to v} &= \psi_{J^\alpha, J^\beta} 
    \end{aligned}

Evaluation of 1-rdm
+++++++++++++++++++++++++++++++++++

Here is the table of all the allowed transitions (:math:`\langle L | \hat p^\dagger \hat q | R \rangle, (p,q \in \mathcal{ECV})`)

+-----------+-------+-------+-----------+-----------+
|           | \|EE> | \|CE> | \|CV>     | \|EV>     |
+===========+=======+=======+===========+===========+
| **<EE|**  | EE/CC | CE    | CV        | EV        |
+-----------+-------+-------+-----------+-----------+
| **<CE|**  | EC    | EE/CC | EV        |           |
+-----------+-------+-------+-----------+-----------+
| **<CV|**  | VC    | VE    | EE/CC/VV  | EC        |
+-----------+-------+-------+-----------+-----------+
| **<EV|**  | VE    |       | CE        | EE/CC/VV  |
+-----------+-------+-------+-----------+-----------+

For simplification, we neglect the spin-beta parts and write the wave functions :eq:`wfn-fast` as below:

.. math::
    :label: wfn-simp

    \begin{aligned}
        | \Psi_{e \to e} \rangle &= (-)^{N_a N_c}| \mathcal C \rangle \otimes | \psi_{e \to e} \rangle \otimes | \mathcal C_\beta \rangle \\ 
        | \Psi_{c \to e} \rangle &= (-)^{N_a N_c} \sum\limits_{q \in \mathcal C} C_{qi}^* (-)^q | \mathcal C^q \rangle \otimes | \psi_{c \to e} \rangle \otimes | \mathcal C_\beta \rangle\\
        | \Psi_{e \to v} \rangle &= (-)^{N_a N_c} \sum\limits_{p \in \mathcal V} C_{pa} (-)^{N_c} | \mathcal V_p \mathcal C \rangle \otimes | \psi_{e \to v} \rangle \otimes | \mathcal C_\beta \rangle\\
        | \Psi_{c \to v} \rangle &= (-)^{N_a N_c} \sum\limits_{q \in \mathcal C, p \in \mathcal V} S_{pq}^{v \leftarrow c} (-)^{q + N_c - 1} | \mathcal V^p \mathcal C^q \rangle \otimes | \psi_{c \to v} \rangle \otimes | \mathcal C_\beta \rangle
    \end{aligned}

where phase :math:`(-)^{N_a N_c}` corresponds to the exchange between :math:`| \mathcal E_{J^\beta} \rangle` and :math:`| \mathcal C^\beta \rangle`.

The correponding matrix elements are:

.. math::
    :label: 1rdm-mat-elem

    \begin{aligned}
    \langle EE | EE | EE \rangle &= \langle \psi_{ee}^L | \hat a^\dagger_p \hat a_q | \psi_{ee}^R \rangle \\
    \langle EE | CC | EE \rangle &= \delta_{pq} \langle \psi_{ee}^L | \psi_{ee}^R \rangle \\
    \langle EE | CE | CE \rangle &= C_{pi}^{*R} \langle \psi_{ee}^L | \hat a_q | \psi_{ce}^R \rangle \\
    \langle EE | CV | CV \rangle &= S_{qp}^{R} \langle \psi_{ee}^L | \psi_{ee}^R \rangle \\
    \langle EE | EV | EV \rangle &= C_{pa}^R \langle \psi_{ee}^L | \hat a_q | \psi_{ev}^R \rangle \\
    \langle CE | EE | CE \rangle &= \sum\limits_{r \in \mathcal C} C_{rj}^L C_{ri}^{R*} \langle \psi_{ce}^L | \hat a^\dagger_p \hat a_q | \psi_{ce}^R \rangle \\
    \langle CE | CC | CE \rangle &= [-(1-\delta_{pq}) C_{qj}^L C_{pi}^{R*} + \delta_{pq} \sum\limits_{r \ne p, r \in \mathcal C} C_{rj}^L C_{ri}^{R*}] \langle \psi_{ce}^L | \psi_{ce}^R \rangle \\
    \langle CE | EV | CV \rangle &= \sum\limits_{r \in \mathcal C} C_{rj}^L S_{qr}^{R} \langle \psi_{ce}^L | \hat a^\dagger_p | \psi_{cv}^R \rangle \\
    \langle CV | EE | CV \rangle &= \sum\limits_{r \in \mathcal C, s \in \mathcal V} S_{sr}^{L*} S_{sr}^R \langle \psi_{cv}^L | \hat a^\dagger_p \hat a_q | \psi_{cv}^R \rangle \\
    \langle CV | CC | CV \rangle &= \sum\limits_{s \in \mathcal V} [- S_{sq}^{L*} S_{sp}^R (1 - \delta_{pq}) + \sum\limits_{r \ne p, r \in \mathcal C} S_{sr}^{L*} S_{sr}^{R} \delta_{pq}] \langle \psi_{cv}^L | \psi_{cv}^R \rangle \\
    \langle CV | VV | CV \rangle &= \sum\limits_{r \in \mathcal C} S_{pr}^{L*} S_{qr}^{R} \langle \psi_{cv}^L | \psi_{cv}^R \rangle \\
    \langle CV | EC | EV \rangle &= - \sum\limits_{r\in \mathcal V} S_{rq}^{L*} C_{ra}^R \langle \psi_{cv}^L | \hat a^\dagger_p | \psi_{ev}^R \rangle \\
    \langle EV | EE | EV \rangle &= \sum\limits_{r \in \mathcal V} C_{rb}^{L*} C_{ra}^R \langle \psi_{ev}^L | \hat a^\dagger_p \hat a_q | \psi_{ev}^R \rangle \\
    \langle EV | CC | EV \rangle &= \delta_{pq} \sum\limits_{r \in \mathcal V} C_{rb}^{L*} C_{ra}^R \langle \psi_{ev}^L | \psi_{ev}^R \rangle \\ 
    \langle EV | VV | EV \rangle &= C_{pb}^{L*} C_{qa}^R \langle \psi_{ev}^L | \psi_{ev}^R \rangle
    \end{aligned}

Evaluation of 2-rdm
++++++++++++++++++++++++++

Now we first consider :math:`\langle L | \hat a^\dagger_{p\sigma} \hat a^\dagger_{r \sigma} \hat a_{q \sigma} \hat a_{s \sigma} | R \rangle`.

which reduces to 1rdm treatment.

+-----------+-----------------+-----------------+---------------------------+----------------------------+
|           | \|EE>           | \|CE>           | \|CV>                     | \|EV>                      |
+===========+=================+=================+===========================+============================+
| **<EE|**  | EEEE/ECCE/ECEC  | ECEE            | ECVE/ECEV                 | EEEV/EEVE                  |
+-----------+-----------------+-----------------+---------------------------+----------------------------+
| **<CE|**  | EECE/EEEC/ECCC  | EEEE/ECCE/ECEC  | ECVC/ECCV/EEVE/EEEV       | EEVC/EECV                  |
+-----------+-----------------+-----------------+---------------------------+----------------------------+
| **<CV|**  | EVCE/EVEC       | EVEE            | EEEE/ECCE/ECEC/EVVE/EVEV  | EECE/EEEC/EVCV/EVVC/ECCC   |
+-----------+-----------------+-----------------+---------------------------+----------------------------+
| **<EV|**  | EVEE            |                 | ECEE                      | EEEE/ECCE/ECEC/EVVE/EVEV   |
+-----------+-----------------+-----------------+---------------------------+----------------------------+


.. math::
    :label: 2rdm-mat-elem

    \begin{aligned}
        \langle EE | EEEE | EE \rangle &= \langle \psi_{ee}^L | \hat p^\dagger \hat r^\dagger \hat q \hat s | \psi_{ee}^R \rangle \\ 
        \langle EE | ECCE | EE \rangle &= \delta_{rq} \langle \psi_{ee}^L | \hat p^\dagger \hat s | \psi_{ee}^R \rangle \\ 
        \langle EE | ECEC | EE \rangle &= - \delta_{rs} \langle \psi_{ee}^L | \hat p^\dagger \hat q | \psi_{ee}^R \rangle \\
        \langle EE | ECEE | CE \rangle &= - C_{ri}^{* R} \langle \psi^{L}_{ee} | \hat p^\dagger \hat q \hat s | \psi_{ce}^R \rangle \\
        \langle EE | ECVE | CV \rangle &= S_{qr}^R \langle \psi_{ee}^L | \hat p^\dagger \hat s | \psi_{cv}^R \rangle \\
        \langle EE | ECEV | CV \rangle &= - S_{sr}^R \langle \psi_{ee}^L | \hat p^\dagger \hat q | \psi_{cv}^R \rangle \\
        \langle EE | EEEV | EV \rangle &= C_{sa}^R \langle \psi_{ee}^L | \hat p^\dagger \hat r^\dagger \hat q | \psi_{ev}^R \rangle \\
        \langle EE | EEVE | EV \rangle &= - C_{qa}^R \langle \psi_{ee}^L | \hat p^\dagger \hat r^\dagger \hat s | \psi_{ev}^R \rangle \\ 
        \langle CE | EECE | EE \rangle &= - C_{qi}^L  \langle \psi_{ce}^L | \hat p^\dagger \hat r^\dagger \hat s | \psi_{ee}^R \rangle \\
        \langle CE | EEEC | EE \rangle &= C_{si}^L \langle \psi_{ce}^L | \hat p^\dagger \hat r^\dagger \hat q | \psi_{ee}^R \rangle \\ \langle CE | ECCC | EE \rangle &= [C_{si}^L \delta_{rq} - C_{qi}^L \delta_{rs}] (1 - \delta_{sq}) \langle \psi_{ce}^L | \hat p^\dagger | \psi_{ee}^R \rangle \\
        \langle CE | EEEE | CE \rangle &= \sum\limits_{t \in \mathcal C} C_{ti}^{L} C_{ti}^{R*} \langle \psi_{ce}^L | \hat p^\dagger \hat r^\dagger \hat q \hat s | \psi_{ce}^R \rangle \\
        \langle CE | ECCE | CE \rangle &= [- C_{qj}^L C_{ri}^{R*} + \delta_{rq} \sum\limits_{t \in \mathcal C} C_{tj}^{L} C_{ti}^{R*}] \langle \psi_{ce}^L | \hat p^\dagger \hat s | \psi_{ce}^R \rangle \\
        \langle CE | ECEC | CE \rangle &= -[- C_{sj}^L C_{ri}^{R*} + \delta_{rs} \sum\limits_{t \in \mathcal C} C_{tj}^L C_{ti}^{R*}] \langle \psi_{ce}^L | \hat p^\dagger \hat q | \psi_{ce}^R \rangle \\
        \langle CE | ECVC | CV \rangle &= - [- C_{si}^L S_{qr}^R + \sum\limits_{t \in \mathcal C} C_{ti}^L S_{qt}^R ] \langle \psi_{ce}^L | \hat p^\dagger | \psi_{cv}^R \rangle \\ 
        \langle CE | ECCV | CV \rangle &=  [- C_{qi}^L S_{sr}^R + \sum\limits_{t \in \mathcal C} C_{ti}^L S_{st}^R ] \langle \psi_{ce}^L | \hat p^\dagger | \psi_{cv}^R \rangle \\ 
        \langle CE | EEVE | CV \rangle &= - \sum\limits_{t \in \mathcal C} C_{ti}^L S_{qt}^R  \langle \psi_{ce}^L | \hat p^\dagger \hat r^\dagger \hat s | \psi_{cv}^R \rangle \\
        \langle CE | EEEV | CV \rangle &= \sum\limits_{t \in \mathcal C} C_{ti}^L S_{st}^R  \langle \psi_{ce}^L | \hat p^\dagger \hat r^\dagger \hat q | \psi_{cv}^R \rangle \\
        \langle CE | EEVC | EV \rangle &= C_{si}^L C_{qa}^R  \langle \psi_{ce}^L | \hat p^\dagger \hat r^\dagger | \psi_{ev} ^R \rangle \\
        \langle CE | EECV | EV \rangle &= - C_{qi}^L C_{sa}^R \langle \psi_{ce}^L | \hat p^\dagger \hat r^\dagger | \psi_{ev}^R \rangle \\
        \langle CV | EVCE | EE \rangle &= S_{rq}^{L*} (-)^{N_e - 1} \langle \psi_{cv}^L | \hat p^\dagger \hat s | \psi_{ee}^R \rangle \\
        \langle CV | EVEC | EE \rangle &= S_{rs}^{L*} (-)^{N_e} \langle \psi_{cv}^L | \hat p^\dagger \hat q | \psi_{ee}^R \rangle \\
        \langle CV | EVEE | CE \rangle &= \sum\limits_{t \in \mathcal C} S_{rt}^{L*} C_{ti}^{R*} (-)^{N_e} \langle \psi_{cv}^L | \hat p^\dagger \hat q \hat s | \psi_{ce}^R \rangle \\
        \langle CV | EEEE | CV \rangle &= \sum\limits_{t \in \mathcal C, u \in \mathcal V} S_{ut}^{L*} S_{ut}^R \langle \psi_{cv}^L | \hat p^\dagger \hat r^\dagger \hat q \hat s | \psi_{cv}^R \rangle \\
        \langle CV | ECCE | CV \rangle &= [\sum\limits_{u \in \mathcal V} - S_{uq}^{L*} S_{ur}^{R} + \delta_{qr} \sum\limits_{t \in \mathcal C} S_{ut}^{L*} S_{ut}^R ] \langle \psi_{cv}^L | \hat p^\dagger \hat s | \psi_{cv}^R \rangle \\
        \langle CV | ECEC | CV \rangle &= -[\sum\limits_{u \in \mathcal V} - S_{us}^{L*} S_{ur}^R + \delta_{sr} \sum\limits_{t \in \mathcal C} S_{ut}^{L*} S_{ut}^{R}] \langle \psi_{cv}^L | \hat p^\dagger \hat q | \psi_{cv}^R \rangle \\
        \langle CV | EVVE | CV \rangle &= \sum\limits_{t \in \mathcal C} S_{rt}^{L*} S_{qt}^{R} \langle \psi_{cv}^L | \hat p^\dagger \hat s | \psi_{cv}^R \rangle \\
        \langle CV | EVEV | CV \rangle &= -\sum\limits_{t \in \mathcal C} S_{rt}^{L*} S_{st}^R \langle \psi_{cv}^L | \hat p^\dagger \hat q | \psi_{cv}^R \rangle \\
        \langle CV | EECE | EV \rangle &= - \sum\limits_{u \in \mathcal V} S_{uq}^{L*} C_{ua}^R \langle \psi_{cv}^L | \hat p^\dagger \hat r^\dagger \hat s | \psi_{ev}^R \rangle \\
        \langle CV | EEEC | EV \rangle &= \sum\limits_{u \in \mathcal V} S_{us}^{L*} C_{ua}^R \langle \psi_{cv}^L | \hat p^\dagger \hat r^\dagger \hat q | \psi_{ev}^R \rangle \\
        \langle CV | EVCV | EV \rangle &= S_{rq}^{L*} C_{sa}^{R}  \langle \psi_{cv}^L | \hat p^\dagger | \psi_{ev}^R \rangle \\
        \langle CV | EVVC | EV \rangle &=- S_{rs}^{L*} C_{qa}^R  \langle \psi_{cv}^L | \hat p^\dagger | \psi_{ev}^R \rangle \\
        \langle CV | ECCC | EV \rangle &= - \sum\limits_{u \in \mathcal V} C_{ua}^R [ S_{us}^{L*}  \delta_{rq} (1 - \delta_{sq}) - S_{uq}^{L*} \delta_{rs} (1 - \delta_{sq})] \langle \psi_{cv}^L | \hat p^\dagger | \psi_{ev}^R \rangle \\
        \langle EV | EVEE | EE \rangle &= - C_{ra}^{L*} \langle \psi_{ev}^L | \hat p^\dagger \hat q \hat s | \psi_{ee}^R \rangle \\
        \langle EV | ECEE | CV \rangle &= \sum\limits_{t \in \mathcal V} C_{ta}^{L*} S_{tr}^R \langle \psi_{ev} ^L | \hat p^\dagger \hat q \hat s | \psi_{cv} ^R \rangle \\
        \langle EV | EEEE | EV \rangle &= \sum\limits_{t \in \mathcal V} C_{tb}^{L*} C_{ta}^R \langle \psi_{ev}^L | \hat p^\dagger \hat r^\dagger \hat q \hat s | \psi_{ev}^R \rangle \\ 
        \langle EV | ECCE | EV \rangle &= \delta_{rq} \sum\limits_{t \in \mathcal V} C_{tb}^{L*} C_{ta}^R \langle \psi_{ev}^L | \hat p^\dagger \hat s | \psi_{ev}^R \rangle \\
        \langle EV | ECEC | EV \rangle &= -  \delta_{rs} \sum\limits_{t \in \mathcal V} C_{tb}^{L*} C_{ta}^R \langle \psi_{ev}^L | \hat p^\dagger \hat q | \psi_{ev}^R \rangle \\
        \langle EV | EVVE | EV \rangle &= C_{rb}^{* L} C_{qa}^R \langle \psi_{ev}^L | \hat p^\dagger \hat s | \psi_{ev}^R \rangle \\
        \langle EV | EVEV | EV \rangle &= - C_{rb}^{* L} C_{sa}^R \langle \psi_{ev}^L | \hat p^\dagger \hat q | \psi_{ev}^R \rangle 
    \end{aligned}

Issues with Spin
++++++++++++++++++++++++++++

For Beta spin, the wave-function has the similar representation as :eq:`wfn-fast`, such as:

.. math::
    :label: wfn-fast-beta

    \begin{aligned}
    | \Psi_{c\to e}^\beta \rangle &= \sum\limits_{q \in \mathcal C} C_{qi}^* (-)^q \sum\limits_{J^\alpha J^\beta} \psi_{J^\alpha J^\beta}^{c \to e} | C_\alpha \rangle | \mathcal E_{J^\alpha} \rangle | C_\beta^q \rangle | \mathcal E_{J^\beta} \rangle \\ &= (-)^{(N_a + 1) (N_c - 1)}  | C_\alpha \rangle \sum\limits_{J^\alpha J^\beta} \psi_{J^\alpha J^\beta}^{c \to e}  | \mathcal E_{J^\alpha} \mathcal E_{J^\beta} \rangle \sum\limits_{q \in \mathcal C} C_{qi}^* (-)^q | C_\beta^q \rangle \\
    &= (-)^{N_e^2+N_a N_c + N_a(N_a+1)} \sum\limits_{q \in \mathcal C} C_{qi}^* (-)^q | \mathcal C_\beta ^q \rangle \sum\limits_{J^\alpha J^\beta} \psi_{J^\alpha J^\beta}^{c \to e} | \mathcal E_{J^\alpha} \mathcal E_{J^\beta} \rangle | \mathcal C_\alpha \rangle 
    \end{aligned}


in which 

.. math::
    :label: wfn-fast-coeff-beta

    \psi_{J^\alpha J^\beta}^{c \to e} = \sum\limits_{p \in \mathcal E} C_{pa} \mathrm{PF}(J^\beta, p) \, \psi_{J^\alpha J^{\beta'}(J^\beta, p) }
