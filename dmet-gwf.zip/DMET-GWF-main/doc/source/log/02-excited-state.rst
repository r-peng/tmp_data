Excited State I: Exact Implementation of an EOM-Like method
==============================================================

(Updated on Jan 3)

Theory
----------------------------

Reminding the ansatz of EOM-CC where the excited states are parameterized as:

.. math::
    :label: eom-cc-wfn

    | \Psi_k \rangle = \hat R_k | \mathrm{CC} \rangle

in which :math:`| \mathrm{CC} \rangle = \exp(\hat T) | \mathrm{HF} \rangle` and :math:`\hat R_k` is the excitation operator.

For CPS or Gutzwiller-type wave function, we can similarly assume that the excited states can be solved by spanning the bases :math:`\{| \Psi_i^a \rangle \}`:

.. math::
    :label: gwf-ext-bases

    | \Psi_i^a \rangle = \prod\limits_i \hat G_i | \Phi_i^a \rangle

where :math:`| \Phi_i^a \rangle = \hat a^\dagger \hat i | \mathrm{HF} \rangle` is the singly-excited determinant. Since :math:`\{ | \Psi_i^a \rangle \}` and :math:`| \Psi_0 \rangle` may no longer orthogonal to each other (see figure below), we need general eigenvalue problem :math:`\mathrm H \mathrm C = \mathrm S \mathrm C \varepsilon` where the matrix elements of Hamiltonian matrix elements and overlap elements:

.. figure:: ./figure-02/ovlp.png
    :alt: ovlp
    :align: center

.. math::
    :label: ham-elem

    H_{ij}^{ab} = \langle \Psi_{i}^a | \hat H | \Psi_j^b \rangle,\,
    H_i^a = \langle \Psi_0 | \hat H | \Psi_i^a \rangle,\,
    H_{0} = \langle \Psi_0 | \hat H | \Psi_0 \rangle

.. math::
    :label: s-elem

    S_{ij}^{ab} = \langle \Psi_{i}^a | \Psi_j^b \rangle,\,
    S_i^a = \langle \Psi_0 | \Psi_i^a \rangle,\,
    S_{0} = \langle \Psi_0 | \Psi_0 \rangle

We can call the method **EOM-CPS** in the context.

Result: Hydrogen ring
----------------------------

Potential energy surface of ground state and the first excited state.

- Var.: the energy directly from :math:`\dfrac{\langle \Psi_G^\dagger | \hat H | \Psi_G \rangle}{\langle \Psi_G^\dagger | \Psi_G \rangle}`
- xx-0: ground-state energy from EOM-CPS
- xx-y: the yth excite-state energy from EOM-CPS

.. figure:: ./figure-02/pes.png
    :alt: pes
    :align: center

the excitation energy from FCI, EOM-CPS, TDHF and CIS.

.. figure:: ./figure-02/ee-1.png
    :alt: ext-energy
    :align: center

.. figure:: ./figure-02/ee-2.png
    :alt: ext-energy
    :align: center

.. figure:: ./figure-02/ee-3.png
    :alt: ext-energy
    :align: center

the difference between CPS excitation energies and FCI ones

.. figure:: ./figure-02/exte-error.png
    :alt: exte-error
    :align: center

.. note::

    - Excitation energy has error less than 0.06 Hartree (~1.7eV) globally, which is much better than TDHF and CIS result. So it is worth further developing for approximation of excited state.

    - 1-site impurity suffers from the energy cross between ground state and 1st excitation state, but 2-site impurity does not.
    
    - The excitation basis set corrects the ground-state, too.

    - Complexity: EOM-CPS just multiplies :math:`N_O N_V` for calculating the basis set :math:`\{| \Psi_i^a \rangle \}` (which is the major time consumption).
