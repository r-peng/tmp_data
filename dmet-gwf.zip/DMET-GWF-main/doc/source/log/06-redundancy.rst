Redundancies in Exact-TN
=====================================

Redundancies from Real-space View
---------------------------------------------

The exact version of our method, the chosen basis for expanding excited states are:

.. math::
    :label: exact-TN-basis

    | \Psi_{m, {I}} \rangle = | {I}_m \rangle \langle {I}_m | \Psi \rangle

in which :math:`m` is the index of impurity, :math:`{I}` is a configuration on impurity :math:`m`, and :math:`| \Psi \rangle` is the ground-state wave-function.

Here we denote :math:`|\Psi_{m, {IJ}} \rangle \equiv \pmb a_{IJ}^m,\, | \Psi \rangle \equiv \pmb M`, then we have the relationship:

For single-site impurity :math:`m`:

.. math::
    :label: single-site-imp-redund

    \sum\limits_J \pmb a_J^m = \pmb M, \forall m


For multi-site impurity, 

.. math::
    :label: multi-site-imp-redund

    \sum\limits_{J} \pmb a_{m+1}^{IJ} = \hat T \sum\limits_{J} \pmb a_m^{IJ} = \sum\limits_J \pmb a_m^{JI}, \forall I, m.

Here :math:`J` is the configuration for single site and :math:`I` is that of the other sites. For example in the three-site impurities, the number of configuration :math:`I` is :math:`4^{3-1} = 16`. 

Then at least there are :math:`4^{q-1} N` redundancies, where :math:`N` is the length of chain, and :math:`q` is the site number of each impurity.

Redundancies from K-space View
----------------------------------------

The Fourier-transformed wave functions are labeled as:

.. math::
    :label: wfn-k-space

    \tilde a_I^k = \sum\limits_{m=0}^{N-1} \exp(ikm) \hat T^m \pmb a_0^I,\, k = \dfrac{2\pi L}{N}, L = 0, 1, \cdots, N-1.

Then the overlap matrix between different configurations with the same :math:`k` is:

.. math::
    :label: ovlp-k-space

    S_{IJ}^k = \tilde a_I^{k\dagger} \tilde a_I = N \sum\limits_{m=0}^{N-1} \exp(ikm) \pmb a_0^{I \dagger} \hat T^m \pmb a_0^J 

The zero-mode :math:`\pmb b = \sum\limits_J b_J \pmb a_0^J` requires 

.. math::
    :label: zero-mode

    \forall I, \sum\limits_J S_{IJ}^k b_J = N \pmb a_0^{I \dagger} \sum\limits_m \exp(ikm) T^m (\sum\limits_J b_J \pmb a_0^J) = 0
 
we can define the target vector as

.. math::
    :label: target-vector

    \tilde b = \sum\limits_m \exp(ikm) T^m \pmb b

which should be either 0 or located in the compensatory space spanned by :math:`\{ \pmb a_0^I \}`. However, since :math:`\hat T \tilde b = \exp(-ik) \tilde b`, then :math:`\pmb a_{m}^I \tilde b = \pmb a_0^I \hat T^m \tilde b = 0`, so :math:`\tilde b` should be in the compensatory space spanned by :math:`\{ \pmb a_m^I \}, \forall m, I`, which indicates that we only have :math:`\tilde b = 0`.

For multi-site impurities, we guess from the analysis of real space:

.. math::
    :label: multi-site-ansatz

    \pmb b = \alpha \sum\limits_{J} \pmb a_0^{IJ} + \beta \sum\limits_J \pmb a_0^{JI} = (\alpha + \beta \hat T) \sum\limits_{J} \pmb a_0^{IJ}

Then 

.. math::
    :label: tilde-b-from-multisite-ansatz

    \tilde b = \sum\limits_m \exp(ikm) \sum\limits_J (\alpha \hat T^m + \beta \hat T^{m+1}) \pmb a_{0}^{IJ} = (\alpha + \beta \exp(-ik)) \sum\limits_m \exp(ikm) \hat T^{m} \sum\limits_J \pmb a_{0}^{IJ}

which indicates that :math:`\alpha + \beta \exp(-ik) = 0`.

So we can lead to the unnormalized zero modes for each k point and (q-1)-site configuration :math:`I`:

.. important::

    .. math::
        :label: zero-mode-kpt-multisite

        \pmb b_I^k = \exp(-\dfrac{ik}{2}) \sum\limits_{J} \pmb a_0^{IJ} - \exp(\dfrac{ik}{2}) \sum\limits_J \pmb a_0^{JI} 

For multiple sites, Eq. :eq:`zero-mode-kpt-multisite` accounts for :math:`4^{q-1}` redundancies, and is suitable for every :math:`k`-points, but for single site situation, since Eq. :eq:`zero-mode-kpt-multisite` degenerates into the ground-state wave-function itself.

.. math::
    :label: zero-mode-kpt-singlesite

    \pmb b = -2 \sin (k/2) \sum\limits_I \pmb a_0^I = -2 \sin(k/2) \pmb M

then this zero mode only survives when :math:`k \ne 0`.

Comparison with Numerical Results
------------------------------------

For impurity number :math:`q = 1, 2, 3`, the zero mode numbers follow the rule:

.. math::
    :label: zero-mode-numerical

    n = \begin{cases} 4^{q-1} + 1, \, k = 0; \\ 4^{q-1},\, k \ne 0. \end{cases}

which means that there still exist one or two redundancy apart from which we have analysed. The reason why additional redundancy exists in Gamma point is still on the way to figure out.
