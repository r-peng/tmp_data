Approximation of 1-RDM for FCI solver
=========================================

(Updated on Jan 8)

.. warning::

    Severe problem: phase factor!!! Since the sequence of operators goes reversed while implementation, the phase factor of each parts may be wrong.

Intro
---------------

Since it is impratical to directly evaluate of Gutzwiller wave function with Full-CI expansion, we need approximation methods. First we consider the reduced density matrix (1rdm):

.. math::
    :label: 1rdm-general

    \gamma_{pq} = \langle \Psi_G | \hat a^\dagger_p \hat a_q | \Psi_G \rangle

In DMET, the "democratic partition" gives the approximation:

.. math::
    :label: 1rdm-dmet

    \gamma_{pq} \approx \dfrac{1}{2} (\langle \Phi | \hat G^\dagger_{p} \hat a_{p}^\dagger \hat a_q \hat G_{p} | \Phi \rangle + \langle \Phi | \hat G^\dagger_{q} \hat a_{p}^\dagger \hat a_q \hat G_{q} | \Phi \rangle)

But we can add more correlators in the 1rdm approximation. In Eric's evaluation of CPS wave-function energy, similarly transformed Hamiltonian is used:

.. math::
    :label: eric-energy

    E = \langle \Phi | \hat G^{-1} \hat H \hat G | \Phi \rangle

where :math:`| \Phi \rangle` is the reference wave function (mostly the Slater determinant) and the :math:`\hat G` is the Gutzwiller correlator. The 1-rdm is then exactly:

.. math::
    :label: 1rdm-eric

    \gamma_{pq} = \langle \Phi | \hat G^{-1}_{pq} \hat a^\dagger_p \hat a_q \hat G_{pq} | \Phi\rangle

in which :math:`\hat G_{pq}` is the correlator of the *sites containing the index* :math:`p` and :math:`q`. Thus for our situation, we *approximate* 1rdm as:

.. math::
    :label: 1rdm-approx

    \gamma_{pq} \approx \langle \Phi | \hat G^{\dagger}_{pq} \hat a^\dagger_p \hat a_q \hat G_{pq} | \Phi\rangle

Derivation
------------------------------

Unnormalized 1RDM
++++++++++++++++++++

Since unnormalized 1rdm can be decomposed as

.. math::
    :label: 1rdm-dm

    \langle \Phi | \hat G^\dagger_{pq} \hat a^\dagger_p \hat a_q \hat G_{pq} | \Phi \rangle =  \langle \Phi | \hat G^\dagger_p \hat a^\dagger_p \hat G_p \hat G^\dagger_q \hat a_q \hat G_q | \Phi \rangle

then we can consider the auxilliary wave function

.. math::
    :label: gaag

    | \Psi_q \rangle = \hat G_q^\dagger \hat a_q^\alpha \hat G_q | \Phi \rangle

where :math:`q` is the EO index, and :math:`\hat G_q` is the correlator that *contains* index :math:`q`, which writes as:

.. math::
    :label: g_q

    \hat G_q = \sum\limits_{i^\alpha j^\alpha i^\beta j^\beta} g_{\underline{j^\alpha i^\alpha}, \underline{j^\beta i^\beta}} | \mathcal F_{j^\alpha j^\beta} \rangle \langle \mathcal F_{i^\alpha i^\beta} |

here we denote fragement orbitals as :math:`| \mathcal F \rangle`, bath orbitals as :math:`| \mathcal B \rangle`, core orbitals as :math:`| \mathcal C \rangle`, and the underlined index :math:`\underline{ji}` as the index of embedded wave-function basis :math:`| \mathcal F_j \rangle \otimes | \mathcal B_i \rangle`. 

The conjugation of :math:`\hat G_q` is


.. math::
    :label: g_q_dagger

    \hat G_q^\dagger = \sum\limits_{k^\alpha l^\alpha k^\beta l^\beta} g_{\underline{l^\alpha k^\alpha}, \underline{l^\beta k^\beta}}^* | \mathcal F_{k^\alpha k^\beta} \rangle \langle \mathcal F_{l^\alpha l^\beta} |

and the single-fragment DMET wave-function is written as:

.. math::
    :label: g_q_phi

    \hat G_q | \Phi \rangle = \sum\limits_{i^\alpha j^\alpha i^\beta j^\beta} \psi_{\underline{j^\alpha i^\alpha}, \underline{j^\beta i^\beta}} | \mathcal F_{j^\alpha j^\beta} \rangle \otimes | \mathcal B_{i^\alpha i^\beta} \rangle \otimes | \mathcal C \rangle

Then 

.. math::
    :label: results-1rdm

    \begin{aligned}
    \hat G_q^\dagger \hat a_q^\alpha \hat G_q | \Phi \rangle &= \sum\limits_{i^\alpha j^\alpha i^\beta j^\beta} \sum\limits_{k^\alpha l^\alpha k^\beta l^\beta} (g_{\underline{l^\alpha k^\alpha}, \underline{l^\beta k^\beta}}^* \psi_{\underline{j^\alpha i^\alpha}, \underline{j^\beta i^\beta}} \langle \mathcal F_{l^\alpha l^\beta} | \hat a_q^\alpha | \mathcal F_{j^\alpha j^\beta} \rangle ) | \mathcal F_{k^\alpha k^\beta} \rangle \otimes | \mathcal B_{i^\alpha i^\beta} \rangle \otimes | \mathcal C \rangle \\ &= \sum\limits_{i^\alpha k^\alpha i^\beta k^\beta} f_{\underline{k^\alpha i^\alpha}, \underline{k^\beta, i^\beta}}^{(q)}  | \mathcal F_{k^\alpha k^\beta} \rangle \otimes | \mathcal B_{i^\alpha i^\beta} \rangle \otimes | \mathcal C \rangle
    \end{aligned}

where the summation coefficient

.. math::
    :label: fkiq

    \begin{aligned}
        f_{\underline{k^\alpha i^\alpha}, \underline{k^\beta, i^\beta}}^{(q)} &= \sum\limits_{j^\alpha j^\beta l^\alpha l^\beta} g_{\underline{l^\alpha k^\alpha}, \underline{l^\beta k^\beta}}^* \,\psi_{\underline{j^\alpha i^\alpha}, \underline{j^\beta i^\beta}} \,\langle  \mathcal F_{l^\alpha l^\beta} | \hat a_q^\alpha | \mathcal F_{j^\alpha j^\beta} \rangle \\ &= \sum\limits_{j^\alpha j^\beta} g_{\underline{l^\alpha(j^\alpha, q) k^\alpha}, \underline{j^\beta k^\beta}}^* \,\psi_{\underline{j^\alpha i^\alpha}, \underline{j^\beta i^\beta}}\,\delta_{l^\beta, j^\beta}\,\mathrm{PF}(j^\alpha, q) 
    \end{aligned}

in which the phase factor is:

.. math::
    :label: PF

    \mathrm{PF}(j^\alpha, q) = (-)^{n(j^\alpha)} \langle \mathcal F_{l^\alpha(j^\alpha, q)} | \hat a_q^\alpha | \mathcal F_{j^\alpha} \rangle

where :math:`n(j_\alpha)` is the electron number of fragment configuration index :math:`j^\alpha`, and the index :math:`l^\alpha` is uniquely determined by configuration :math:`j^\alpha` and EO index :math:`q`. The table of :math:`q, l^\alpha` and the parity of :math:`\langle \mathcal F_{l^\alpha(j^\alpha, q)} | \hat a_q^\alpha | \mathcal F_{j^\alpha} \rangle` is available in ``pyscf.fci.cistring.gen_des_str_index`` method.

Then we consider the overlap

.. math::
    :label: gag-ovlp

    \langle \Psi_p^\alpha | \Psi_q^\alpha \rangle = \sum\limits_{i^\alpha k^\alpha i^\beta k^\beta} \sum\limits_{\tilde i^\alpha \tilde k^\alpha \tilde i^\beta \tilde k^\beta} f_{\underline{\tilde k^\alpha \tilde i^\alpha}, \underline{\tilde k^\beta \tilde i^\beta}}^{(p)*} f_{\underline{k^\alpha i^\alpha}, \underline{k^\beta i^\beta}}^{(q)} \langle \mathcal C^{(p)} \mathcal B_{\tilde i^\alpha \tilde i^\beta}^{(p)}\mathcal F_{\tilde k^\alpha \tilde k^\beta}^{(p)} | \mathcal F_{k^\alpha k^\beta}^{(q)} \mathcal B_{i^\alpha i^\beta}^{(q)} \mathcal C^{(q)} \rangle

the last term is written as:

.. math::
    :label: slater-ovlp

    \langle \mathcal C^{(p)} \mathcal B_{\tilde i^\alpha \tilde i^\beta}^{(p)}\mathcal F_{\tilde k^\alpha \tilde k^\beta}^{(p)} | \mathcal F_{k^\alpha k^\beta}^{(q)} \mathcal B_{i^\alpha i^\beta}^{(q)} \mathcal C^{(q)} \rangle = \det S^{(pq)}_{\underline{\tilde k^\alpha \tilde i^\alpha}, \underline{k^\alpha i^\alpha}} \det S^{(pq)}_{\underline{\tilde k^\beta \tilde i^\beta}, \underline{k^\beta i^\beta}} 
    
where the matrix :math:`\det S^{(pq)}_{\underline{\tilde k \tilde i}, \underline{k i}}` is cut from the overlap matrix of two EO coefficient :math:`S^{(pq)}`, with the indices determined by the occupation of configuration :math:`\underline{\tilde k^\beta \tilde i^\beta}` and  :math:`\underline{k^\beta i^\beta}`. The overlap matrix :math:`S^{(pq)}` is defined as:

.. math::
    :label: ovlp-mat

    S^{(pq)}_{ji} = \sum\limits_{\mu \nu} \tilde C_{\mu j}^{(p)*} C_{\nu i}^{(q)} \langle \mu | \nu \rangle

where :math:`\mu` and :math:`\nu` are the indices of atomic orbital or localized orbital.

The diagonal block part of 1rdm is:

.. math::
    :label: dm-diag

    \langle \Phi | \hat G^\dagger_{pq} \hat a_p^{\dagger \alpha} \hat a_q^\alpha \hat G_{pq} | \Phi \rangle = \sum\limits_{j^\alpha j^\beta i^\alpha i^\beta} \psi_{\underline{j^\alpha i^\alpha}, \underline{j^\beta i^\beta}}\,\psi^*_{\underline{l^\alpha(j^\alpha, p, q) i^\alpha}, \underline{j^\beta i^\beta}}\,\mathrm{PF}(j^\alpha, p, q)

in which the phase factor

.. math::
    :label: pf-diag

    \mathrm{PF}(j^\alpha, p, q) = \langle \mathcal F_{l^\alpha(j^\alpha, p, q)} | \hat a_q^{\dagger \alpha} \hat a_p^\alpha | \mathcal F_{j^\alpha} \rangle

which is available in ``pyscf.fci.cistring.gen_linkstr_index`` method.

Normalization
++++++++++++++++++++

For the normalization, I will firstly try

.. math::
    :label: normed-1rdm

    \gamma_{pq} = \dfrac{\langle \Phi \hat G^\dagger_{pq} \hat a^\dagger_p \hat a_q \hat G_{pq} | \Phi \rangle}{\langle \Phi | \hat G^\dagger_{pq} \hat G_{pq} | \Phi \rangle}

in which the "overlap" for different fragment

.. math::
    :label: rdm-ovlp

    \langle \Phi | \hat G^\dagger_{pq} \hat G_{pq} | \Phi \rangle = \langle \Phi | \hat G^\dagger_{p} \hat G_{p} \hat G^\dagger_q \hat G_q | \Phi \rangle

and can be treated with the same but easier manner as that in unnormalized 1rdm. For off-diagonal block, we still use the form of Eq. :eq:`gag-ovlp`, but the summation coefficient is:

.. math::
    :label: fkiq_ovlp

    f_{\underline{k^\alpha i^\alpha}, \underline{k^\beta, i^\beta}}^{(q)} = \sum\limits_{j^\alpha j^\beta} \psi_{\underline{j^\alpha i^\alpha}, \underline{j^\beta i^\beta}}\,g^*_{\underline{j^\alpha k^\alpha}, \underline{j^\beta k^\beta}}

The overlap for the same fragment is :math:`1` because single-fragment DMET wave function is naturally normalized:

.. math::
    :label: psi_normalize

    \langle \Phi | \hat G^\dagger \hat G | \Phi \rangle = \sum\limits_{i^\alpha j^\alpha j^\beta i^\beta} | \psi_{\underline{j^\alpha i^\alpha}, \underline{j^\beta i^\beta}} | ^2 = 1

Current Progress and Outlook
------------------------------------

Current Progress
+++++++++++++++++++

- The 1rdm and overlap results based on the formula above are equal to those derived from expansion in Full-CI basis, which shows the correctness.

TODO
+++++++++

- The closeness among 2-correlator 1rdm, exact 1rdm and democratically-partitioned 1rdm, as well as the one-electron Hamiltonian expectation are to be evaluated

- **The evaluation of 2-RDM.** The Correlation Matrix Renormalization (CWR) Theory based on Gutzwiller wave function (J. Chem. Theory Comput. 2016, 12, 4806−4811) uses the Wick theorem to approximate 2-RDM by 1-RDM from GWF, but simultaneously additional Hamiltonian should be added. Since CWR theory shows good results for some simple molecules according to the literature, I would consider its implementation.

Trial: directly using Wick theorem:

.. math::
    :label: approx-2rdm

    \langle \hat e_{pqrs} \rangle_{\Psi_G} = \sum\limits_{\sigma \tau} \langle \hat a^\dagger_{p\sigma} \hat a^\dagger_{r\tau} \hat a_{s\tau} \hat a_{q\sigma} \rangle = \langle \hat E_{pq} \rangle \langle \hat E_{rs} \rangle - \dfrac{1}{2} \langle \hat E_{ps} \rangle \langle \hat E_{rq} \rangle

Therefore

.. math::
    :label: 2rdm

    \Gamma_{pqrs} \approx \gamma_{pq} \gamma_{rs} - \dfrac{1}{2} \gamma_{ps} \gamma_{rq}

Then energy is 

.. math::
    :label: approx-energy

    E = \sum\limits_{pq} \tilde h_{pq} \gamma_{pq}

in which the effective 1e Hamiltonian is

.. math::
    :label: h1e-eff

    \tilde h_{pq} = h_{pq} + \sum\limits_{rs} \dfrac{1}{2} g_{pqrs} \gamma_{rs} - \dfrac{1}{4} g_{psrq} \gamma_{rs} 

