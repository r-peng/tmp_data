Report: Exact Correlator Product State Energies from DMET 
==============================================================

(Last updated on Dec 14, 2022)

Theory
-------------

Projector
+++++++++++++++++++++++++++++

The HF Slater determinant in the *impurity* or *fragment* bases (note: not the primitive localized orbitals!!!) can be written as the CI form:

.. math::
    :label: slater

    | \Phi \rangle = \prod\limits_{i=1}^{N} \hat a_{i\uparrow}^\dagger | - \rangle \otimes \prod\limits_{i=1}^N \hat a_{i\downarrow}^\dagger | - \rangle = \sum\limits_{\lambda \mu} \det C_\lambda \det C_\mu \hat a^\dagger_{\lambda \uparrow} | - \rangle \otimes \hat a_{\mu \downarrow} | - \rangle

in which the :math:`\lambda` and :math:`\mu` are the occupation configurations in the localized orbitals, and :math:`C_\lambda` is the configuration slices of LO->MO transformation matrix. Then the Full-CI parameter of configuration :math:`(\lambda,\mu)` is :math:`\det C_\lambda \det C_\mu`.

Then the projector of every site is subsequently operated onto the Slater determinant by identifying whether the electron/hole in each projection term exist on the configurations. The projector of each site is **determined by DMET**, *i.e.*, the Hartree-Fock and CI coefficients from the single-site DMET calculation.

Assuming that Hartree-Fock wave function in DMET is

.. math::
    :label: dmet-slater

    | \Phi \rangle = \sum\limits_{i} \lambda_i | \alpha_i \rangle \otimes | \beta_i \gamma \rangle

in which :math:`\alpha_i` are configurations of inpurity orbitals, :math:`\beta_i` are those of bath orbitals and :math:`| \gamma \rangle` is core orbital. Then theoretically, the high-level DMET wave function can be represented as:

.. math::
    :label: dmet-corr-wfn

    | \Psi \rangle = \sum\limits_{ij} \psi_{ji} | \alpha_j \rangle \times | \beta_i \gamma \rangle = \hat P | \Phi \rangle

where the projection operator is

.. math::
    :label: projorb-1

    \hat P = \sum\limits_{ji} | \alpha_j \rangle \dfrac{\psi_{ji}}{\lambda_i}\langle \alpha_i |

However, for the single-site problem (with :math:`S_z = 0`), since we only have four types of frag-bath occupation:

.. math::

    | \rangle \otimes | \uparrow \downarrow \rangle,\, | \uparrow \rangle \otimes | \downarrow \rangle, \, | \downarrow \rangle \otimes | \uparrow \rangle ,\, | \uparrow\downarrow \rangle \otimes | \rangle

So it is easy to show that projector is diagonal:

.. math::
    :label: projorb-2

    \hat P = \sum\limits_i | \alpha_i \rangle \dfrac{\psi_i}{\lambda_i} \langle \alpha_i | 

If we assume that the Gutzwiller wave function is directly the *product of projectors of each site*, or the correlator product state (CPS):

.. math::
    :label: gutzwilller-wfn
    
    | \Psi \rangle = \hat G | \Phi \rangle = \prod\limits_{a} \hat P_a | \Phi \rangle

"Variational" Energy
++++++++++++++++++++++++

Firstly we consider an inefficient evaluation of correlator product states (CPS) energy by a "variational" manner, i.e. directly calculating the Hamiltonian expectation by normalized CPS. 

Since :math:`\hat P_i | \Phi \rangle` is normalized but generally :math:`\hat G | \Phi \rangle` may not be normalized, then the expectation of energy is evaluated as:

.. math::
    :label: energy

    E = \dfrac{\langle \Phi | \hat G^\dagger \hat H \hat G | \Phi \rangle }{\langle \Phi | \hat G^\dagger \hat G | \Phi \rangle}

Similarity Transformed Energy
+++++++++++++++++++++++++++++++++++

Assuming that the wave function the eigenvalue of Hamiltonian:

.. math::
    :label: schrodinger-gwf

    \hat H \hat G | \Phi \rangle = E \hat G | \Phi \rangle

Then we have

.. math::
    :label: e-st-gwf

    E = \langle \Phi | \hat G^{-1} \hat H \hat G | \Phi \rangle

For projector with dianogal form:

.. math::
    :label: p-diagonal

    \hat P = \sum\limits_i p_i | \alpha_i \rangle  \langle \alpha_i |

its inverse is

.. math::
    :label: p-diag-inverse

    \hat P^{-1} = \sum\limits_i p_i^{-1} | \alpha_i \rangle \langle \alpha_i | 

Results and discussions
--------------------------

Hydrogen ring
+++++++++++++++++++++

The PES of :math:`\mathrm{H_{10}}` ring using HF, FCI, 1-site DMET, 2-site DMET and the expectation value of CPS wave function. The green "CPS(1H)" means the direct expectation value of single-site CPS wave function, and purple "CPS(2H)" means the two-site CPS wave function result, which needs non-symmetric projection operator :eq:`projorb-1`.

.. figure:: ./figure/Hring-va-pes.png
   :alt: PES
   :align: center

with the correlation energy that each methods saves:

.. figure:: ./figure/Hring-va-corr.png
    :alt: corr
    :align: center


From the results we get
- The Gutzwiller-type wave function only restores :math:`\sim 50\%` correlation energy than FCI;
- The correlation energy percent increases when the bond length of :math:`\mathrm{H_{10}}` increases.

For CPS energies, "VA" means the energy directly calculated from CPS wave function, and "ST" means energy calculated by similarity transformation method.

.. figure:: ./figure/Hring-st-pes.png
   :alt: PES
   :align: center

.. figure:: ./figure/Hring-st-corr.png
    :alt: corr
    :align: center

One can see from the plot that similarity transformed energies of :math:`\mathrm{H_{10}}` ring fits well before the equlibrium bond length, but fall behind FCI result and even collapse afterward.

Hubbard Model
+++++++++++++++++

Implementation Details:

- 2D :math:`3 \times 4` spin Hubbard model with open boundary condition (OBC)
- Bath of DMET are chosen from the Restricted HF result without corrlation potential fitting.
- "DMET-1S" means each fragment has one site 
- "DMET-2S" means each fragment has two sites
- "CPS-VA" means "variational" CPS energy
- "CPS-ST" means similarity transformed CPS energy


The first two figures trace the energy change with the increment of parameter :math:`U` in Hubbard model, while fixing the occupation number as 12(half occupied).

.. figure:: ./figure/Hubbard_34_N12_PES.png
    :alt: HUB-N12-PES
    :align: center

.. figure:: ./figure/Hubbard_34_N12_CORR.png
    :alt: HUB-N12-CORR
    :align: center

The last two figures shows the energy and the recovery of correlation energy changing with the occupation number, while fixing :math:`U/t = 2`.

.. figure:: ./figure/Hubbard_34_U2_PES.png
    :alt: HUB-U2-PES
    :align: center

.. figure:: ./figure/Hubbard_34_U2_CORR.png
    :alt: HUB-U2-CORR
    :align: center

From the hubbard model results we get:

- The "variational" CPS energy is acceptable and relatively near FCI and DMET result;
- The similarity transformed CPS energy suffers from underestimation, and may give the wrong behaviour with the increment of interaction intensity (parameter :math:`U`), but the response to occupation number is not such obvious. **Further optimization of the parameters in CPS(or Gutzwiller-type function) is still needed.**
