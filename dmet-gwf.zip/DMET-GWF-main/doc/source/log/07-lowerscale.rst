Lowering the Scaling of Excited-State Calculation
=========================================================

The major part of current implementation is solving the DMET problem of the combined impurity $x+y+z$, in which :math:`x,y,z` are the site of differentiated bra, ket and the physical observable, respectively. If no symmetry is considered, the number of impurity :math:`x,y,z` is in order $O(N^3)$ where :math:`N` is the size of the system.

However we can consider the limit that impurity :math:`x` is far from an impurity :math:`y`. In general the configuration :math:`I+J` in DMET wave-function of impurity :math:`x+y`:

.. math::
    :label: dmet-wfn-ij

    | \Psi_{IJ}^{xy} \rangle = \sum\limits_{I', J'} \xi_{IJ, I'J'} | \mathcal F_{IJ}^{xy} \mathcal B_{I'J'}^{xy} \rangle | \mathcal C \rangle

in which the impurity :math:`|\mathcal F_{I} \mathcal B_{I'}\rangle`` and :math:`|\mathcal F_J \mathcal B_{J'}\rangle` has the entanglement. But if :math:`x` is far from :math:`y`, the entanglement is ignorable and the wave-function can be approximated as:

.. math::
    :label: dmet-wfn-i-j

    | \Psi_{IJ}^{xy} \rangle = \sum\limits_{I'} \lambda_{II'} | \mathcal F_I^{x} \mathcal B_{I'}^{x} \rangle \sum\limits_{J'} \mu_{JJ'} | \mathcal F_J^{y} \mathcal B_{J'}^{y} \rangle | \mathcal C \rangle

in which :math:`\lambda_{II'}` and :math:`\mu_{JJ'}` come to the coefficients from solving the DMET problem by only treating the sites :math:`x` or :math:`y` as the impurity. 

Then we get the approximation of quantities:

.. important::

    .. math::
        :label: ham

        \langle \Psi_{I0}^{xy} | \hat O_y | \Psi_{I'0}^{xy} \rangle  \approx \langle \Psi_{I}^{x} | \Psi_{I'}^{x} \rangle \langle \Psi^{y} | \hat O_y | \Psi^{y} \rangle 

    .. math::
        :label: ham2

        \langle \Psi_{I0}^{xy} | \hat O_x \hat O_y | \Psi_{0J}^{xy} \rangle\approx \langle \Psi_I^x | \hat O_x | \Psi^x \rangle \langle \Psi^y | \hat O_y | \Psi_J^y \rangle = \sum\limits_{I'J'} \langle \Psi_I^x | \hat O_x | \Psi_{I'}^x \rangle \langle \Psi_{J'}^y | \hat O_y | \Psi_{J}^y \rangle 

So that for the impurities that are far away from each other, we can use the single impurities to estimate the combined impurities, therefore the scaling can be efficiently reduced to linear :math:`O(N)`.
