K-Labeling 
========================

The transformation of operators is 

.. math::
    :label: transformation

    \hat C_n \hat a^\dagger_{i \sigma} \hat C_n^{-1} = \hat a^\dagger_{i+1, \sigma}

The Hamiltonian of PBC Hubbard is invariant under transformation.

