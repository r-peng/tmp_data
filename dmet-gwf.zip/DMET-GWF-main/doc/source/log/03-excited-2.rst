Excited State II: EOM + Democratic Partitioning
=========================================================

Theory
------------

Democratic Partitioning of Different Bra and Ket
++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Here we use *tilde* :math:`\sim` and *prime* :math:`p', q', \cdots` to represent LO basis. Then the 1e and 2e transition Hamiltonians :math:`H_{jb\sigma', ia\sigma} =H^{LR} =  E_{1e}^{LR} + E_{2e}^{LR}` are

.. math::
    :label: l-e1e-r 

    \begin{aligned}
        E_{1e}^{LR} &= \sum\limits_{p'q'} \tilde h_{p'q'} \langle \Psi_L | \tilde E_{p'q'} | \Psi_R \rangle \\ &= \sum\limits_x \sum\limits_{p' \in x} \sum\limits_{q'} \tilde h_{p'q'} \langle \Psi_L^{(x_{p'})} | \tilde E_{p'q'} | \Psi_R^{(x_{p'})} \rangle \\
        &= \sum\limits_x \sum\limits_{p \in x} \sum\limits_{q} h_{pq} \langle \Psi_L^{(x)} | \hat E_{pq} | \Psi_R^{(x)} \rangle
    \end{aligned}

.. math::
    :label: l-e2e-r

    \begin{aligned}
        E_{2e}^{LR} &= \dfrac{1}{2} \sum\limits_{p'q'r's} \tilde g_{p'q'r's'} \langle \Psi_L | \tilde e_{p'q'r's'} | \Psi_R \rangle \\ 
        &= \dfrac{1}{2} \sum\limits_x \sum\limits_{p' \in x} \sum\limits_{q'r's'}\tilde g_{p'q'r's'} \langle \Psi_L^{x(p')} | \tilde e_{p'q'r's'} | \Psi_R^{x(p')} \rangle \\
        &= \dfrac{1}{2} \sum\limits_x \sum\limits_{p \in x} \sum\limits_{qrs} g_{pqrs} \langle \Psi_L^{(x)} | \hat e_{pqrs} | \Psi_R^{(x)} \rangle 
    \end{aligned}

Now the normal indices represent the *embedding* and *core* orbitals of the impurity :math:`x`.

Basis Set and EOM Function
+++++++++++++++++++++++++++++

The basis set of each single-excitation is 

.. math::
    :label: eomdp-basis-set

    | \Psi_{ia \sigma}^{(x)} \rangle = \hat a^{\dagger\sigma}_{a} \hat a^\sigma_i | \Psi^{(x)} \rangle

which satisfies that the basis set will be the same as CIS basis in HF-in-HF embedding.

The excitation operator :math:`\hat a^{\dagger\sigma}_{a} \hat a^\sigma_i` is at *molecular orbitals*, and it has expansion in ``emb+core+vir`` orbital of one impurity

.. math::
    :label: mo-to-ecv

    \hat a^{\dagger \sigma}_a \hat a_i^\sigma = \sum\limits_{p,q} C_{pa} C_{qi}^* \hat a_{p}^{\dagger \sigma} \hat a_q^{\sigma} = \sum\limits_{p,q \in \mathrm{\mathcal E \mathcal C \mathcal V}} S_{pq} \hat a_{p}^{\dagger \sigma} \hat a_q^{\sigma}

here the ``vir`` means the virtual orbital with no entanglement with embedding space, which can be acquired from the SVD of the ghost density matrix with all the embedding and core orbitals singly occupied.

And the EOM Hamiltonian is just substituting the :math:`\langle \Psi_L |` and :math:`| \Psi_R \rangle` in :eq:`l-e1e-r` and :eq:`l-e2e-r` into :math:`\langle \Psi_{jb\sigma'} |` and :math:`| \Psi_{ia\sigma} \rangle`.

Overlap may have multiple ways to define, but we can still choose a democratic-partitioning style such as

.. math::
    :label: def-ovlp

    S_{jb\sigma',ia\sigma} = \sum\limits_{x}\dfrac{N_a^{(x)}}{N} \langle \Psi_{jb\sigma'}^{(x)} | \Psi_{ia\sigma'}^{(x)} \rangle

and we solve the generalized eigenvalue problem

.. math::
    :label: eigenvalue

    \mathrm{HC = SC \epsilon}


Results
-----------------------

Hydrogen Ring
++++++++++++++++++++++

.. figure:: ./figure-03/hring-compare-ecv.png
    :alt: ext-energy
    :width: 85%
    :align: center

.. figure:: ./figure-03/hring-compare-cps.png
    :alt: ext-energy-2
    :width: 85%
    :align: center