踩坑指南
===================

1. 如果需要给numpy矩阵的某些行列赋值，需要使用 ``numpy.ix_`` 来对横纵index进行索引（相当于指针），而非直接划取slice（相当于copy数值）。即需要进行如下操作

.. code-block:: python

    a[np.ix_(fragx, fragy)] = b

千万不能用

.. code-block:: python

    a[fragx][:,fragy] = b