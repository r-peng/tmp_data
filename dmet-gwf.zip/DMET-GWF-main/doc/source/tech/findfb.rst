Identification of Fragment and Bath Orbital
====================================================

(Updated on Jan 17)

In current code (``dmet/solver.py``), the matrix :math:`P, Q` strictly follows the construction of Boxiao's thesis, and the singular value of them are strictly :math:`\Gamma` and :math:`1-\Gamma`, respectively. 

Then the correspondence of orbital is strictly :math:`\beta_i = 2^{n_A} - \alpha_i`.

The previous ``get_proj`` function in ``cpskit/fci.py`` is 

.. code-block:: python

    def get_proj(ci_slater, ci_dmet, nocc):

        l = np.zeros_like(ci_dmet)  # l_{ji} = \lambda_i 
        strab = list(make_strings(range(2*nocc), nocc))
        badict = {}
        
        for i in range(len(strab)):
            
            stra = strab[i]     # 
            betaa = stra >> nocc
            for j in range(len(strab)):
                c = ci_slater[i,j]
                strb = strab[j]
                betab = strb >> nocc

                if not np.allclose(c, 0):   # to be changed ...
                    badict[betaa] = stra-betaa*2**nocc
                    badict[betab] = strb-betab*2**nocc  # mapping \beta_i -> \alpha_i


                    # Choose all the configuration that satisfies |alpha_j> * |beta_i>
                    str_betaa = [x for x in strab if x>>nocc == betaa]  
                    str_betab = [x for x in strab if x>>nocc == betab]

                    for sa in str_betaa:
                        aidx = strab.index(sa)
                        for sb in str_betab:
                            bidx = strab.index(sb)

                            l[aidx,bidx] = c    # L_{ji} = L_{i}
        # print("p = ", ci_dmet / l)
        return ci_dmet / l, badict  # return p_{ji} = c_{ji}/L_{i}

which identifies fragment-bath pair when the matrix element of determinant is not zero. However this method suffers from inefficiency and numerical error. Due to the notes above, the modified inner cycle is just

.. code-block:: python

    def get_proj(ci_slater, ci_dmet, nocc):

        l = np.zeros_like(ci_dmet)  # l_{ji} = \lambda_i 
        strab = list(make_strings(range(2*nocc), nocc))

        for i in range(2**nocc):
            
            betaa = 2*nocc-i
            stra = i + 2**nocc*betaa  # |\alpha_i\rangle \otimes |\beta_i\rangle

            stridxa = strab.index(stra)

            str_betaa = [x for x in strab if x>>nocc == betaa]

            for j in range(2**nocc):
                betab = 2*nocc - j
                strb = j * 2**nocc*betab

                stridxb = strab.index(strb)

                c = ci_slater[stridxa, stridxb]

                str_betab = [x for x in strab if x>>nocc == betab]

                for sa in str_betaa:
                    aidx = strab.index(sa)
                    for sb in str_betab:
                        bidx = strab.index(sb)

                        l[aidx,bidx] = c
        # print("p = ", ci_dmet / l)
        return ci_dmet / l  # return p_{ji} = c_{ji}/L_{i}