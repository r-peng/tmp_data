#include <pybind11/pybind11.h>
#include <iostream>

namespace py = pybind11;

char *p1 = "Hello world!";
int p2[4] = {0, 1, 2, 3};

void test_print()
{
    std::cout << p1 << std::endl;
}

PYBIND11_MODULE(api, m)
{
    m.doc() = "pybind11 example module";
    m.def("test_print", &test_print);
    m.attr("p1") = p1;
    m.attr("p2") = p2;
}