Recap of Density Matrix Embedding Theory (DMET)
======================================================

Schmidt Decomposition of Wave function
------------------------------------------

Assume the wave function of the system can be written as:

.. math::
    :label: exact-wf

    | \psi \rangle = \sum\limits_{i,j} \Psi_{ij} | \psi_i^A \rangle \otimes | \psi^B_j \rangle

By implementing Schmidt decomposition, we can get

.. math::
    :label: exact-wf-schmidt

    | \psi \rangle = \sum\limits_i \sigma_i | \alpha_i \rangle \otimes | \beta_i \rangle

where the :math:`| \alpha_i \rangle` and :math:`| \beta_i \rangle` are the orthornormally transformed in their own spaces. However, since we usually do not know the full correlated wave function of the system, we can start from the Slater determinant.

The slater determinant can be written as the creation operators on the vacant:

.. math::
    :label: slater-primit

    | \psi \rangle = \hat c^\dagger_1 \cdots \hat c^\dagger_N | 0 \rangle

where :math:`N` is the number of electrons. Operating rotations *on the occupied orbitals*:

.. math::
    :label: rot-op

    \tilde c_k^\dagger = \sum\limits_{j=1}^N R_{jk} \hat c_j^\dagger

and we can get the rotated Slater determinant:

.. math::
    :label: slater-rot

    | \tilde \psi \rangle = \tilde c_1^\dagger \cdots \tilde c_N^\dagger | 0 \rangle = \det R | \psi \rangle

Only a phase factor difference to :math:`| \psi \rangle`. 

For embedding problems, we'd like to separate the system into "fragment" and "environment", which can be done by localization of the whole sets of molecular orbitals :math:`\hat a^\dagger_\mu`, which has the relationship

.. math::
    :label: lo-mo-eo

    \hat c^\dagger_i = \sum\limits_{\mu = 1}^n C_{\mu i}\hat a^\dagger_\mu; \tilde c^\dagger_k = \sum\limits_{\mu = 1}^n \tilde C_{\mu k} \hat a^\dagger_\mu

where :math:`n` is the number of molecular orbitals (occupied + virtual), and we can find a LO->EO transformation Matrix s.t.

.. math::
    :label: lo-eo

    \tilde C = CR = \begin{bmatrix} P & 0 \\ Q & E \end{bmatrix}

The dimension of :math:`P, Q, E` are :math:`n_A \times n_A,\, n_B \times n_A,\, n_B \times (N - n_A)`, respectively.

*Columns* of :math:`P, Q` and :math:`E` are all orthorgonal to each other. In fact it is easy to realize. Considering density matrix

.. math::
    :label: dm-decomp

    \rho = \tilde C \tilde C^\dagger = CC^\dagger = \begin{bmatrix} PP^\dagger & PQ^\dagger \\ QP^\dagger & QQ^\dagger + EE^\dagger \end{bmatrix} = \begin{bmatrix} \rho_A & \rho_{AB} \\ \rho^\dagger_{AB} & \rho_B \end{bmatrix}

We diagonize :math:`\rho_A = U \Gamma U^\dagger` and then we can choose

.. math::
    :label: p-q

    P = U\Gamma^{1/2},\, Q = (P^{-1} \rho_{AB})^\dagger

Since 

.. math::
    :label: ortho-cond
    
    I = \tilde C^\dagger \tilde C = \begin{bmatrix}P^\dagger P + Q^\dagger Q & Q^\dagger E \\ E^\dagger Q & E^\dagger E\end{bmatrix}

Then we get :math:`P^\dagger P = \Gamma, \, Q^\dagger Q = 1 - \Gamma` and :math:`Q^\dagger E = 0`.

From :math:`P. Q` and :math:`E`, we can define the new sets of orthonormal creaction operators for each parts:

.. math::
    :label: new-op
    
    \hat c^\dagger_{A, k} = \dfrac{1}{p_k} \sum\limits_{i = 1}^{n_A} P_{ik} \hat a^\dagger_i, k = 1, 2, \cdots, n_A \\
    \hat c^\dagger_{B, k} = \dfrac{1}{q_k} \sum\limits_{j = 1}^{n_B} Q_{jk} \hat a_{j+n_A}^\dagger, k = 1, 2, \cdots, n_A \\
    \hat c^\dagger_{B, l} = \sum\limits_{j=1}^{n_B} E_{j,l} \hat a_{j+n_A}^\dagger, l = n_A + 1, \cdots, N.

Then the Slater determinant can be written as:

.. math::
    :label: slater-svd

    | \psi \rangle = \prod\limits_{i=1}^{n_A} (p_k \hat c_{A, k}^\dagger + q_k \hat c_{B, k}) \prod\limits_{l = n_A + 1}^{N} \hat c_{B, l}^\dagger | 0 \rangle \\  
    = \sum\limits_{i_1, \cdots, i_{n_A} \in \{0,1\}} \prod\limits_{k=1}^n p_k^{i_k} q_k^{1-i_k} | i_1 \cdots, i_{n_A} \rangle_A \otimes | 1-i_1, \cdots, 1-i_{n_A}; \Psi_c \rangle_B

this result shows that Slater deterninant can be separated to fragment, bath and unentangled parts, where :math:`n_A` electrons are allocated to :math:`2n_A` fragment+bath orbitals, and the unentangled ones :math:`|\Psi_c \rangle` remains doubly occupied.

Details of DMET Algorithm
-----------------------------

Embedding Hamiltonian
++++++++++++++++++++++++++

The single-electron part of Hamiltonian in an embedded space :math:`A_x + B_x` is 

.. math::
    :label: hemb-1e

    \hat h^x = \sum\limits_{kl}^{\mathrm{frag+bath}} [t_{kl} + \sum\limits_{m,n}^{\mathrm{core}} [(kl|mn) - (kn|ml)] D_{mn}^{\mathrm{env},x}] \hat c_k^\dagger \hat c_l = \sum\limits_{kl}^{\mathrm{frag+bath}}
    \tilde h_{kl}^x \hat c_k^\dagger \hat c_l

Here the notation changes: :math:`\hat c_k` are in the fragment+bath space. And the hole embedded Hamiltonian :math:`\hat H_{emb}^x` is written as:

.. math::
    :label: dmet-hemb
    
    \hat H_{\mathrm{emb}}^x = \sum\limits_{kl}^{\mathrm{frag+bath}}  \tilde h_{kl}^x \hat c_k^\dagger \hat c_l + \sum\limits_{klmn}^{\mathrm{frag+bath}} (kl|mn) \hat c_k^\dagger \hat c_m^\dagger \hat c_n \hat c_l - \mu_{\mathrm{glob}} \sum\limits_r^{\mathrm{frag}} \hat c^\dagger_r \hat c_r

Global Chemical Potential and Correlation Potential
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

The **global chemical potential** :math:`\mu_{\mathrm{glob}}` here is defined to keep the electron in the fragment site (trace of DM block) the same as :math:`n_A`.

In addition, in order to mimic the mean-field wave function and **correlated wave function**, the determination of *mean-field density matrix* can be done by adding a correlation 1-electron potential into the *mean-field Hartree-Fock*:

.. math::
    :label: corr-pot

    \hat C_x = \sum\limits_{kl}^{\mathrm{frag}} u_{kl}^{x} \hat c_k^\dagger \hat c_l \\
    \hat F \leftarrow \hat F + \sum\limits_x \hat C_x

the metric of determining :math:`\hat C_x` is multiple, and one can use the similarity of 1rdm, *i.e.* minimizing the penalty function:

.. math::
    :label: cost-function

    \mathrm{CF_{full}}(u) = \sum\limits_x \sum\limits_{rs}^{\mathrm{frag+env}(x)} (D_{rs}^x - D_{rs}^{mf}(u)) ^ 2

in which :math:`D_{rs}^x` is the density matrix of correlated wave function, and :math:`D_{rs}^{mf}(u)` is the density matrix from Hartree-Fock solution with the correlation potential :math:`\hat C_x`. However practically, the L2 penalty function may encounter the uncertainty problem. Therefore we provided an alternative way of removing the uncertainty of correlation potential: Assuming that we want to minimize a single-electron Hamiltonian :math:`\langle \Phi | \hat h | \Phi` so that

.. math::
    :label: st

    \forall x, D_{rs}^{mf}(\Phi) = D_{rs}^x

and considering that the *dual* of this problem is convex: 

.. math::
    :label: dual-problem

    \max_{U} \min_{\Phi} \langle \Phi | \hat h | \Phi \rangle + \sum\limits_x \sum\limits_{rs} u_{sr}^x (D_{rs}^{mf}(\Phi) - D_{rs}^{x})

we can work on the dual problem Eq. :eq:`dual-problem` to find optimal :math:`\{u_{sr}^x\}`. The :math:`\hat h` is often chosen as the initial Fock matrix and remain fixed.

Evaluation of DMET Energy
++++++++++++++++++++++++++++++++++++

The **energy** of each fragment:

.. math::
    :label: dmet-ex

    E_x = \sum\limits_{p\in A_x} [\sum\limits_{q}^{\mathrm{frag+bath}} \dfrac{t_{pq} + \tilde h_{pq}^x}{2} D_{qp}^{x} + \dfrac{1}{2} \sum\limits_{qrs}^{\mathrm{frag+bath}}(pq|rs) P_{qp|sr}^x ]

which avoids double counting of unentangled contribution to each fragment, and therefore the total energy is the summation of different parts:

.. math::
    :label: dmet-etot

    E = E_{\mathrm{nuc}} + \sum\limits_x E_x

In a nutshell, DMET approximates the total energy from the correlation energy of each parts.

Restricted Open Shell Scheme
--------------------------------------------

