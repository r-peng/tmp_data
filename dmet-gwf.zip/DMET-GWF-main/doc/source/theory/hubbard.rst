Implementation of Hubbard Model
========================================

Spinless
-----------------------

Spinless Hubbard model Hamiltonian is:

.. math::
    :label: spinless-hubbard

    \hat H = \sum\limits_{\langle PQ \rangle} -t(\hat a^\dagger_P \hat a_Q + \hat a^\dagger_Q \hat a_P) + U \hat a_P^\dagger \hat a_P \hat a^\dagger_Q \hat a_Q

where :math:`P,R,Q,S` are the indices of *sites*. comparing the spinless ab-initio Hamiltonian:

.. math::
    :label: spinless-abinit

    \hat H = \sum\limits_{PQ} h_{PQ} \hat a^\dagger_P \hat a_Q + \dfrac{1}{2} \sum\limits_{PQRS} g_{PQRS} \hat a^\dagger_P \hat a^\dagger_R \hat a_S \hat a_Q + E_{\mathrm{nuc}}

we find that the two-body eri can be written as:

.. math::
    :label: g2e

    g_{PQRS} = \tilde g_{PR} \delta_{PQ} \delta_{RS}

where :math:`\tilde g_{PR} = 2U` if :math:`P` and :math:`R` are at the nearest neighbor. For other situation, it is zero.

Spin
--------------

Hamiltonian for spin Hubbard model is

.. math::
    :label: spin-hubbard

    \hat H = \sum\limits_{\langle pq\rangle \sigma} -t \hat a^\dagger_{p\sigma} \hat a_{q\sigma} + \sum\limits_{p} U \hat a^\dagger_{p\uparrow} \hat a_{p\uparrow} \hat a^\dagger_{p\downarrow} \hat a_{p\downarrow}

Then the Hartree-Fock energy is:

.. math::
    :label: spin-hubbard-hf

    E = 2 \sum\limits_{\mu\nu} \sum\limits_a^{occ} C^*_{\mu a} C_{\nu a} h_{\mu \nu} + U \sum\limits_{ab}^{occ} \sum\limits_\mu C^*_{\mu a} C_{\mu a} C^*_{\nu a} C_{\nu a}

and the energy gradient is

.. math::
    :label: spin-hubbard-grad

    \dfrac{1}{2} \dfrac{\partial E}{\partial C_{\mu a}^*} = \sum\limits_\mu h_{\mu \nu} C_{\nu a} + \dfrac{U}{2} D_{\mu \mu} C_{\mu a}

and the Fock matrix is:

.. math::
    :label: spin-hubbard-fock

    F_{\mu \nu} = h_{\mu \nu} + \dfrac{U}{2} \sum\limits_{\nu} D_{\mu \mu} \delta_{\mu \nu}

But for Full-CI, it is better to solve in the MO bases, so we should get the ERI. The ERI for site is just:

.. math::
    :label: eri-ao

    g_{\mu\nu\kappa \lambda} = U \delta_{\mu \nu \kappa \lambda} 

K Points

.. math::
    :label: hubbard-kpt

    h_{kk'} = -2t\cos k \delta_{kk'},\, g_{kk'k''k'''} = \dfrac{U}{L} \delta_{k+k''-k'-k'''},\, k = \dfrac{2\pi N}{L}, N = 0, \cdots, L-1