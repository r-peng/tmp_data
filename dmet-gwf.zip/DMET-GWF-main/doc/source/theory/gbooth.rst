George Booth DMET Wave function
===================================================================

The density of democratic partitioning in DMET does not fulfill the N-representability, that is, the density matrix can be derived from a valid **global** wave function. So could we write some wave functions?

George Booth put forward a full-system wave function:

.. math::
    :label: gbooth-wfn

    | \Phi \rangle = \sum\limits_x^{N^{\mathrm{frag}}} \hat P^x | \Psi^x \rangle


in which the projection operator

.. math::
    :label: proj-op-x

    \hat P^x = \sum\limits_i^{N^x} | \psi_i^x \rangle \langle \psi_i^x |

and we write the matrix form under some MO as

.. math::
    :label: proj-mat-mo

    P^x_{pq} = \sum\limits_i^{N^x} (\mathrm C^T \mathrm S \mathrm C_f^x)_{pi} (\mathrm C^T \mathrm S \mathrm C_f^x)_{qi}

and :math:`| \Psi^x \rangle` is the total single-impurity DMET wave function for each impurity :math:`x`.

if we define the difference between the single-impurity wfn and the reference

.. math::
    :label: wfn-diff

    | \Delta \Psi^x \rangle = | \Psi^x \rangle - | \Phi \rangle,\, | \Psi \rangle = | \Phi \rangle + \sum\limits_x^{N^{\mathrm{frag}}} \hat P^x | \Delta \Psi^x \rangle

where the wave function can be generated using linear parameterization:

.. math::
    :label: lin-param-dpsi

    | \Delta \Psi \rangle = \sum\limits_x^{N^{\mathrm{frag}}} \sum\limits_i^{N_{occ}^x} \sum\limits_a^{N_{vir}^x} (\hat P^x C_1^x)_i^a | \Phi_i^a \rangle \\ + \sum\limits_x \sum\limits_{ij}^{N_{occ}^x} \sum\limits_{ab}^{N_{vir}^x} (\hat P^x C_1^x)_{ij}^{ab} | \Phi_{ij}^{ab} \rangle

or using exponential parameterization:

.. math::
    :label: exp-param-dpsi

    | \Delta \Psi \rangle = \sum\limits_x^{N^{\mathrm{frag}}} \sum\limits_i^{N_{occ}^x} \sum\limits_a^{N_{vir}^x} (\hat P^x T_1^x)_i^a | \Phi_i^a \rangle \\ + \sum\limits_x \sum\limits_{ij}^{N_{occ}^x} \sum\limits_{ab}^{N_{vir}^x} (\hat P^x T_1^x)_{ij}^{ab} | \Phi_{ij}^{ab} \rangle \\ + \sum\limits_{xy} \sum\limits_i^{N_{occ}^x} \sum\limits_j^{N_{occ}^y} \sum\limits_{a}^{N_{vir}^x} \sum\limits_b^{N_{vir}^y} (\hat P^x T_1^x)_i^a (\hat P^y T_1^y)_j^b | \Phi^{ab}_{ij} \rangle

The calculation of energy can follow two routines: 

- Directly calculation from wave function :math:`E[\Psi] = \langle \Phi | \hat H  | \Psi \rangle`;
 
- or generate from one-body and two-body density matrices, called :math:`E[(\gamma, \Gamma)[\Psi^x]]`.