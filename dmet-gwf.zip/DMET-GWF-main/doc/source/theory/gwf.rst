Gutzwiller Wavefunction (GWF) Ansatz
===========================================


Operator on a specific configuration:

.. math::
    :label: proj-1

    \hat m_i = | \alpha_i \rangle \langle \alpha_i | = \prod\limits_{\sigma \in i} \hat n_\sigma \prod\limits_{\sigma' \in \bar i} (1 - \hat n_\sigma')

in which :math:`i` is the notation of a configuration in some site, and :math:`\bar i` denotes the configurations in this site other than configuration :math:`i`.

For :math:`i \ne j`, if we define :math:`k = i \cap j`, :math:`i_1 = i - k, j_1 = j - k`, then the projection operator

.. math::
    :label: proj-2

    \hat m_{i, j} = | \alpha_i \rangle \langle \alpha_j | = \mathrm{fsgn}(k, i_1) \mathrm{fsgn}(k, i_2) \prod\limits_{\sigma \in k} \hat n_\sigma \prod\limits_{\sigma' \in \bar k \\ (i_1 \cup j_1)} (1 - \hat n_{\sigma'}) \prod\limits_{\sigma \in i_1} \hat c^\dagger_\sigma \prod\limits_{\sigma \in j_1} \hat c_{\sigma}

where we define the fermionic sign function by adding one particle :math:`\sigma`:

.. math::
    :label: sgn-1p

    \mathrm{fsgn}(\sigma, i) = \langle \alpha_i \sigma | \hat c^\dagger_\sigma | \alpha_i \rangle

and the sign function of two configuration

.. math::
    :label: sgn-mp

    \mathrm{fsgn}(j,i) = \langle \alpha_i \alpha_j | \prod\limits_{n=1(\sigma_n \in j)}^{|j|} \hat c^\dagger_{\sigma_n} | \alpha_i \rangle

in which :math:`| \alpha_i \sigma \rangle` and :math:`| \alpha_i \alpha_j \rangle` have been arranged to the correct sequence.


The diagonalization of atomic Hamiltonian gives the 

.. math::
    :label: hat

    \hat H_{\mathrm{at}} = \sum\limits_\Gamma E_\Gamma \hat m_\Gamma

where

.. math::
    :label: mgamma 

    \hat m_\Gamma = | \Gamma \rangle \langle \Gamma | = \sum\limits_{ij} T_{i\Gamma} \hat m_{ij} T^\dagger_{\Gamma,j}

Then the Gutzwiller Wave Function is:

.. math::
    :label: gwf

    | \Psi\rangle = \hat P_G | \Phi \rangle = \prod\limits_{x, \Gamma} \lambda_{x;\Gamma}^{\hat m_{x;\Gamma}} | \Phi \rangle = \prod\limits_x (1 + \sum\limits_{\Gamma} (\lambda_{x;\Gamma} - 1) \hat m_{x;\Gamma}) | \Phi \rangle

the :math:`2^{2N}` variational parameters :math:`\lambda_{x,\Gamma}` are real and positive.

To be convenient, we change the basis to DMET fragments such that

.. math::
    :label: dm-diagnonize

    \langle \Phi | \hat a^\dagger_{x, i} \hat a_{x, j} | \Phi \rangle = \delta_{i,j} n^{(x)}_i



Conditions of Gutzwiller Approximation:

- Infinite spatial dimension
- Local constraint: :math:`\langle \Phi | \hat G_x^2 | \Phi \rangle = 1,\, \langle \Phi | \hat a^\dagger_{i \in x} \hat a_{j \in x} \hat G_x^2 | \Phi \rangle = \langle \Phi |  \hat a^\dagger_{i \in x} \hat a_{j \in x} | \Phi \rangle`.

