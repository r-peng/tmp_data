Electron-Phonon Coupling
=============================================

Hubbard-Holstein Model
-------------------------------

.. math::
    :label: hh-model

    \hat H = \sum\limits_{\langle i, j \rangle, \sigma} t \hat c_{i\sigma}^\dagger \hat c_{j \sigma} + \sum\limits_i U \hat n_{i\uparrow} \hat n_{i \downarrow} + \sum\limits_{i} \omega_- \hat a^\dagger_i \hat a_i + \sum\limits_{i \sigma} g \hat n_{ \sigma} (\hat a_i^\dagger + \hat a_i) 

