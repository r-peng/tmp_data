Recap of Coupled-Cluster Theory
===========================================

CC Energy and Amplitude Equation
---------------------------------------

Define projection operator in and out of reference-state space:

.. math::
    :label: proj-orb-cc

    \hat P = | \Phi_0 \rangle \langle \Phi_0 |,\, \hat Q = 1 - \hat P

and then the CC energy and amplitude equations are:

.. math::
    :label: cc-eq

    \hat P \mathcal H \hat P = \Delta E \hat P,\, \hat Q \mathcal H \hat P = 0

in which the *effective Hamiltonian*:

.. math::
    :label: cc-eff-ham

    \mathcal H = e^{-\hat T} \hat H_N e^{\hat T} = (\hat H_N e^{\hat T})_{\mathrm C} 