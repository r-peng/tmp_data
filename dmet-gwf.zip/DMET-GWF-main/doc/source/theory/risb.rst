Rotationally Invariant Slave-boson Formalism
=======================================================

