Time-dependent CASSCF
===============================

General Theory
--------------------

Time-dependent Variational principle is the fixed point of action integral

.. math::
    :label: action-integral

    I[\Psi] = \int_{t_1}^{t_2} \langle \Psi | \hat H - i\hbar \dfrac{\partial}{\partial t} | \Psi \rangle \mathrm d t

.. math::
    :label: tdvp

    \langle \delta \Psi | (\hat H - i\hbar \dfrac{\partial}{\partial t}) | \Psi \rangle + \langle \Psi | (\hat H - i\hbar \dfrac{\partial}{\partial t} ) | \Psi \rangle = 0

The time-dependent WFN is generally

.. math::
    :label: general

    | \Psi(t) \rangle = \sum\limits_M C_M(t) | \Phi_M(t) \rangle

The MCSCF both changes the combination coefficient :math:`C_M(t)` and the Slater Determinant :math:`| \Phi_M(t) \rangle`, and we consider the rotation of molecular orbitals

.. math::
    :label: rotation-mo

    | \psi_i' \rangle = \sum\limits_j \exp(\Delta_{ji}) | \psi_j \rangle 

where the anti-unitary matrix is

.. math::
    :label: antiuni-trans

    \Delta_{ji}^* = - \Delta_{ij}

And the transformed MCSCF function *due to the change of basis set* is

.. math::
    :label: var-wfn-bs

    | \delta_\psi \Psi\rangle = \sum\limits_{i,j} \Delta_{ji} \hat c^\dagger_j \hat c_i | \Psi \rangle

for the variation of wfn by che change of combination coefficient,

.. math::
    :label: var-wfn-coeff

    | \delta_C \Psi \rangle = \sum\limits_M \delta C_M | \Phi_M \rangle

The time derivation of MCSCF wave-function is

.. math::
    :label: tderiv-mcscf

    i\hbar | \dfrac{\partial \Psi}{\partial t} \rangle = i\hbar \sum\limits_M \dfrac{\partial C_M}{\partial t} | \Phi_M \rangle + \hat X | \Psi \rangle

where :math:`\hat X` is **unitary**:

.. math::
    :label: hat-x

    \hat X = \sum\limits_{i,j} X_{ij} \hat c^\dagger_i \hat c_j

Due to the Eq.:eq:`var-wfn-coeff`, the variation to :math:`\delta C_M^*` yields

.. math::
    :label: eom-coeff

    i\hbar \dfrac{\partial C_\alpha}{\partial t} = \sum\limits_\beta \langle \Phi_\alpha | \hat H - \hat X | \Phi_\beta \rangle C_\beta 

For variation of :math:`\Delta_{ij}`, substituting :eq:`eom-coeff` into TDVP, we get

.. math::
    :label: tdcas-work-func

    \langle \Psi | (\hat H - \hat X) (1 - \hat P) \hat c_i^\dagger \hat c_j | \Psi \rangle - \langle \Psi | \hat c^\dagger_i \hat c_j (1 - \hat P) (\hat H - \hat X) | \Psi \rangle = 0

if the MOs are time invariant, then :math:`\hat X = 0`, it reduces to TDCI work function.

for the variation parameter :math:`\Delta_{ji}`, where the **projector** :math:`\hat P = \sum\limits_{M} | \Phi_M \rangle \langle \Phi_M |` corresponds to the **current occupied states**.

In order to use the work Eq. :eq:`tdcas-work-func`, we firstly consider the commutation 

.. math::
    :label: commutation

    \langle [\hat H - \hat X, \hat a^\dagger_p \hat a_q] \rangle_\Psi = \sum\limits_r [(h_{rp} - x_{rp}) \gamma_{rq} - (h_{qr} - x_{qr}) \gamma_{pr}] \\ + \dfrac{1}{2} \sum\limits_{rst} ( g_{rpst} \Gamma_{rqst} - g_{rstp}\Gamma_{rqts} + g_{rsqt} \Gamma_{psrt} - g_{qrst} \Gamma_{prst} )

.. note::

    Here is a illustration for RHF case.

    For a single Slater determinant, The projector :math:`\hat P` contains only :math:`| \Phi \rangle \langle \Phi|` itself. For i and j label that are both occupied or virtual, we have :math:`(1 - \hat P) \hat a^\dagger_i \hat a_j | \Phi \rangle = 0`, but for the case that *i* is virtual and *j* is occupied, :math:`(1 - \hat P) \hat a^\dagger_i \hat a_j | \Phi \rangle = \hat a^\dagger_i \hat a_j | \Phi \rangle.` Therefore we directly get that for this situation, 

    .. math::
        :label: tdrhf-work-func

        \langle \Phi | [\hat H - \hat X, \hat a^\dagger_a \hat a_i] | \Phi \rangle = 0

    Here the *i, j ...* are the label of general spin-orbitals. 
    and considering the 1rdm and 2rdm for Slater: :math:`\gamma_{ij} = \delta_{ij}, \, \Gamma_{ijkl} = \delta_{il}\delta_{jk} - \delta_{ik} \delta_{jl}` where *i,j,k,l* are occupied MOs, we get

    .. math::
        :label: commute-slater

        \langle [\hat H - \hat X, \hat a^\dagger_a \hat a_i] \rangle= h_{ia} - x_{ia} + \dfrac{1}{2} \sum\limits_j^{occ} (g_{iajj} + g_{jjia} - g_{jaij} - g_{ijja})

    For RHF, the parameter for alpha and beta spin are the same, so we get the equation (i,j... are spatial orbital)

    .. math::
        :label: tdhf-work-eq

        \sum\limits_j^{occ} h_{ia} - x_{ia} + \sum\limits_{j}^{occ} (2 g_{iajj} - g_{ijja}) = 0

    which gives the familiar result 

    .. math::
        :label: tdhf-eq

        \hat X = \hat F, \, i\hbar | \dfrac{\partial \Psi}{\partial t} \rangle = \hat F | \Psi \rangle

TDCAS Case
-----------------------

Here we denote *klmn* as active-space orbital, *ab* as virtual orbital, and *uvwx* as core orbital, then

.. math::
    :label: redundancy-tdcas

    (1 - \hat P) \hat a^\dagger_a \hat a_b | \Psi \rangle = (1 - \hat P) \hat a^\dagger_u \hat a_v | \Psi \rangle = (1 - \hat P) \hat a^\dagger_{k} \hat a_l | \Psi \rangle = 0

but for other situations, the projector :math:`1 - \hat P` is eliminated and we can still use Eq. :eq:`commutation`. 