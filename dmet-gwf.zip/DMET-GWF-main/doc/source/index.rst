.. DMET-GWF documentation master file, created by
   sphinx-quickstart on Sat Nov 12 15:46:44 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Notes of DMET-GWF
====================================

.. toctree::
   :maxdepth: 1
   :caption: Theory Recap

   DMET Recap <theory/dmet>
   Gutzwiller Wavefunctions (GWF) <theory/gwf>
   George Booth DMET Wave function <theory/gbooth>
   Hubbard Model <theory/hubbard>
   Recap of Coupled-Cluster Theory <theory/cc>
   Response Theory <theory/response>
   Rotationally Inviriant Slave-boson Formalism (RISB) <theory/risb>
   Time-dependent MCSCF <theory/tdmcscf>
   Electron Phonon Coupling <theory/epc>

.. toctree::
   :maxdepth: 1
   :caption: Working Log

   CPS Ground-state Energies from DMET Results <log/01-exact-energy>
   Excited State I: Exact Implementation of an EOM-Like method <log/02-excited-state>
   Excited State II: EOM + Democratic Partitioning <log/03-excited-2>
   Details of EOMDP <log/03-details>
   Approximation of 1-RDM for FCI solver <log/04-approx-1rdm>
   K Labeling for Excited States <log/05-klabel>
   Redundancies <log/06-redundancy>
   Lowering the Scale <log/07-lowerscale>

.. toctree::
   :maxdepth: 1
   :caption: Technical Problems

   Bugs and Corrections <tech/qa>
   CI Strings in PySCF <tech/cistring>
   Identification of Fragment and Bath Index <tech/findfb>

.. toctree::
   :maxdepth: 1
   :caption: Boson for BLOCK2

   Learning the Block2 Code <block2-boson/readcode>
   Learning the Renormalizer Code <block2-boson/read-renormalizer>
   Developing Note <block2-boson/develop-note>