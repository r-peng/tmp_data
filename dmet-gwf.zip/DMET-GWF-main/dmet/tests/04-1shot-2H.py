import sys
sys.path.append("..")

from pyscf import gto
from pyscf.scf import hf
import numpy as np
from dmet.main.solver import DMET_FCI
from dmet.main.outer import DMET
from dmet.main.vfit import Vcorr_Fit

# Correspondence between analytical and numerical gradient
# Hydrogen ring

def make_Hring(l=1.):
    r = l/(2 * np.sin(np.pi / 10))
    atmlst = []
    for i in range(10):
        atmlst.append(['H', (r*np.cos(2. * np.pi/10*i), r*np.sin(2. * np.pi/10*i), 0)])
    mol = gto.Mole()
    mol.atom = atmlst
    mol.basis = 'sto-6g'
    mol.build()
    return mol

fragments = [[[0,1], [2,3], [4,5], [6,7], [8,9]]]
mol = make_Hring(1.4)
mf = hf.RHF(mol); mf.kernel()

dmet = DMET(mf, fragments, DMET_FCI)
dmet.chempot_cycle()
print(dmet.kernel_1shot()[0])
