import sys
sys.path.append("..")

from dmet.model.hubbard import *
from dmet.main.outer import DMET

# Correspondence between analytical and numerical gradient
# Hubbard model

mol = HubbardMole(lx=3, ly=4, t=1, U=2)
mol.nelectron = 12

mf = RHF_SpinHubbard(mol)
mf.kernel()

def get_num_grad(f, u0, du=1E-5):
    a = []
    for i in range(len(u0)):
        ul = u0.copy(); ul[i] -= du
        ur = u0.copy(); ur[i] += du
        fl = f(ul); fr = f(ur)
        a.append((fr-fl)/(2.*du))

    return np.array(a)

fragments = [
    [[0,1], [3,2]], [[8,9], [11,10]],
    [[4,5], [7,6]]
]

dmet = DMET(mf, fragments, DMET_Hubbard_FCI)
dmet.kernel(fit_method='loss')