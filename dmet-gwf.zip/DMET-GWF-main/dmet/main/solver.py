import numpy as np
from pyscf.scf import hf
from pyscf import ao2mo, lo
from pyscf.lib import logger
from cpskit.fci import ci_slater

from pyblock2._pyscf.ao2mo import integrals as itg
from pyblock2.driver.core import DMRGDriver, SymmetryTypes

def get_dmrg_integral_rhf(frag_coeff, bath_coeff, core_coeff, mf):
    """
    inputting the frag, bath and core coefficient and the mean-field solver
    rearrange the sequence to CORE + (FRAG+BATH)
    output the integral h1e and g2e

    here the frag_coeff is suggested to the lo itself
    """
    mo_coeff = np.hstack((core_coeff, frag_coeff, bath_coeff))
    ncore = core_coeff.shape[1]
    
    class PseudoMF(mf.__class__):
        def __init__(self, mol):
            super(PseudoMF, self).__init__(mol)
            self.mo_coeff = mo_coeff

    mf = PseudoMF()
    ncas, n_elec, spin, ecore, h1e, g2e, orb_sym = itg.get_rhf_integrals(mf, ncore)
    return h1e, g2e

def gen_emb_orb(dm:np.ndarray, na, cal:np.ndarray, nocc=None):
    """
    DMET 

    Ref: PhD Thesis of Boxiao Zheng

    Attributes:
        dm: density matrix of RHF
        na: number of FRAGMENT orbitals or INDICES
        cal: transformation coefficient from ATOMIC to LOCALIZED
        nocc: number of total occupied number

    Return: Fragment/Bath/Unentangled orbitals in ATOMIC base
    """

    if type(na) in [list, np.ndarray]:
        mask = np.ones(dm.shape[0], np.bool_)
        mask[na] = False

    if type(na)==int: 
        daa = dm[:na,:na]
        dab = dm[:na,na:]
        dbb = dm[na:,na:,]
        calcuta = cal[:,:na]
        calcutb = cal[:,na:]
        lenna = na
    else: 
        daa = dm[na][:,na]
        dab = dm[na][:,mask]
        dbb = dm[mask][:,mask]
        calcuta = cal[:,na]     # C_{\mu j}, j \in N_A
        calcutb = cal[:,mask]   # C_{\mu j}, j \in N_B
        lenna = len(na)

    up, sp, vp = np.linalg.svd(daa)
    p = np.einsum("ij,j->ij", up, np.sqrt(sp))
    q = np.dot(np.linalg.inv(p), dab).conj().T
    # uq, sq, vq = np.linalg.svd(np.dot(q, q.conj().T))
    pnorm = np.sqrt(np.einsum("ik,ik->k", p, p.conj()))
    # q = np.einsum("ij,j->ij", uq[:,:lenna], np.sqrt(sq)[:lenna])
    qnorm = np.sqrt(np.einsum("jk,jk->k", q, q.conj()))
    eed = dbb - np.dot(q, q.conj().T)   # EE^\dagger = \rho_{bb} - QQ^\dagger
    uu, su, vu = np.linalg.svd(eed)
    uocc = uu[:,np.where(abs(su)>1E-12)[0]]   # choose occupied unentangled orbitals

    # caf: ATOMIC -> FRAGMENT / IMPURITY coefficient
    # cab: ATOMIC -> BATH coefficient 
    # cau: ATOMIC -> UNENTANGLED / CORE coefficient
    caf = np.einsum("nj,k,jk->nk", calcuta, 1/pnorm, p)
    cab = np.einsum("nj,k,jk->nk", calcutb, 1/qnorm, q)
    cau = np.dot(calcutb, uocc)    

    occfb = np.hstack((sp, 1.-sp))

    return (caf, cab, cau, occfb)

class DMET_SCF(hf.SCF):
    r'''
    One-shot DMET SCF in the (fragment + environment) subspace
    '''

    def __init__(self, mf:hf.RHF, fragments, mu_glob=0):

        mol = mf.mol
        self._scf = mf

        hf.SCF.__init__(self, mol)
        self.fragment = fragments
        cam = mf.mo_coeff

        if mf.__class__.__name__ == "RHF":
            cal = lo.orth_ao(self._scf)
        else:   # Hubbard
            cal = np.eye(cam.shape[0])   # hubbard

        clm = np.dot(np.linalg.inv(cal), cam)
        occ = mf.mo_occ
        nocc = mol.nelec[0]
        dml = np.einsum("ij,j,jk->ik", clm, occ, clm.conj().T)

        self.cal = cal
        caf, cab, cau, occfb = gen_emb_orb(dml, fragments, cal, nocc)
        
        self.frag_coeff = caf   # AO -> FRAGMENT
        self.bath_coeff = cab   # AO -> BATH
        self.na = caf.shape[1]

        self.fb_coeff = np.hstack((caf, cab))
        self.un_coeff = cau
        self.core_coeff = self.un_coeff
        self.fbc_coeff = np.hstack((caf, cab, cau)) # Frag+Bath+Core
        self.dm = np.diag(occfb)    # as initial guess of EO density matrix
        self.dmx = None

        # unentangled dm in AO
        self.un_dm = 2. * np.dot(self.un_coeff, self.un_coeff.conj().T)

        # extra conditions: :math:`\mu_glob` and :math:`u`.
        self.mu_glob = mu_glob
        
        self.nocc = cau.shape[1] + self.na

        # densitry matrix projected to frag+bath bases
        self.init_guess = "project" 

        # eri[ijkl] = (ij|kl) , in frag and bath orbital
        try: 
            erifb = ao2mo.kernel(mf._eri, self.fb_coeff, compact=False)
            self.erifb = erifb.reshape((self.na*2, self.na*2, self.na*2, self.na*2))
        except NotImplementedError: 
            pass

    def get_emb_orb(self): return self.fb_coeff
    def get_core_orb(self): return self.un_coeff

    def get_ecv_coeff(self):    # AO -> emb+core+vir
        
        coef_l_ec = np.dot(np.linalg.inv(self.cal), self.fbc_coeff)
        dm_ghost = np.einsum("mi,ni->mn", coef_l_ec, coef_l_ec.conj())
        u, s, v = np.linalg.svd(dm_ghost)
        coef_l_vir = u[:,np.where(abs(s)<1E-10)[0]]
        vi_coeff = np.dot(self.cal, coef_l_vir)
        ecv_coeff = np.hstack((self.fbc_coeff, vi_coeff))

        cle = np.dot(np.linalg.inv(self.cal), ecv_coeff)

        return  ecv_coeff

    def get_ecv_eri(self):  # eri in emb+core+vir orbital

        ecv_coeff = self.get_ecv_coeff()
        eri = ao2mo.kernel(self._scf._eri, ecv_coeff)
        g = ao2mo.restore(1, eri, norb=self.mol.nao)
        return g

    def change_mu_glob(self, mu_glob):
        self.mu_glob = mu_glob

    def get_occ(self, mo_energy, mo_coeff=None):
        occidx = np.argsort(mo_energy)[:self.na]
        mo_occ = np.zeros_like(mo_energy)
        mo_occ[occidx] = 2

        return mo_occ

    def get_hcore_bare(self, mol=None):
        if mol is None: mol = self.mol
        hao = hf.get_hcore(mol)
        h = np.einsum("mj,mn,nk->jk", self.fb_coeff.conj(), hao, self.fb_coeff)
        return h
    
    def get_hcore(self, mol=None, mu_glob=None):
        # h^x, \mu_{glob} -> hcore (in EO)
        if mol is None: mol = self.mol
        
        hao = hf.get_hcore(mol)
        vj, vk = hf.get_jk(mol, self.un_dm)
        hall = hao + vj - .5 * vk
        h = np.einsum("mj,mn,nk->jk", self.fb_coeff.conj(), hall, self.fb_coeff)

        # minus global chemical potential
        if mu_glob is None: mu_glob = self.mu_glob
        for i in range(self.na):
            h[i,i] -= mu_glob
        return h

    def get_ovlp(self, mol=None):   # unitary matrix
        fbdim = self.fb_coeff.shape[1]
        return np.eye(fbdim)

    # with new 'get_jk' function, then 'get_veff' and 'get_fock' are used as before
    def get_jk(self, mol=None, dm=None, hermi=1, with_j=True, with_k=True):
        # density matrix in the frag+bath bases
        return hf.dot_eri_dm(self.erifb, dm, hermi, with_j, with_k)

    def get_init_guess(self, mol=None, key='project'):
        if key == "project": return self.init_guess_by_project(mol)
        else:
            raise NotImplementedError("Other initial guess methods are not available!")

    def init_guess_by_project(self, mol=None):
        return self.dm

    def eig(self, h, s):
        # eigenvalue solver since orbitals are orthornomal.
        e, c = np.linalg.eig(h)
        idx = np.argmax(abs(c.real), axis=0)
        c[:,c[idx,np.arange(len(e))].real<0] *= -1
        return e, c

    def energy_tot(self, dm=None, h1e=None, vhf=None):
        # Partition energy Ex, see Eq. (25) in DMET2016
        hbare = self.get_hcore_bare()
        h1e = self.get_hcore(mu_glob=0)
        h1e = (h1e[:self.na] + hbare[:self.na]) / 2.
        vhf = vhf[:self.na]
        dm = dm[:,:self.na]
        e1 = np.einsum('ij,ji->', h1e, dm)
        e_coul = np.einsum('ij,ji->', vhf, dm) * .5
        self.scf_summary['e1'] = e1.real
        self.scf_summary['e2'] = e_coul.real
        logger.debug(self, 'E1 = %s  E_coul = %s', e1, e_coul)
        return (e1+e_coul).real

    def get_dmcorr_eo(self):   # density matrix of fragment-fragment block in EO
        return self.make_rdm1()[:self.na][:,:self.na]

    def get_ne(self):   # number of electrons
        return np.einsum("ii->", self.get_dmcorr_eo())

    def get_hf_cistr(self):
        c = self.mo_coeff[:,np.argsort(self.mo_energy)[:self.na]]
        coef_hf = ci_slater(2*self.na, (self.na, self.na), (c, c))
        self.fci_coeff = coef_hf

class DMET_DMRG(DMET_SCF):

    def kernel(self, scratch="./tmp", n_thread=4, n_sweeps=50):
        """
        Currently support UHF(SZ) solver only.
        """
        # WARNING: the fragment is LO itself here, not the transformed fragment orbitals
        self.frag_coeff = self.cal[:,self.fragment]
        self.fb_coeff = np.hstack((self.frag_coeff, self.bath_coeff))
        erifb = ao2mo.kernel(self._scf._eri, self.fb_coeff, compact=False)
        self.erifb = erifb.reshape((self.na*2, self.na*2, self.na*2, self.na*2))

        h1e = self.get_hcore()
        g2e = self.erifb

        driver = DMRGDriver(scratch=scratch, symm_type=SymmetryTypes.SZ, n_threads=n_thread)
        driver.initialize_system(n_sites=self.na*2, n_elec=self.na*2,
        spin=0) # Starting the problem

        print(h1e.shape)
        print(g2e.shape)
        g2e_s = ao2mo.restore(1, g2e, self.na*2)
        print(g2e_s.shape)
        mpo = driver.get_qc_mpo(h1e, g2e_s, ecore=0, iprint=1)
        ket = driver.get_random_mps(tag="GS", bond_dim=250, nroots=1)

        def run_dmrg(driver, mpo):
            bond_dims = [250] * 4 + [500] * 4
            noises = [1e-4] * 4 + [1e-5] * 4 + [0]
            thrds = [1e-10] * 8
            return driver.dmrg(
                mpo,
                ket,
                n_sweeps=n_sweeps,
                bond_dims=bond_dims,
                noises=noises,
                thrds=thrds,
                iprint=1,
            )

        run_dmrg(driver, mpo)

        dm1a, dm1b = driver.get_1pdm(ket)
        dm2aa, dm2ab, dm2bb = driver.get_2pdm(ket)
        # transpose from the block2 seq. <p*q*rs> to pyscf seq. <p*r*sq> 
        dm2aa = dm2aa.transpose(0,3,1,2)
        dm2ab = dm2ab.transpose(0,3,1,2)
        dm2bb = dm2bb.transpose(0,3,1,2)

        dm1 = dm1a + dm1b
        dm2 = dm2aa + 2. * dm2ab + dm2bb

        dm1 = dm1[:,:self.na]
        dm2 = dm2[:self.na]

        hbare = self.get_hcore_bare()
        h1e = self.get_hcore(mu_glob=0)
        hnew = (h1e[:self.na] + hbare[:self.na]) / 2.
        eri = g2e[:self.na]
        ex = np.einsum("pq,qp->", hnew, dm1) + .5 * np.einsum("pqrs,pqrs->", eri, dm2)
        dmx = dm1[:self.na] # 1rdm in the FRAGMENT block
        self.dmx = dmx
        self.e_tot = ex

        return ex

    def get_dmcorr_eo(self): return self.dmx


class DMET_FCI(DMET_SCF):

    def kernel(self):
        # Full-CI Solver for DMET
        # In fact we do not need SCF results in Full CI lol
        from pyscf.fci.direct_spin1 import FCISolver
        norb = 2*self.na
        nelec = 2*self.na   # Corr problem in DMET is 1/2 occupied itself.
        # h1e = reduce(np.dot, (self.mo_coeff.conj().T, self.get_hcore(), self.mo_coeff))
        # eri = ao2mo.kernel(self.erifb, self.mo_coeff, compact=False)
        # eri = eri.reshape(norb,norb,norb,norb)
        cis = FCISolver(self.mol)
        
        h1e = self.get_hcore()  # at EO picture
        eri = self.erifb
        e, c = cis.kernel(h1e, eri, norb, nelec)

        self.fci_coeff = c  # save the fci coefficient

        dm1 = cis.make_rdm1(c, norb, nelec)[:,:self.na]
        dm2 = cis.make_rdm2(c, norb, nelec)[:self.na]

        hbare = self.get_hcore_bare()
        
        h1e = self.get_hcore(mu_glob=0)
        hnew = (h1e[:self.na] + hbare[:self.na]) / 2.
        eri = eri[:self.na]
        ex = np.einsum("pq,qp->", hnew, dm1) + .5 * np.einsum("pqrs,pqrs->", eri, dm2)
        
        self.e1e = np.einsum("pq,qp->", hnew, dm1)
        self.e2e = .5 * np.einsum("pqrs,pqrs->", eri, dm2)

        dmx = dm1[:self.na] # 1rdm in the FRAGMENT block
        self.dmx = dmx

        self.e_tot = ex
        return ex

    def get_dmcorr_eo(self): return self.dmx
