import numpy as np
from pyscf.scf import hf
from scipy import optimize

def get_corr_laglangian(f1e, u, dm_mf, dm_corr):
    r'''
    dm_corr: the diagnoally blocked high-level density matrix
    '''
    dm_corr = (dm_corr + dm_corr.T) / 2.0
    dm_mf = (dm_mf + dm_mf.T) / 2.0

    return np.einsum("ij,ji->", f1e+u, dm_mf) - np.einsum("ij,ji->", u, dm_corr)

def get_corr_grad(f1e, mo_energy, mo_coeff, mo_occ, dm_mf, dm_corr):
    r'''
    return :math:`G_{rs} = dL/du_{rs}`
    f1e: (F+C)
    '''


    eocc = mo_energy[mo_occ>0]
    evir = mo_energy[mo_occ==0]
    cocc = mo_coeff[:,mo_occ>0]
    cvir = mo_coeff[:,mo_occ==0]

    de = evir[:,None] - eocc

    ddm = dm_mf - dm_corr
    
    grad = ddm.T
    grad -= np.einsum("pq,qn,rm,sn,pm,mn->rs", 2.*f1e, cocc, cvir, cocc.conj(), cvir.conj(), 1./de)
    grad -= np.einsum("pq,qm,rm,sn,pn,mn->rs", 2.*f1e, cvir, cvir.conj(), cocc, cocc.conj(), 1./de)
    return grad

def dmloss(dm_mf, dm_corr, fragments):
    # (DM_MF - DM_X) ^ 2
    
    sgn = np.zeros_like(dm_mf)
    for sym_frag in fragments:
        for frag in sym_frag:
            sgn[np.ix_(frag, frag)] = 1.
    ddm = sgn * (dm_mf - dm_corr)
    return np.einsum("ij,ji->", ddm, ddm)

def dmloss_grad(dm_mf, dm_corr, mo_energy, mo_coeff, mo_occ, fragments):

    sgn = np.zeros_like(dm_mf)
    for sym_frag in fragments:
        for frag in sym_frag:
            sgn[np.ix_(frag, frag)] = 1

    eocc = mo_energy[mo_occ>0]
    evir = mo_energy[mo_occ==0]
    cocc = mo_coeff[:,mo_occ>0]
    cvir = mo_coeff[:,mo_occ==0]

    de = evir[:,None] - eocc

    ddm = sgn * (dm_mf - dm_corr)   # mask the non block-diagonal part
    
    grad = -np.einsum("kl,kp,iq,jp,lq,qp->ij", 4.*ddm, cocc, cvir, cocc.conj(), cvir.conj(), 1./de)
    grad -= np.einsum("kl,kq,iq,jp,lp,qp->ij", 4.*ddm, cvir, cvir.conj(), cocc, cocc.conj(), 1./de)
    return grad

def _unpack_to_mat(u, mat0, fragments):

    mat = np.zeros_like(mat0)
    idx = 0
    for sym_frag in fragments:
        frag0 = sym_frag[0]
        idxr = idx + len(frag0) ** 2
        a = u[idx:idxr].reshape((len(frag0), len(frag0)))
        for fragment in sym_frag:
            mat[np.ix_(fragment, fragment)] = a
        idx = idxr

    return mat

def _pack_matrix(mat, u, fragments):

    res = np.zeros_like(u)
    idx = 0
    for sym_frag in fragments:
        frag0 = sym_frag[0]
        idxr = idx + len(frag0) ** 2
        res[idx:idxr] = mat[np.ix_(frag0, frag0)].reshape(-1) * len(sym_frag)
        idx = idxr
    return res


def corr_info(u, fock0, cal, mol, mf, fragments, scf=False):

    umat = _unpack_to_mat(u, fock0, fragments)
    umat = (umat + umat.T) / 2.    # Keep symmetric

    if not scf:

        if mol.__class__.__name__ == "Mole":
            ovlp = mol.intor_symmetric('int1e_ovlp')
            mo_energy, mo_coeff = hf.eig(fock0+umat, np.einsum("mj,mn,nk->jk", cal.conj(), ovlp, cal))
        else:   # Hubbard
            mo_energy, mo_coeff = np.linalg.eig(fock0+umat)

    else:
        calinv = np.linalg.inv(cal)

        class RHF_Corr(hf.RHF):
            def __init__(self, mol):
                super(hf.RHF, self).__init__(mol)

            def get_hcore(self, mol=None):
                if mol is None: mol = self.mol
                h0 = hf.get_hcore(mol)
                h0 += np.einsum("mj,mn,nk->jk", calinv.conj(), umat, calinv)
                return h0

        mf_corr = RHF_Corr(mol); mf_corr.kernel()

    mo_energy = mo_energy.real
    mo_coeff = mo_coeff.real
    mo_occ = hf.get_occ(mf, mo_energy)
    dm_mf = hf.make_rdm1(mo_coeff, mo_occ)

    return umat, mo_energy, mo_coeff, mo_occ, dm_mf


class Vcorr_Fit:

    # Wouters2016 Eq.(30) & (35)

    def __init__(self, mol, mf, cal, fragments, fock0, isscf=False):

        self.mol = mol
        self.cal = cal
        self._scf = mf
        self.fragments = fragments
        self.fock0 = fock0
        self.dmx = None
        self.isscf = isscf
        
        idx = 0
        for sym_frag in self.fragments:
            frag0 = sym_frag[0]
            idx += len(frag0) ** 2

        self.u = np.random.random(idx) * 1E-4

    def push_dmcorr(self, dmx): self.dmx = dmx

    def corr_info(self, u=None):
        if u is None: u = self.u
        return corr_info(u, self.fock0, self.cal, self.mol, self._scf, self.fragments, scf=self.isscf)

    def loss(self, u):
        umat, mo_energy, mo_coeff, mo_occ, dm_mf = self.corr_info(u)
        return dmloss(dm_mf, self.dmx, self.fragments)

    def loss_grad(self, u):
        umat, mo_energy, mo_coeff, mo_occ, dm_mf = self.corr_info(u)
        gradmat = dmloss_grad(dm_mf, self.dmx, mo_energy, mo_coeff, mo_occ, self.fragments)
        gradmat = (gradmat + gradmat.T) / 2.

        return _pack_matrix(gradmat, u, self.fragments)

    def lag(self, u):
        umat, mo_energy, mo_coeff, mo_occ, dm_mf = self.corr_info(u)
        return get_corr_laglangian(self.fock0, umat, dm_mf, self.dmx) * -1.
        
    def lag_grad(self, u):
        umat, mo_energy, mo_coeff, mo_occ, dm_mf = self.corr_info(u)
        gradmat = get_corr_grad(self.fock0+umat, mo_energy, mo_coeff, mo_occ, dm_mf, self.dmx) * -1.
        gradmat = (gradmat + gradmat.T) / 2.

        return _pack_matrix(gradmat, u, self.fragments)

    def update_u(self, method="lag"):

        if method == "lag":
            u = optimize.minimize(fun=self.lag, x0=self.u, jac=self.lag_grad)['x']
        elif method == "loss":
            u = optimize.minimize(fun=self.loss, x0=self.u, jac=self.loss_grad)['x']
        else:
            raise NotImplementedError
        self.u = u

        return u