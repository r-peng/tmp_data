# Outer cycle for DMET
import numpy as np
from dmet.main.vfit import Vcorr_Fit
from dmet.tools.mathtools import secant

class DMET:
    def __init__(self, mf, fragments:list, dmetclass):

        self.mu_glob = 0
        self._scf = mf
        self.energy_nuc = mf.energy_nuc()

        self.fragments = fragments
        self.dmetclass = dmetclass
        self.sym_factor = [len(sym_frag) for sym_frag in fragments]
        self.dmets = [dmetclass(mf, sym_frag[0]) for sym_frag in fragments]
        
        self.u = np.zeros_like(mf.mo_coeff, dtype=np.float32)

        self.cal = self.dmets[0].cal            # AO -> LO
        self.cle = np.zeros_like(self.cal)      # LO -> EO

        k = 0
        for sym_frag in fragments:
            frag0 = sym_frag[0]
            cle_frag = np.dot(np.linalg.inv(self.cal), self.dmets[k].frag_coeff) # LO -> AO -> EO
            for fragment in sym_frag:
                self.cle[np.ix_(fragment, fragment)] += cle_frag[frag0,:]
            k += 1
        
        self.cae = np.dot(self.cal, self.cle)   # AO -> EO
        self.fock0 = np.einsum("mj,mn,nk->jk", self.cal.conj(), mf.get_fock(), self.cal)  
        self.dmx = np.zeros_like(mf.mo_coeff)

    def update_solver(self, mf):
        # V-fit needs the info for the new solvers
        self._scf = mf
        self.dmets = [self.dmetclass(mf, sym_frag[0], self.mu_glob) for sym_frag in self.fragments]

    def kernel_1shot(self):
        nelec = 0
        e_tot = self.energy_nuc

        k = 0
        for sym_frag in self.fragments:
            fragment = sym_frag[0]
            solver = self.dmets[k]
            e  = solver.kernel()
            dm = solver.get_dmcorr_eo()
            n  = solver.get_ne()

            e_tot += e * self.sym_factor[k]
            nelec += n * self.sym_factor[k]

            for fragment in sym_frag:
                self.dmx[np.ix_(fragment, fragment)] = dm
            k += 1

        self.dmx = np.einsum("ms,sr,nr->mn", self.cle, self.dmx, self.cle.conj())
        
        return e_tot, nelec, self.dmx
    
    def chempot_cycle(self):
        r'''
        Cycle of fitting total electron number by 
        '''
        def f(mu_glob):
            for i in range(len(self.dmets)):
                self.dmets[i].change_mu_glob(mu_glob)
            etot, nelec, dmx = self.kernel_1shot()
            return nelec - self._scf.mol.nelectron

        mu, count = secant(f, 0, 0.1, 1E-9)
        for i in range(len(self.dmets)):
            self.dmets[i].change_mu_glob(mu)

    def kernel(self, conv_tol=1E-5, max_step=50, fit_method="lag"):

        u_prev = 0
        norm = 1
        converged = False

        vfit_obj = Vcorr_Fit(self._scf.mol, self._scf, self.cal, self.fragments, self.fock0)

        norm_prev = 1

        for i in range(max_step):
            if norm > conv_tol:
                self.chempot_cycle()
                e_tot, nelec, dmx = self.kernel_1shot()
                self.dmx = dmx

                vfit_obj.push_dmcorr(dmx)
                u = vfit_obj.update_u(method=fit_method)

                umat, mo_energy, mo_coeff, mo_occ, dm_mf = vfit_obj.corr_info(u)

                umat = (umat + umat.T) / 2.

                # if norm < norm_prev: umat = (umat + u_prev) / 2.
                self.u = umat

                self._scf.mo_energy = mo_energy
                self._scf.mo_coeff = np.dot(self.cal, mo_coeff) # LO -> AO
                self._scf.mo_occ = mo_occ
                # update DMET parameters from corr potential
                self.update_solver(self._scf)

                norm = np.linalg.norm(umat - u_prev)

                norm_prev = norm
                print("|u - u_prev| = {:6.4e}".format(norm), "E = ", e_tot)
                # TODO: DIIS or EDIIS for convergence?
                u_prev = umat
            else: converged = True; break

        print("E = ", e_tot, ", Converged = ", converged)
        return e_tot, converged
