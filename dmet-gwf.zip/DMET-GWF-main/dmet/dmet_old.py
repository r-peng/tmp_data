import numpy as np
from pyscf.scf import hf
from pyscf import gto, ao2mo, lo
from pyscf.lib import logger

"""
Reconstruction of SCF method
        mf.get_init_guess   Completed
        mf.get_hcore        Completed
        mf.get_ovlp         Completed
        mf.get_veff         Completed
        mf.get_fock         Completed
        mf.get_grad         Completed
        mf.eig              Completed
        mf.get_occ          Completed
        mf.make_rdm1        Completed
        mf.energy_tot       Completed
        mf.dump_chk         
"""

# https://stackoverflow.com/questions/65614649/secant-method-using-python
def secant(f, x0, x1, eps):
    import sys
    f_x0 = f(x0)
    f_x1 = f(x1)
    iteration_counter = 0
    while abs(f_x1) > eps and iteration_counter < 100:
        try:
            denominator = float(f_x1 - f_x0)/(x1 - x0)
            x = x1 - float(f_x1)/denominator
        except ZeroDivisionError:
            print ("Error! - denominator zero for x = ", x)
            sys.exit(1)     # Abort with error
        x0 = x1
        x1 = x
        f_x0 = f_x1
        f_x1 = f(x1)
        iteration_counter += 1
    # Here, either a solution is found, or too many iterations
    if abs(f_x1) > eps:
        iteration_counter = -1
    return x, iteration_counter

def gen_emb_orb(dm:np.ndarray, na, cal:np.ndarray, nocc):
    """
    DMET 

    Ref: PhD Thesis of Boxiao Zheng

    Attributes:
        dm: density matrix of RHF
        na: number of FRAGMENT orbitals or INDICES
        cal: transformation coefficient from ATOMIC to LOCALIZED
        nocc: number of total occupied number

    Return: Fragment/Bath/Unentangled orbitals in ATOMIC base
    """

    if type(na) in [list, np.ndarray]:
        mask = np.ones(dm.shape[0], np.bool_)
        mask[na] = False

    if type(na)==int: 
        daa = dm[:na,:na]
        dab = dm[:na,na:]
        dbb = dm[na:,na:,]
        calcuta = cal[:,:na]
        calcutb = cal[:,na:]
        lenna = na
    else: 
        daa = dm[na][:,na]
        dab = dm[na][:,mask]
        dbb = dm[mask][:,mask]
        calcuta = cal[:,na]     # C_{\mu j}, j \in N_A
        calcutb = cal[:,mask]   # C_{\mu j}, j \in N_B
        lenna = len(na)

    up, sp, vp = np.linalg.svd(daa)
    p = np.einsum("ij,j->ij", up, np.sqrt(sp))
    q = np.dot(np.linalg.inv(p), dab).conj().T
    uq, sq, vq = np.linalg.svd(np.dot(q, q.conj().T))
    pnorm = np.sqrt(np.einsum("ik,ik->k", p, p.conj()))
    q = np.einsum("ij,j->ij", uq[:,:lenna], np.sqrt(sq)[:lenna])
    qnorm = np.sqrt(np.einsum("jk,jk->k", q, q.conj()))
    eed = dbb - np.dot(q, q.conj().T)   # EE^\dagger = \rho_{bb} - QQ^\dagger
    uu, su, vu = np.linalg.svd(eed)
    uocc = uu[:,np.where(abs(su)>1E-12)[0]]   # choose occupied unentangled orbitals

    # caf: ATOMIC -> FRAGMENT / IMPURITY coefficient
    # cab: ATOMIC -> BATH coefficient 
    # cau: ATOMIC -> UNENTANGLED / CORE coefficient
    caf = np.einsum("nj,k,jk->nk", calcuta, 1/pnorm, p)
    cab = np.einsum("nj,k,jk->nk", calcutb, 1/qnorm, q)
    cau = np.dot(calcutb, uocc)

    occfb = np.hstack((sp, sq[:lenna]))

    return (caf, cab, cau, occfb)


# Correlation Potential
def get_corr_laglangian(f1e, u, dm_mf, dm_corr):
    r'''
    dm_corr: the diagnoally blocked high-level density matrix
    '''
    dm_corr = (dm_corr + dm_corr.T) / 2.0
    dm_mf = (dm_mf + dm_mf.T) / 2.0

    return np.einsum("ij,ji->", f1e+u, dm_mf) - np.einsum("ij,ji->", u, dm_corr)

def get_corr_grad(f1e, mo_energy, mo_coeff, mo_occ, dm_mf, dm_corr):
    r'''
    return :math:`G_{rs} = dL/du_{rs}`
    f1e: (F+C)
    '''


    eocc = mo_energy[mo_occ>0]
    evir = mo_energy[mo_occ==0]
    cocc = mo_coeff[:,mo_occ>0]
    cvir = mo_coeff[:,mo_occ==0]

    de = evir[:,None] - eocc

    ddm = dm_mf - dm_corr
    
    grad = ddm.T
    grad -= np.einsum("pq,qn,rm,sn,pm,mn->rs", 2.*f1e, cocc, cvir, cocc.conj(), cvir.conj(), 1./de)
    grad -= np.einsum("pq,qm,rm,sn,pn,mn->rs", 2.*f1e, cvir, cvir.conj(), cocc, cocc.conj(), 1./de)
    return grad

def dmloss(dm_mf, dm_corr, fragments):
    # (DM_MF - DM_X) ^ 2
    
    sgn = np.zeros_like(dm_mf)
    for sym_frag in fragments:
        for frag in sym_frag:
            sgn[np.ix_(frag, frag)] = 1.
    ddm = sgn * (dm_mf - dm_corr)
    return np.einsum("ij,ji->", ddm, ddm)

def dmloss_grad(dm_mf, dm_corr, mo_energy, mo_coeff, mo_occ, fragments):

    sgn = np.zeros_like(dm_mf)
    for sym_frag in fragments:
        for frag in sym_frag:
            sgn[np.ix_(frag, frag)] = 1

    eocc = mo_energy[mo_occ>0]
    evir = mo_energy[mo_occ==0]
    cocc = mo_coeff[:,mo_occ>0]
    cvir = mo_coeff[:,mo_occ==0]

    de = evir[:,None] - eocc

    ddm = sgn * (dm_mf - dm_corr)   # mask the non block-diagonal part

    grad = -np.einsum("kl,kp,iq,jp,lq,qp->ij", 4.*ddm, cocc, cvir, cocc.conj(), cvir.conj(), 1./de)
    grad -= np.einsum("kl,kq,iq,jp,lp,qp->ij", 4.*ddm, cvir, cvir.conj(), cocc, cocc.conj(), 1./de)
    return grad

class DMET_SCF(hf.SCF):
    r'''
    One-shot DMET SCF in the (fragment + environment) subspace
    '''

    def __init__(self, mf:hf.RHF, fragments, mu_glob=0):

        mol = mf.mol
        self._scf = mf

        hf.SCF.__init__(self, mol)
        self.fragment = fragments
        cam = mf.mo_coeff

        if mf.__class__.__name__ == "RHF":
            cal = lo.orth_ao(self._scf)
        else:   # Hubbard
            cal = np.eye(cam.shape[0])   # hubbard

        clm = np.dot(np.linalg.inv(cal), cam)
        occ = mf.mo_occ
        nocc = mol.nelec[0]
        dml = np.einsum("ij,j,jk->ik", clm, occ, clm.conj().T)

        self.cal = cal
        caf, cab, cau, occfb = gen_emb_orb(dml, fragments, cal, nocc)
        
        self.frag_coeff = caf   # AO -> FRAGMENT
        self.bath_coeff = cab   # AO -> BATH
        self.na = caf.shape[1]

        self.fb_coeff = np.hstack((caf, cab))
        self.un_coeff = cau
        self.dm = np.diag(occfb)    # as initial guess of
        # unentangled dm in AO
        self.un_dm = 2. * np.dot(self.un_coeff, self.un_coeff.conj().T)

        # extra conditions: :math:`\mu_glob` and :math:`u`.
        self.mu_glob = mu_glob
        
        self.nocc = cau.shape[1] + self.na

        # densitry matrix projected to frag+bath bases
        self.init_guess = "project" 

        # eri[ijkl] = (ij|kl) , in frag and bath orbital
        try: 
            erifb = ao2mo.kernel(mol.intor('int2e', aosym='s8'), self.fb_coeff, compact=False)
            self.erifb = erifb.reshape((self.na*2, self.na*2, self.na*2, self.na*2))
        except NotImplementedError: 
            pass

    def change_mu_glob(self, mu_glob):
        self.mu_glob = mu_glob

    def get_occ(self, mo_energy, mo_coeff=None):
        occidx = np.argsort(mo_energy)[:self.na]
        mo_occ = np.zeros_like(mo_energy)
        mo_occ[occidx] = 2

        return mo_occ

    def get_hcore_bare(self, mol=None):
        if mol is None: mol = self.mol
        hao = hf.get_hcore(mol)
        h = np.einsum("mj,mn,nk->jk", self.fb_coeff.conj(), hao, self.fb_coeff)
        return h
    
    def get_hcore(self, mol=None, mu_glob=None):
        # h^x, \mu_{glob} -> hcore (in EO)
        if mol is None: mol = self.mol
        
        hao = hf.get_hcore(mol)
        vj, vk = hf.get_jk(mol, self.un_dm)
        hall = hao + vj - .5 * vk
        h = np.einsum("mj,mn,nk->jk", self.fb_coeff.conj(), hall, self.fb_coeff)

        # minus global chemical potential
        if mu_glob is None: mu_glob = self.mu_glob
        for i in range(self.na):
            h[i,i] -= mu_glob
        return h

    def get_ovlp(self, mol=None):   # unitary matrix
        fbdim = self.fb_coeff.shape[1]
        return np.eye(fbdim)

    # with new 'get_jk' function, then 'get_veff' and 'get_fock' are used as before
    def get_jk(self, mol=None, dm=None, hermi=1, with_j=True, with_k=True):
        # density matrix in the frag+bath bases
        return hf.dot_eri_dm(self.erifb, dm, hermi, with_j, with_k)

    def get_init_guess(self, mol=None, key='project'):
        if key == "project": return self.init_guess_by_project(mol)
        else:
            raise NotImplementedError("Other initial guess methods are not available!")

    def init_guess_by_project(self, mol=None):
        return self.dm

    def eig(self, h, s):
        # eigenvalue solver since orbitals are orthornomal.
        e, c = np.linalg.eig(h)
        idx = np.argmax(abs(c.real), axis=0)
        c[:,c[idx,np.arange(len(e))].real<0] *= -1
        return e, c

    def energy_tot(self, dm=None, h1e=None, vhf=None):
        # Partition energy Ex, see Eq. (25) in DMET2016
        hbare = self.get_hcore_bare()
        h1e = self.get_hcore(mu_glob=0)
        h1e = (h1e[:self.na] + hbare[:self.na]) / 2.
        vhf = vhf[:self.na]
        dm = dm[:,:self.na]
        e1 = np.einsum('ij,ji->', h1e, dm)
        e_coul = np.einsum('ij,ji->', vhf, dm) * .5
        self.scf_summary['e1'] = e1.real
        self.scf_summary['e2'] = e_coul.real
        logger.debug(self, 'E1 = %s  E_coul = %s', e1, e_coul)
        return (e1+e_coul).real

    def rhf(self):
        # SCF or post-HF method: return energy, electron numbers and density matrix.
        self.run()
        dm = self.make_rdm1()[:self.na][:,:self.na]
        nx = np.einsum("ii->", dm)
        return self.e_tot, nx, dm

    def fci(self):
        # Full-CI Solver for DMET
        # In fact we do not need SCF results in Full CI lol
        from pyscf.fci.direct_spin1 import FCISolver
        norb = 2*self.na
        nelec = 2*self.na   # Corr problem in DMET is 1/2 occupied itself.
        # h1e = reduce(np.dot, (self.mo_coeff.conj().T, self.get_hcore(), self.mo_coeff))
        # eri = ao2mo.kernel(self.erifb, self.mo_coeff, compact=False)
        # eri = eri.reshape(norb,norb,norb,norb)
        cis = FCISolver(self.mol)
        
        h1e = self.get_hcore()  # at EO picture
        eri = self.erifb
        e, c = cis.kernel(h1e, eri, norb, nelec)

        dm1 = cis.make_rdm1(c, norb, nelec)[:,:self.na]
        dm2 = cis.make_rdm2(c, norb, nelec)[:self.na]

        hbare = self.get_hcore_bare()
        
        h1e = self.get_hcore(mu_glob=0)
        hnew = (h1e[:self.na] + hbare[:self.na]) / 2.
        eri = eri[:self.na]

        ex = np.einsum("pq,qp->", hnew, dm1) + .5 * np.einsum("pqrs,pqrs->", eri, dm2)

        dmx = dm1[:self.na] # 1rdm in the FRAGMENT block
        return ex, np.einsum("ii->", dmx), dmx


class DMET_Outer:
    r'''
    Outer iteration routine in DMET
    Containing fitting of 
        particle number (by global chemical potential)
        and density matrix (by correlation potential)
    '''

    def __init__(self, mf:hf.RHF, fragments:list, dmetclass=DMET_SCF):

        r'''
        fragments: 
        considering symmetry of fragments
        e.g. Hubbard Model
        0  1  2  3  4
        5  6  7  8  9
        10 11 12 13 14
        15 16 17 18 19

        frag = 
        [[[0,1], [15,16], [4,3], [19,18]], 
         [[5,6], [9,8], [10,11], [14,13]], 
         [[2,7], [17,12]]
         ]
        '''

        self.mu_glob = 0
        self._scf = mf
        self.energy_nuc = mf.energy_nuc()
        self.cal = lo.orth_ao(self._scf)
        if self.cal is None or self.cal.shape == (0,0): 
            self.cal = np.eye(mf.mo_coeff.shape[0])   # hubbard
        self.dmetclass = dmetclass
        
        self.u = np.zeros_like(mf.mo_coeff, dtype=np.float32)
        self.fragments = fragments
        
        self.dmets = [self.dmetclass(mf, sym_frag[0]) for sym_frag in fragments]

        self.cle = np.zeros_like(self.cal)

        k = 0
        for sym_frag in fragments:
            frag0 = sym_frag[0]
            cle_frag = np.dot(np.linalg.inv(self.cal), self.dmets[k].frag_coeff)
            for fragment in sym_frag:
                self.cle[np.ix_(fragment, fragment)] += cle_frag[frag0,:]
            k += 1

        self.cae = np.dot(self.cal, self.cle)

        # fixing initial Fock matrix for optimizing u. (in localized bases)
        self.fock0 = np.einsum("mj,mn,nk->jk", self.cal.conj(), mf.get_fock(), self.cal)  
        self.sym_factor = [len(sym_frag) for sym_frag in fragments]
        self.dmx = np.zeros_like(mf.mo_coeff)

    def inner_kernel(self, method="fci"):
        nelec = 0
        dmx = np.zeros_like(self._scf.mo_coeff)
        e_tot = self.energy_nuc

        k = 0
        for sym_frag in self.fragments:
            fragment = sym_frag[0]
            dmet_scf = self.dmets[k]
            if method.upper() in ['FCI']:
                e, n, dm = dmet_scf.fci()
            elif method.upper() in ['HF', 'RHF']:
                e, n, dm = dmet_scf.rhf()
            else:
                raise NotImplementedError("Methods other than HF and FCI have not been implemented yet.")
            
            e_tot += e * self.sym_factor[k]
            nelec += n * self.sym_factor[k]

            for fragment in sym_frag:
                dmx[np.ix_(fragment, fragment)] = dm
            k += 1

        dmx = np.einsum("ms,sr,nr->mn", self.cle, dmx, self.cle.conj())
        
        return e_tot, nelec, dmx

    def chempot_cycle(self, method="fci"):
        r'''
        Cycle of fitting total electron number by 
        '''
        def f(mu_glob):
            for i in range(len(self.dmets)):
                self.dmets[i].change_mu_glob(mu_glob)
            etot, nelec, dmx = self.inner_kernel(method)
            return nelec - self._scf.mol.nelectron

        mu, count = secant(f, 0, 0.1, 1E-12)
        for i in range(len(self.dmets)):
            self.dmets[i].change_mu_glob(mu)

        
    def corr_info(self, u, scf=False):
        r'''
        Provide information of correlation potential
        '''

        # save correlation potential into matrix
        umat = np.zeros_like(self.fock0)
        idx = 0
        k = 0
        for sym_frag in self.fragments:
            frag0 = sym_frag[0]
            idxr = idx + len(frag0)**2
            a = u[idx:idxr].reshape((len(frag0), len(frag0)))

            for fragment in sym_frag:
                umat[np.ix_(fragment, fragment)] = a
            idx = idxr

            k += 1

        if not scf:
            umat = (umat + umat.T) / 2
            mo_energy, mo_coeff = hf.eig(self.fock0+umat, np.einsum("mj,mn,nk->jk", self.cal.conj(), self._scf.get_ovlp(), self.cal))
        else:
            
            calinv = np.linalg.inv(self.cal)
            class RHF_Corr(hf.RHF):
                def __init__(self, mol):
                    super(hf.RHF, self).__init__(mol)

                def get_hcore(self, mol=None):
                    if mol is None: mol = self.mol
                    h0 = hf.get_hcore(mol)
                    h0 += np.einsum("mj,mn,nk->jk", calinv.conj(), umat, calinv)
                    return h0

            mf_corr = RHF_Corr(mol)
            mf_corr.kernel()
            mo_energy = mf_corr.mo_energy
            mo_coeff = np.dot(calinv, mf_corr.mo_coeff)
                
        mo_energy = mo_energy.real
        mo_coeff = mo_coeff.real
        mo_occ = hf.get_occ(self._scf, mo_energy)
        dm_mf = hf.make_rdm1(mo_coeff, mo_occ)

        return umat, mo_energy, mo_coeff, mo_occ, dm_mf

    def update_u(self, u):
        # Test random initialization for correlation potential
        umat = self.corr_info(u)[0]
        self.u = umat

    def corrpot_cycle(self, method="lag"):

        if method == "lag": return self.corrpot_cycle_lag()
        if method == "loss": return self.corrpot_cycle_dmloss()
        else: 
            raise NotImplementedError("Other methods are not available yet.")

    def corrpot_cycle_lag(self):
        r'''
        Iteration cycle for correlation potential
        '''
        from scipy import optimize
        def f(u):
            
            umat, mo_energy, mo_coeff, mo_occ, dm_mf = self.corr_info(u)
            umat = (umat + umat.T) / 2.
            lag = get_corr_laglangian(self.fock0, umat, dm_mf, self.dmx) * -1.
            return lag

        def fprime(u):
            grad = np.zeros_like(u)
            umat, mo_energy, mo_coeff, mo_occ, dm_mf = self.corr_info(u)
            gradmat = get_corr_grad(self.fock0+umat, mo_energy, mo_coeff, mo_occ, dm_mf, self.dmx) * -1.
            gradmat = (gradmat + gradmat.T) / 2.

            idx = 0
            k = 0

            for sym_frag in self.fragments:
                frag0 = sym_frag[0]
                idxr = idx + len(frag0)**2
                grad[idx:idxr] = gradmat[np.ix_(frag0, frag0)].reshape(-1) * self.sym_factor[k]
                idx = idxr

                k += 1
            return grad

        u0 = []
        k = 0
        for sym_frag in self.fragments:
            frag0 = sym_frag[0]
            u0.extend(list(self.u[np.ix_(frag0, frag0)].reshape(-1)))
            k += 1

        u0 = np.array(u0)
        u = optimize.minimize(fun=f, x0=u0, jac=fprime)["x"]
        print("u = ", u)

        return self.corr_info(u)

    def corrpot_cycle_dmloss(self):
        r'''
        Iteration cycle for correlation potential
        '''
        from scipy import optimize
        def f(u):
            
            umat, mo_energy, mo_coeff, mo_occ, dm_mf = self.corr_info(u)
            loss = dmloss(dm_mf, self.dmx, self.fragments)
            return loss

        def fprime(u):
            grad = np.zeros_like(u)
            umat, mo_energy, mo_coeff, mo_occ, dm_mf = self.corr_info(u)
            gradmat = dmloss_grad(dm_mf, self.dmx, mo_energy, mo_coeff, mo_occ, self.fragments)
            gradmat = (gradmat + gradmat.T) / 2.

            idx = 0
            k = 0

            for sym_frag in self.fragments:
                frag0 = sym_frag[0]
                idxr = idx + len(frag0)**2
                grad[idx:idxr] = gradmat[np.ix_(frag0, frag0)].reshape(-1) * self.sym_factor[k]
                idx = idxr

                k += 1
            return grad

        u0 = []
        k = 0
        for sym_frag in self.fragments:
            frag0 = sym_frag[0]
            u0.extend(list(self.u[np.ix_(frag0, frag0)].reshape(-1)))
            k += 1

        u0 = np.array(u0)
        u = optimize.minimize(fun=f, x0=u0, jac=fprime)["x"]
        print("loss = ", "{:6.4e}".format(f(u)))

        return self.corr_info(u)

    def kernel_oneshot(self, method='fci'):
        self.chempot_cycle(method)
        e_tot, nelec, dmx = self.inner_kernel(method)
        print("One-shot DMET energy = ", e_tot)
        return e_tot

    def kernel(self, conv_tol=1E-5, max_step=50, method="fci", ufit="lag"):
        
        u_prev = 0
        norm = 1
        converged = False

        for i in range(max_step):
            if norm > conv_tol:
                self.chempot_cycle(method)
                e_tot, nelec, dmx = self.inner_kernel(method)
                self.dmx = dmx

                umat, mo_energy, mo_coeff, mo_occ, dm_mf = self.corrpot_cycle(ufit)

                umat = (umat + umat.T) / 2.
                self.u = umat

                self._scf.mo_energy = mo_energy
                self._scf.mo_coeff = np.dot(self.cal, mo_coeff) # LO -> AO
                self._scf.mo_occ = mo_occ
                # update DMET parameters from corr potential
                self.dmets = [self.dmetclass(self._scf, sym_frag[0]) for sym_frag in self.fragments]

                e_tot, nelec, dmx = self.inner_kernel()

                norm = np.linalg.norm(umat - u_prev)
                print("|u - u_prev| = {:6.4e}".format(norm), "E = ", e_tot)
                # TODO: DIIS or EDIIS for convergence?
                u_prev = umat
            else: converged = True; break

        e_tot, nelec, dmx = self.inner_kernel()
        print("E = ", e_tot, ", Converged = ", converged)
        return e_tot, converged

if __name__ == "__main__":

    # calculating only one fragment
    fragments = [[[0,1]], [[2,3]], [[4,5]], [[6,7]], [[8,9]]] 

    def make_Hring(l=1.):
        r = l/(2 * np.sin(np.pi / 10))
        atmlst = []
        for i in range(10):
            atmlst.append(['H', (r*np.cos(2. * np.pi/10*i), r*np.sin(2. * np.pi/10*i), 0)])
        mol = gto.Mole()
        mol.atom = atmlst
        mol.basis = 'sto-6g'
        mol.build()
        return mol

    mol = make_Hring(1.4)
    mf = hf.RHF(mol); mf.kernel()
    print(mf.__class__.__name__ == "RHF")
    dmet_outer = DMET_Outer(mf, fragments)
    # dmet_outer.kernel(ufit='loss')
    
    dmet_outer.chempot_cycle(method='fci')
    etot, nelec, dmx = dmet_outer.inner_kernel(method='fci')
    # gradient test

    def f(u):
            
        umat, mo_energy, mo_coeff, mo_occ, dm_mf = dmet_outer.corr_info(u)
        umat = (umat + umat.T) / 2.
        lag = get_corr_laglangian(dmet_outer.fock0, umat, dm_mf, dmx) * -1.
        return lag

    def fprime(u):
        grad = np.zeros_like(u)
        umat, mo_energy, mo_coeff, mo_occ, dm_mf = dmet_outer.corr_info(u)
        gradmat = get_corr_grad(dmet_outer.fock0+umat, mo_energy, mo_coeff, mo_occ, dm_mf, dmx) * -1.            
        gradmat = (gradmat + gradmat.T) / 2.

        idx = 0
        k = 0

        for sym_frag in dmet_outer.fragments:
            frag0 = sym_frag[0]
            idxr = idx + len(frag0)**2
            grad[idx:idxr] = gradmat[np.ix_(frag0, frag0)].reshape(-1) * dmet_outer.sym_factor[k]
            idx = idxr

            k += 1
        return grad

    def get_num_grad(f, u0, du):
        a = []
        for i in range(len(u0)):
            ul = u0.copy(); ul[i] -= du
            ur = u0.copy(); ur[i] += du
            fl = f(ul); fr = f(ur)
            a.append((fr-fl)/(2.*du))

        return np.array(a)

    u0 = np.array([4E-4, -1E-4, -1E-4, -2E-4, 3E-4] * 4)
    u0 = (u0 + u0.T) / 2
    num_grad = get_num_grad(f, u0, 1E-6)

    anal_grad = fprime(u0)
    print(num_grad)
    print(anal_grad)