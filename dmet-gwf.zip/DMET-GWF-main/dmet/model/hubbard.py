# An extension to spin Hubbard model

import numpy as np
from pyscf import gto, ao2mo
from pyscf.scf import hf
from dmet.main.solver import DMET_SCF, DMET_FCI

def get_hcore_2dobc(lx, ly, t):
    
    hcore = np.zeros((lx,ly,lx,ly))

    for i in range(lx):
        for j in range(ly):
            if i+1 in range(lx): hcore[i,j,i+1,j] = -t
            if i-1 in range(lx): hcore[i,j,i-1,j] = -t
            if j+1 in range(ly): hcore[i,j,i,j+1] = -t
            if j-1 in range(ly): hcore[i,j,i,j-1] = -t

    hcore = hcore.reshape((lx*ly, lx*ly))

    return hcore

def get_hcore_2dpbc(lx, ly, t):

    hcore = np.zeros((lx, ly, lx, ly))

    for i in range(lx):
        for j in range(ly):
            hcore[i,j,(i+1)%lx,j] = -t
            hcore[i,j,(i-1)%lx,j] = -t
            hcore[i,j,i,(j+1)%ly] = -t
            hcore[i,j,i,(j-1)%ly] = -t

    hcore = hcore.reshape((lx*ly, lx*ly))

    return hcore

def get_hcore_1dobc(lx,t):

    hcore = np.zeros((lx,lx))
    for i in range(lx):
        if i+1 in range(lx): hcore[i,i+1] = -t
        if i-1 in range(lx): hcore[i,i-1] = -t

    return hcore

def get_hcore_1dpbc(lx,t):
    hcore = np.zeros((lx,lx))
    for i in range(lx):
        hcore[i,(i+1)%lx] = -t
        hcore[i,(i-1)%lx] = -t
        
    return hcore

def energy_tot(mf, dm=None, h1e=None, vhf=None):
    return hf.energy_elec(mf, dm, h1e, vhf)[0]


class HubbardMole(gto.Mole):

    def __init__(self, lx, ly, t, U):
        super(HubbardMole, self).__init__()

        self.t = t
        self.U = U
        self.lx = lx
        self.ly = ly

        self.nao = lx * ly

def gen_qcham_1dhubbard_kpt(norb, t, U):
    h1e = np.zeros((norb, norb))
    eri = np.zeros((norb, norb, norb, norb))

    scale = 2 * np.pi / norb
    for n in range(norb):
        h1e[n,n] += -2 * t * np.cos(n * scale)
        
    for m in range(norb):
        for n in range(norb):
            for p in range(norb):
                q = (m + p - n) % norb

                eri[m,n,p,q] += U / norb
                eri = ao2mo.restore(1, eri, norb)
    
    return h1e, eri

class RHF_Hubbard_KPT(hf.RHF):
    def __init__(self, mol:HubbardMole):
        super(RHF_Hubbard_KPT, self).__init__(mol)

        n = mol.lx * mol.ly
        t = mol.t; U = mol.U
        self.hcore, self._eri = gen_qcham_1dhubbard_kpt(n, t, U)

    def get_hcore(self, mol=None):
        if mol is None: mol = self.mol

        return self.hcore

    def get_ovlp(self, mol=None):
        if mol is None: mol = self.mol
        return np.eye(mol.lx*mol.ly)

class RHF_SpinHubbard(hf.RHF):
    def __init__(self, mol:HubbardMole):
        super(RHF_SpinHubbard, self).__init__(mol)

        n = mol.lx * mol.ly

        self.pbc = False    # Whether periodic bound condition is used

        try:    
            eri = np.zeros((n,n,n,n))
            for i in range(n): eri[i,i,i,i] = mol.U
            self._eri = ao2mo.restore(8, eri, n)
        except: pass

    def get_hcore(self, mol=None):

        if mol is None: mol = self.mol

        if mol.lx == 1:
            if not self.pbc: return get_hcore_1dobc(mol.ly, mol.t)
            else: return get_hcore_1dpbc(mol.ly, mol.t) 
        elif mol.ly == 1:
            if not self.pbc: return get_hcore_1dobc(mol.lx, mol.t)
            else: return get_hcore_1dpbc(mol.lx, mol.t) 
        else:
            if not self.pbc: return get_hcore_2dobc(mol.lx, mol.ly, mol.t)
            else: return get_hcore_2dpbc(mol.lx, mol.ly, mol.t)

    def get_ovlp(self, mol=None):
        if mol is None: mol = self.mol
        return np.eye(mol.lx*mol.ly)

    def get_veff(self, mol=None, dm=None, dm_last=0, vhf_last=0, hermi=1):
        if mol is None: mol = self.mol
        if dm is None: dm = self.make_rdm1()
        if self._eri is not None or not self.direct_scf:
            vhf = np.diag(np.diag(dm)) * mol.U * .5
        else:
            ddm = np.asarray(dm) - np.asarray(dm_last)
            vhf = np.diag(np.diag(ddm)) * mol.U * .5
            vhf += np.asarray(vhf_last)

        return vhf

    energy_tot = energy_tot

class DMET_Hubbard_SCF(DMET_SCF):

    def __init__(self, mf:RHF_SpinHubbard, fragments, mu_glob=0):

        super(DMET_Hubbard_SCF, self).__init__(mf, fragments, mu_glob)

        # get the eri in EO basis for Hubbard
        mol = mf.mol
    
    def get_hcore_bare(self, mol=None):
        if mol is None: mol = self.mol
        hao = self._scf.get_hcore(mol)
        h = np.einsum("mj,mn,nk->jk", self.fb_coeff.conj(), hao, self.fb_coeff)
        return h

    def get_hcore(self, mol=None, mu_glob=None):
        # Hubbard is simpler that there is no unentangled direct+exchange
        h = self.get_hcore_bare(mol)
        if mu_glob is None: mu_glob = self.mu_glob

        for i in range(self.na):
            h[i,i] -= mu_glob
        return h

class DMET_Hubbard_FCI(DMET_Hubbard_SCF, DMET_FCI):

    def __init__(self, mf:RHF_SpinHubbard, fragments, mu_glob=0):

        DMET_Hubbard_SCF.__init__(self, mf, fragments, mu_glob)

    kernel = DMET_FCI.kernel
    get_dmcorr_eo = DMET_FCI.get_dmcorr_eo
