# An extension to spin Hubbard model

import numpy as np
from pyscf import gto, ao2mo
from pyscf.scf import hf
from pyscf.lib import logger
from pyblock2.driver.core import DMRGDriver, SymmetryTypes


def get_hcore_2dobc(lx, ly, t):
    
    hcore = np.zeros((lx,ly,lx,ly))

    for i in range(lx):
        for j in range(ly):
            if i+1 in range(lx): hcore[i,j,i+1,j] -= t
            if i-1 in range(lx): hcore[i,j,i-1,j] -= t
            if j+1 in range(ly): hcore[i,j,i,j+1] -= t
            if j-1 in range(ly): hcore[i,j,i,j-1] -= t

    hcore = hcore.reshape((lx*ly, lx*ly))

    return hcore

def get_hcore_2dpbc(lx, ly, t):

    hcore = np.zeros((lx, ly, lx, ly))

    for i in range(lx):
        for j in range(ly):
            hcore[i,j,(i+1)%lx,j] -= t
            hcore[i,j,(i-1)%lx,j] -= t
            hcore[i,j,i,(j+1)%ly] -= t
            hcore[i,j,i,(j-1)%ly] -= t

    hcore = hcore.reshape((lx*ly, lx*ly))

    return hcore

def get_hcore_1dobc(lx,t):

    hcore = np.zeros((lx,lx))
    for i in range(lx):
        if i+1 in range(lx): hcore[i,i+1] = -t
        if i-1 in range(lx): hcore[i,i-1] = -t

    return hcore

def get_hcore_1dpbc(lx,t):
    hcore = np.zeros((lx,lx))
    for i in range(lx):
        hcore[i,(i+1)%lx] = -t
        hcore[i,(i-1)%lx] = -t
        
    return hcore

def energy_tot(mf, dm=None, h1e=None, vhf=None):
    return hf.energy_elec(mf, dm, h1e, vhf)[0]


class HubbardMole(gto.Mole):

    def __init__(self, lx, ly, t, U):
        super(HubbardMole, self).__init__()

        self.t = t
        self.U = U
        self.lx = lx
        self.ly = ly

        self.nao = lx * ly

def gen_qchem_1dhubbard_kpt(norb, t, U):
    h1e = np.zeros((norb, norb))
    eri = np.zeros((norb, norb, norb, norb))

    scale = 2 * np.pi / norb
    for n in range(norb):
        h1e[n,n] += -2 * t * np.cos(n * scale)
        
    for m in range(norb):
        for n in range(norb):
            for p in range(norb):
                q = (m + p - n) % norb

                eri[m,n,p,q] += U / norb
                eri = ao2mo.restore(1, eri, norb)
    
    return h1e, eri

class RHF_Hubbard_KPT(hf.RHF):
    def __init__(self, mol:HubbardMole):
        super(RHF_Hubbard_KPT, self).__init__(mol)

        n = mol.lx * mol.ly
        t = mol.t; U = mol.U
        self.hcore, self._eri = gen_qchem_1dhubbard_kpt(n, t, U)

    def get_hcore(self, mol=None):
        if mol is None: mol = self.mol

        return self.hcore

    def get_ovlp(self, mol=None):
        if mol is None: mol = self.mol
        return np.eye(mol.lx*mol.ly)

class RHF_SpinHubbard(hf.RHF):
    def __init__(self, mol:HubbardMole):
        super(RHF_SpinHubbard, self).__init__(mol)

        n = mol.lx * mol.ly

        self.pbc = False    # Whether periodic bound condition is used

        try:    
            eri = np.zeros((n,n,n,n))
            for i in range(n): eri[i,i,i,i] = mol.U
            self._eri = ao2mo.restore(8, eri, n)
        except: pass

        # logger.note(self, f"{self.__class__.__name__}: pbc = {self.pbc}")

    def get_hcore(self, mol=None):

        if mol is None: mol = self.mol

        if mol.lx == 1:
            if not self.pbc: return get_hcore_1dobc(mol.ly, mol.t)
            else: return get_hcore_1dpbc(mol.ly, mol.t) 
        elif mol.ly == 1:
            if not self.pbc: return get_hcore_1dobc(mol.lx, mol.t)
            else: return get_hcore_1dpbc(mol.lx, mol.t) 
        else:
            if not self.pbc: return get_hcore_2dobc(mol.lx, mol.ly, mol.t)
            else: return get_hcore_2dpbc(mol.lx, mol.ly, mol.t)

    def get_ovlp(self, mol=None):
        if mol is None: mol = self.mol
        return np.eye(mol.lx*mol.ly)

    def get_veff(self, mol=None, dm=None, dm_last=0, vhf_last=0, hermi=1):
        if mol is None: mol = self.mol
        if dm is None: dm = self.make_rdm1()
        if self._eri is not None or not self.direct_scf:
            vhf = np.diag(np.diag(dm)) * mol.U * .5
        else:
            ddm = np.asarray(dm) - np.asarray(dm_last)
            vhf = np.diag(np.diag(ddm)) * mol.U * .5
            vhf += np.asarray(vhf_last)

        return vhf

    energy_tot = energy_tot

def hubbard_1d_driver_block2(t, U, L, N, scratch="tempdir", n_threads=24):
    TWOSZ = N % 2
    driver = DMRGDriver(scratch=scratch, symm_type=SymmetryTypes.SZ,
                        n_threads=n_threads)
                        # stack_mem=int(50*1024**3))
    driver.initialize_system(n_sites=L, n_elec=N, spin=TWOSZ)
    b = driver.expr_builder()
    # hopping term
    b.add_term("cd",
        np.array([[[i, (i+1)%L], [(i+1)%L, i]] for i in range(L)]).flatten(),
        [-t] * 2 * (L))
    b.add_term("CD",
        np.array([[[i, (i+1)%L], [(i+1)%L, i]] for i in range(L)]).flatten(),
        [-t] * 2 * (L))
    # onsite term
    b.add_term("cdCD",
        np.array([[i, ] * 4 for i in range(L)]).flatten(),
        [U] * L)
    
    return driver, b.finalize()

def hubbard_2d_driver_block2(t, U, lx, ly, N, scratch="tempdir", n_threads=24):
    

    assert lx >= ly
    TWOSZ = N % 2
    driver = DMRGDriver(scratch=scratch, symm_type=SymmetryTypes.SZ,
                        n_threads=n_threads)
    driver.initialize_system(n_sites=lx * ly, n_elec=N, spin=TWOSZ)
    b = driver.expr_builder()
    
    # on-site term
    b.add_term("cdCD",
        np.array([[i, ] * 4 for i in range(lx * ly)]).flatten(),
        [U] * (lx * ly))

    def coord2idx(coord_x, coord_y=None):
        # change index to coordinate
        if coord_y is None:
            coord_x, coord_y = coord_x
        return coord_x * ly + coord_y    
    # hopping term
    hop_terms = np.array([
        [[coord2idx(i, j), coord2idx((i+1)%lx, j)],
         [coord2idx((i+1)%lx, j), coord2idx(i, j)],
         [coord2idx(i, j), coord2idx(i, (j+1)%ly)],
         [coord2idx(i, (j+1)%ly), coord2idx(i, j)]]
        for i in range(lx) for j in range(ly)]).flatten()
    
    b.add_term("cd", hop_terms, [-t] * (4 * lx * ly))
    b.add_term("CD", hop_terms, [-t] * (4 * lx * ly))
    
    mpo = driver.get_mpo(b.finalize(), iprint=1, add_ident=False)
    
    return driver, mpo

