import sys
sys.path.append("../")
import numpy as np

from dmet import Fragment, DMET
from hubbard import get_hcore_2dobc
from gwftools import slater_to_fci, get_proj
from pyscf import gto, scf, ao2mo

def afm_initguess_dm_2d(lx, ly):
    assert lx % 2 == 0
    assert ly % 2 == 0
    dm_a0 = np.zeros((lx*ly, lx*ly))
    dm_b0 = np.zeros((lx*ly, lx*ly))
    for ix in range(lx):
        for iy in range(ly):
            if (ix + iy) % 2 == 0:
                dm_a0[ix * ly + iy] += 1.
            else:
                dm_b0[ix * ly + iy] += 1.
    return (dm_a0, dm_b0)

lx, ly, t, U = (4, 4, 1, 4)
L = lx * ly

h1e = get_hcore_2dobc(lx, ly, t)
eri = np.zeros((L, L, L, L))
for i in range(L):
    eri[i,i,i,i] += U

frags = list(); ranges = [[x] for x in range(L)]
for r in ranges:
    mask = np.zeros(L, dtype=bool)
    mask[r] = True
    frag = Fragment(mask)
    frags.append(frag)

mol = gto.M()
mol.nelectron = L - 2

mf = scf.UHF(mol)
mf.get_hcore = lambda *args: h1e
mf.get_ovlp = lambda *args: np.eye(L)
mf._eri = ao2mo.restore(8, eri, L)

# generate the initial guess of AFM density matrix for 2d
# but minus two electrons 
dm0a, dm0b = afm_initguess_dm_2d(lx, ly)
dm0a[0,0] -= 1.
dm0b[1,1] -= 1. 
dm0 = (dm0a, dm0b)
mf.kernel(dm0=dm0)
# exit()
mol.incore_anyway = True
    
dmet_solver_ci = DMET(mf, fragments=frags, solver='UFCI')

# add the mu_fitting scheme for DMET calculation
dmet_solver_ci = dmet_solver_ci.mu_fitting(mufit='secant')

dmet_solver_ci.kernel()

civec_from_fci = frags[0].solver.c
print("civec_from_fci = ", civec_from_fci)
# do a DMET calculation with RHF solver
dmet_solver_hf = DMET(mf, fragments=frags, solver='UHF')
dmet_solver_hf.kernel()

mo_coeff = frags[0].solver._solver.mo_coeff
mo_occ = frags[0].solver._solver.mo_occ
mo_coeff_occa = mo_coeff[0][:,mo_occ[0]>0]
mo_coeff_occb = mo_coeff[1][:,mo_occ[1]>0]
mo_coeff_occ = (mo_coeff_occa, mo_coeff_occb)
civec_from_uhf = slater_to_fci(mo_coeff_occ, 2, (1, 1))

print("civec_from_fci = ", civec_from_fci)
print("civec_from_uhf = ", civec_from_uhf)

proj_0 = get_proj(civec_from_uhf, civec_from_fci, 1)
print("projector for site 0 = ", proj_0)
