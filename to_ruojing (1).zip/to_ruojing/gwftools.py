# gutzwiller tools 

from pyscf import fci
import numpy as np
from pyblock3.algebra.core import SubTensor

def slater_to_fci(clm, nao, nelec):
    # Get the Full-CI coefficient for Slater determinant in CI.
    nea, neb = nelec

    clma, clmb = clm    

    stra = fci.cistring.make_strings(range(nao), nea)
    strb = fci.cistring.make_strings(range(nao), neb)

    elidxa = [np.array(list(reversed([x for x in range(nao) if s&2**x]))) for s in stra]
    elidxb = [np.array(list(reversed([x for x in range(nao) if s&2**x]))) for s in strb]

    detca = np.array([np.linalg.det(clma[elidx,:]) for elidx in elidxa])
    detcb = np.array([np.linalg.det(clmb[elidx,:]) for elidx in elidxb])

    ci = np.einsum("i,j->ij", detca, detcb)

    return ci

def get_proj(ci_slater, ci_dmet, nocc):

    """
    .. math::

        | HF \rangle = \sum\limits_i \lambda_i | \alpha_i \rangle \otimes | \beta_i; \Psi_c \rangle \\

        | DMET \rangle = \sum\limits_{ji} C_{ji} | \alpha_j \rangle \otimes | \beta_i; \Psi_c \rangle \\

        \hat P = \sum\limits_{ji} \dfrac{C_{ji}}{\lambda_i} | \alpha_j \rangle \langle \alpha_i |

    Then the function gives :math:`P_{ji} = \dfrac{C_{ji}}{\lambda_i}`.
    badict: \beta_i -> \alpha_i
    """

    l = np.zeros_like(ci_dmet)  # l_{ji} = \lambda_i
    strab = list(fci.cistring.make_strings(range(2*nocc), nocc))

    for i in range(2**nocc):

        betaa = 2**nocc - i - 1
        stra = i + 2**nocc*betaa  # |\alpha_i\rangle \otimes |\beta_i\rangle
        stridxa = strab.index(stra)

        str_betaa = [x for x in strab if x>>nocc == betaa]

        for j in range(2**nocc):
            betab = 2**nocc - j - 1
            strb = j + 2**nocc*betab
            stridxb = strab.index(strb)

            c = ci_slater[stridxa, stridxb]

            str_betab = [x for x in strab if x>>nocc == betab]

            for sa in str_betaa:
                aidx = strab.index(sa)
                for sb in str_betab:
                    bidx = strab.index(sb)

                    l[aidx,bidx] = c
    # print("p = ", ci_dmet / l)
    return ci_dmet / l  # return p_{ji} = c_{ji}/L_{i}

def has_config(fullstr, fragstr, frag, badict):

    # given product state | \psi \rangle (fullstr)
    # and | \beta_i \rangle (fragstr)
    # to evaluate whether \langle \alpha_i | \psi \rangle \ne 0
    
    isconf = True

    beta = fragstr >> len(frag) # | \beta_i >
    alpha = badict[beta]        # | \alpha_i>

    for i in range(len(frag)):
        fidx = frag[i]  # the position of site

        sfullstr = fullstr >> fidx  # shift to the defined site
        sfragstr = alpha >> i  
        # whether the last digit is zero -> site occupation are identical     
        crit = (sfullstr^sfragstr) % 2  
        if crit != 0: 
            # if has difference, then the full string doesn't have config |a_i>.
            isconf = False; break   

    return isconf

def change_config(fullstr, fragstr, frag):
    for i in range(len(frag)):
        fidx = frag[i]

        lowbits = fullstr - ((fullstr >> fidx) << fidx)
        fullstr = (fullstr >> (fidx+1)) << 1
        fullstr += (fragstr>>i)%2   # restore the 
        fullstr = fullstr << fidx
        fullstr += lowbits

    return fullstr

def dmrg_gwf_1site(pyket, projectors, sites, normalized=True):
    """
    given a dmrg ket and Gutzwiller projectors, return the product
    """
    resket = pyket.copy()
    qnsdict = {(0,0): 0, (1,1): 1, (1,-1): 2, (2,0): 3}

    for i, site in enumerate(sites):
        projector = np.array(projectors[i]).ravel() # 4-size
        for j, block in enumerate(pyket.tensors[site].blocks):
            qls = block.q_labels
            qn = (qls[1].n, qls[1].twos)
            p = projector[qnsdict[qn]]
            resket.tensors[site].blocks[j] = block * p
            
    if normalized:
        norm = np.sqrt(resket @ resket)
        resket = resket / norm
    return resket

def dmrg_gwf_deriv_1site(pyket0, pyket, pympo, sites):
    """
    derivative, 
    assume pyket0 is NORMALIZED, but pyket not.
    """
    response_ketss = []
    
    qns = [(0,0), (1,1), (1,-1), (2,0)]
    
    for i, site in enumerate(sites):        
        # generate the zero-block lists for frequent use in generating derivative
        zeroblocks = []
        for l, b in enumerate(pyket.tensors[site].blocks):
            zeroblocks.append(SubTensor(np.zeros_like(np.asarray(b)), q_labels=b.q_labels))

        response_kets = []
        for k, qn in enumerate(qns):
            ket_deriv = pyket.copy()
            for j, block in enumerate(pyket0.tensors[site].blocks):
                qn_block = (block.q_labels[1].n, block.q_labels[1].twos)
                # if i == 0: print(qn_block)
                if qn == qn_block:
                    ket_deriv.tensors[site].blocks[j] = block
                else:
                    ket_deriv.tensors[site].blocks[j] = zeroblocks[j]
            response_kets.append(ket_deriv)
        response_ketss.append(response_kets)

    # e0 = pyket @ (pympo @ pyket)
    
    ovlp_response = np.array([[(ket @ pyket) for ket in kets] for kets in response_ketss])   
    ham_response = np.array([[(ket @ (pympo @ pyket)) for ket in kets] for kets in response_ketss])
    
    # ketdot = pyket @ pyket
    
    return (2. * ham_response, 2. * ovlp_response)


def fci_gwf(nao, nelec, ci_slater, p, fraglst, normalized=True):

    # projection operator also arrange as CI coefficient
    
    # fraglst: considering symmetry

    ci = ci_slater.copy()
    nea, neb = nelec

    stra = list(fci.cistring.make_strings(range(nao), nea))
    strb = list(fci.cistring.make_strings(range(nao), neb))

    for x in range(len(fraglst)):

        proj = p[x]
        sym_frag = fraglst[x]
        badict = [2**len(sym_frag[0])-i-1 for i in range(2**len(sym_frag[0]))]

        for frag in sym_frag:
    
        #frag + bath string
            strx = fci.cistring.make_strings(range(2*len(frag)), len(frag))  
            newci = np.zeros_like(ci)

            for a in range(len(strx)):

                strxa = strx[a] # | \alpha_j > * | \beta_i >

                for strfai in stra:
                    if has_config(strfai, strxa, frag, badict):     # |\psi> has | \alpha_i > on site
                        strfaj = change_config(strfai, strxa, frag) # change |\alpha_i> site to |\alpha_j>

                        aiidx = stra.index(strfai)
                        ajidx = stra.index(strfaj)

                        for b in range(len(strx)):
                            pab = proj[a,b]     # p_{ji} | \alpha_j > < \alpha_i |
                            strxb = strx[b]     

                            for strfbi in strb:
                                if has_config(strfbi, strxb, frag, badict):
                                    strfbj = change_config(strfbi, strxb, frag)
                                    biidx = strb.index(strfbi)
                                    bjidx = strb.index(strfbj)
                                    newci[ajidx, bjidx] += pab * ci[aiidx, biidx]  

            ci = newci

    if normalized: ci /= np.sqrt(np.einsum("ij->", ci**2))    # normalization
    return ci

def gwfexact_1site(ci0, norb, nelec, proj, h1e, eri):
    fraglst_full = [[[i] for i in range(norb)]]
    ci_g = fci_gwf(norb, (nelec//2,nelec//2), ci0, 
    [proj], fraglst_full, normalized=False)

    H = fci.direct_spin1.energy(h1e, eri, ci_g, norb, nelec)
    return H
