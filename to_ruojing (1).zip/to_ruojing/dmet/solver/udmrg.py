from dmet.solver import dmrg as rdmrg
from pyblock2.driver.core import SymmetryTypes


class UDMRG(rdmrg.DMRG):

    def __init__(self, nelec=None, verbose=None, conv_tol=None, max_cycle=None, 
                scratch='./tmp', n_threads=4, 
                 symm_type=SymmetryTypes.SZ,
                 bond_dim=500,
                 mpstag="GS",
                 stack_mem=int(1*1024**3)
                 ):

        super().__init__(nelec, verbose, conv_tol, max_cycle, scratch,
                         n_threads, symm_type, bond_dim, mpstag, stack_mem)
        
    def make_rdm12(self):
        # redefine the make_rdm12 to the density matrix package
        return rdmrg.DMRG.make_rdm12s(self)
