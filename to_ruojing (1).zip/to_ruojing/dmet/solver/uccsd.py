from dmet.solver import post_uhf
from dmet.exception import SolverNotConvergedError

from pyscf.cc import uccsd
from pyscf.cc.uccsd import _ChemistsERIs
from pyscf.lib import logger
from pyscf import lib, ao2mo

import numpy as np

# alpha and beta integrals are transformed according to 
# spin-dependent basis, and thus pyscf.cc.uccsd.ao2mo can
# not be used directly
# the following functions are adpated from libdmet

def _init_amps_uhf(mycc, eris=None):
    time0 = logger.process_clock(), logger.perf_counter()
    if eris is None:
        eris = mycc.ao2mo(mycc.mo_coeff)
    nocca, noccb = mycc.nocc

    fova = eris.focka[:nocca,nocca:]
    fovb = eris.fockb[:noccb,noccb:]
    mo_ea_o = eris.mo_energy[0][:nocca]
    mo_ea_v = eris.mo_energy[0][nocca:] + mycc.level_shift
    mo_eb_o = eris.mo_energy[1][:noccb]
    mo_eb_v = eris.mo_energy[1][noccb:] + mycc.level_shift
    eia_a = lib.direct_sum('i-a->ia', mo_ea_o, mo_ea_v)
    eia_b = lib.direct_sum('i-a->ia', mo_eb_o, mo_eb_v)
    
    t1a = fova.conj() / eia_a
    t1b = fovb.conj() / eia_b

    eris_ovov = np.asarray(eris.ovov)
    eris_OVOV = np.asarray(eris.OVOV)
    eris_ovOV = np.asarray(eris.ovOV)
    t2aa = eris_ovov.transpose(0,2,1,3) / lib.direct_sum('ia+jb->ijab', eia_a, eia_a)
    t2ab = eris_ovOV.transpose(0,2,1,3) / lib.direct_sum('ia+jb->ijab', eia_a, eia_b)
    t2bb = eris_OVOV.transpose(0,2,1,3) / lib.direct_sum('ia+jb->ijab', eia_b, eia_b)
    t2aa = t2aa - t2aa.transpose(0,1,3,2)
    t2bb = t2bb - t2bb.transpose(0,1,3,2)
    e  =      np.einsum('iJaB,iaJB', t2ab, eris_ovOV)
    e += 0.25*np.einsum('ijab,iajb', t2aa, eris_ovov)
    e -= 0.25*np.einsum('ijab,ibja', t2aa, eris_ovov)
    e += 0.25*np.einsum('ijab,iajb', t2bb, eris_OVOV)
    e -= 0.25*np.einsum('ijab,ibja', t2bb, eris_OVOV)
    mycc.emp2 = e.real
    logger.info(mycc, 'Init t2, MP2 energy = %.15g', mycc.emp2)
    logger.timer(mycc, 'init mp2', *time0)
    return mycc.emp2, (t1a,t1b), (t2aa,t2ab,t2bb)

def _make_eris_incore_uhf(mycc, mo_coeff=None):
    from dmet.utils.misc import take_eri, tril_take_idx
    import time
    cput0 = (time.process_time(), time.perf_counter())
    eris = _ChemistsERIs()
    eris._common_init_(mycc, mo_coeff)

    nocca, noccb = mycc.nocc
    nmoa, nmob = mycc.nmo
    nvira, nvirb = nmoa-nocca, nmob-noccb

    moa = eris.mo_coeff[0]
    mob = eris.mo_coeff[1]
    naoa, nmoa = moa.shape
    naob, nmob = mob.shape
    assert naoa == naob

    eri_ao = mycc._scf._eri

    # aa
    o = np.arange(0, nocca)
    v = np.arange(nocca, nmoa)
    
    eri_aa = ao2mo.full(ao2mo.restore(4, eri_ao[0], naoa),
                        moa, compact=True)
    
    eris.oooo = take_eri(eri_aa, o, o, o, o)
    eris.ovoo = take_eri(eri_aa, o, v, o, o)
    eris.ovov = take_eri(eri_aa, o, v, o, v)
    eris.oovv = take_eri(eri_aa, o, o, v, v)
    eris.ovvo = take_eri(eri_aa, o, v, v, o)
    
    idx1 = tril_take_idx(o, v, compact=False)
    idx2 = tril_take_idx(v, v, compact=True)
    eris.ovvv = eri_aa[np.ix_(idx1, idx2)].reshape(nocca, nvira, nvira*(nvira+1)//2)
    
    eris.vvvv = take_eri(eri_aa, v, v, v, v, compact=True)
    eri_aa = None
    
    # bb
    O = np.arange(0, noccb)
    V = np.arange(noccb, nmob)
    
    eri_bb = ao2mo.full(ao2mo.restore(4, eri_ao[2], naob),
                        mob, compact=True)
    
    eris.OOOO = take_eri(eri_bb, O, O, O, O)
    eris.OVOO = take_eri(eri_bb, O, V, O, O)
    eris.OVOV = take_eri(eri_bb, O, V, O, V)
    eris.OOVV = take_eri(eri_bb, O, O, V, V)
    eris.OVVO = take_eri(eri_bb, O, V, V, O)
    
    idx1 = tril_take_idx(O, V, compact=False)
    idx2 = tril_take_idx(V, V, compact=True)
    eris.OVVV = eri_bb[np.ix_(idx1, idx2)].reshape(noccb, nvirb, nvirb*(nvirb+1)//2)
    
    eris.VVVV = take_eri(eri_bb, V, V, V, V, compact=True)
    eri_bb = None
    
    # ab
    eri_ab = ao2mo.general(ao2mo.restore(4, eri_ao[1], naoa),
                           (moa, moa, mob, mob), compact=True)
    eri_ao = None
    
    eris.ooOO = take_eri(eri_ab, o, o, O, O)
    eris.ovOO = take_eri(eri_ab, o, v, O, O)
    eris.ovOV = take_eri(eri_ab, o, v, O, V)
    eris.ooVV = take_eri(eri_ab, o, o, V, V)
    eris.ovVO = take_eri(eri_ab, o, v, V, O)
    
    idx1 = tril_take_idx(o, v, compact=False)
    eris.ovVV = eri_ab[np.ix_(idx1, idx2)].reshape(nocca, nvira, nvirb*(nvirb+1)//2)
    
    eris.vvVV = take_eri(eri_ab, v, v, V, V, compact=True)
    
    # ba
    eri_ba = eri_ab.T
    eri_ab = None
    
    eris.OVoo = take_eri(eri_ba, O, V, o, o)
    eris.OOvv = take_eri(eri_ba, O, O, v, v)
    eris.OVvo = take_eri(eri_ba, O, V, v, o)
    
    idx1 = tril_take_idx(O, V, compact=False)
    idx2 = tril_take_idx(v, v, compact=True)
    eris.OVvv = eri_ba[np.ix_(idx1, idx2)].reshape(noccb, nvirb, nvira*(nvira+1)//2)
    eri_ba = None
    return eris

def _ao2mo_uhf(mycc, mo_coeff=None):
    nmoa, nmob = mycc.get_nmo()
    nao = mycc.mo_coeff[0].shape[0]
    nmo_pair = nmoa * (nmoa+1) // 2
    nao_pair = nao * (nao+1) // 2
    mem_incore = (max(nao_pair**2, nmoa**4) + nmo_pair**2) * 8/1e6
    mem_now = lib.current_memory()[0]
    if (mycc._scf._eri is not None and
        (mem_incore+mem_now < mycc.max_memory or mycc.incore_complete)):
        return _make_eris_incore_uhf(mycc, mo_coeff)
    else:
        raise NotImplementedError

class UCCSD(post_uhf.PostHF):
    '''
    unrestricted CCSD
    '''
    def make_rdm12(self, ao_repre=False):
        self.l1, self.l2 = self._solver.solve_lambda(self.t1, self.t2)
        if not self._solver.converged_lambda:
            raise SolverNotConvergedError()
        r1 = self._solver.make_rdm1(self.t1, self.t2, self.l1, self.l2)
        r2 = self._solver.make_rdm2(self.t1, self.t2, self.l1, self.l2)
        if ao_repre:
            r1 = self.basis.transform_rdm1(np.asarray(r1), 'mm,aa')
            r2 = self.basis.transform_rdm2(np.asarray(r2), 'mmmm,aaaa')
        return r1, r2

    def kernel(self, h1e, eri, **kwargs):
        # HF
        post_uhf.PostHF.hf_kernel(self, h1e, eri, **kwargs)
        self.uhf._solver.r1 = None
        self.uhf._solver.r2 = None

        # CCSD
        class UICCSD(uccsd.UCCSD):
            basis = self.basis
            init_amps = _init_amps_uhf
            ao2mo = _ao2mo_uhf

        self._solver = UICCSD(self.mf)
        if self.conv_tol is not None:
            self._solver.conv_tol = self.conv_tol
        if self.max_cycle is not None:
            self._solver.max_cycle = self.max_cycle
        if 'cache4grad' in kwargs and kwargs['cache4grad']:
            self.eris = self._solver.ao2mo()
        else:
            self.eris = None
        self.e_corr, self.t1, self.t2 = \
            self._solver.kernel(eris=self.eris)
        if not self._solver.converged:
            raise SolverNotConvergedError()
        self.E = self.e_corr + self.mf.e_tot

        self.r1, self.r2 = self.make_rdm12(ao_repre=True)

        return self.E, self.r1, self.r2

    def clear_cache(self):
        if hasattr(self, 'eris'):
            del self.eris


class AUCCSD(UCCSD):
    '''
    unrestricted CCSD but not solving lambda
    '''
    def make_rdm12(self, ao_repre=False):
        r1 = self._solver.make_rdm1(self.t1, self.t2, self.t1, self.t2)
        r2 = self._solver.make_rdm2(self.t1, self.t2, self.t1, self.t2)
        if ao_repre:
            r1 = self.basis.transform_rdm1(r1, 'mm,aa')
            r2 = self.basis.transform_rdm2(r2, 'mmmm,aaaa')
        return r1, r2

    def gradient(self, *args, **kwargs):
        raise NotImplementedError

    def mu_response(self, *args, **kwargs):
        raise NotImplementedError
