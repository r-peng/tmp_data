'''
use UCCSD to solve RCCSD problem
the point of doing this is its easier gradient
'''
from dmet.solver import post_hf
from dmet.basis import Basis
from dmet.exception import SolverNotConvergedError

from pyscf.cc import uccsd

class RCCSD(post_hf.PostHF):
    '''
    restricted CCSD
    '''
    def make_rdm12(self, ao_repre=False):
        self.l1, self.l2 = self._solver.solve_lambda(self.t1, self.t2)
        if not self._solver.converged_lambda:
            raise SolverNotConvergedError()
        r1 = self._solver.make_rdm1(self.t1, self.t2, self.l1, self.l2)
        r2 = self._solver.make_rdm2(self.t1, self.t2, self.l1, self.l2)
        r1 = r1[0] + r1[1]
        r2 = r2[0] + r2[2] + r2[1] + r2[1].transpose(2,3,0,1)
        if ao_repre:
            r1 = self.basis.transform_rdm1(r1, 'mm,aa')
            r2 = self.basis.transform_rdm2(r2, 'mmmm,aaaa')
        return r1, r2

    def kernel(self, h1e, eri, **kwargs):
        # HF
        post_hf.PostHF.hf_kernel(self, h1e, eri, **kwargs)

        # CCSD
        uhf = self.mf.to_uhf()
        uhf.get_hcore = self.mf.get_hcore
        uhf.get_ovlp = self.mf.get_ovlp
        self._solver = uccsd.UCCSD(uhf)
        if self.conv_tol is not None:
            self._solver.conv_tol = self.conv_tol
        if self.max_cycle is not None:
            self._solver.max_cycle = self.max_cycle
        self.e_corr, self.t1, self.t2 = self._solver.kernel()
        if not self._solver.converged:
            raise SolverNotConvergedError()
        self.E = self.e_corr + self.mf.e_tot

        self.r1, self.r2 = self.make_rdm12(ao_repre=True)

        return self.E, self.r1, self.r2


class ARCCSD(RCCSD):
    '''
    restricted CCSD but not solving lambda
    '''
    def make_rdm12(self, ao_repre=False):
        r1 = self._solver.make_rdm1(self.t1, self.t2, self.t1, self.t2)
        r2 = self._solver.make_rdm2(self.t1, self.t2, self.t1, self.t2)
        r1 = r1[0] + r1[1]
        r2 = r2[0] + r2[2] + r2[1] + r2[1].transpose(2,3,0,1)
        if ao_repre:
            r1 = self.basis.transform_rdm1(r1, 'mm,aa')
            r2 = self.basis.transform_rdm2(r2, 'mmmm,aaaa')
        return r1, r2

    def gradient(self, *args, **kwargs):
        from dmet.grad.solver.rccsd_slow import ARCCSDGradients
        return ARCCSDGradients(self, *args, **kwargs)

    def mu_response(self, *args, **kwargs):
        from dmet.mu_fitting.solver.rccsd_slow import ARCCSDMuResponse
        return ARCCSDMuResponse(self, *args, **kwargs)
