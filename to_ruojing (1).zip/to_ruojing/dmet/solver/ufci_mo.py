from dmet.solver.ufci import UFCI
from dmet.solver import post_uhf
from dmet.exception import *

import numpy as np

class FCIMO(UFCI, post_uhf.PostHF):
    '''
    restricted Full CI after HF
    '''
    def kernel(self, h1e, eri, dm0=None, **kwargs):
        # HF
        post_uhf.PostHF.hf_kernel(self, h1e, eri, dm0=dm0, **kwargs)

        norb = h1e.shape[1]

        # FCI
        h1e = self.basis.transform_h(h1e, 'aa,mm')
        eri = self.basis.transform_eri(eri, 'aaaa,mmmm')

        if hasattr(self, "c"):
            c0 = self.c[0][0]
        else:
            c0 = 0

        self.E, self.c = \
            self._solver.kernel(h1e, eri, norb, self.nelec)
        if not self._solver.converged:
            raise SolverNotConvergedError()

        if c0 * self.c[0][0] > 0:
            self.change_sign = False
        else:
            self.change_sign = True

        self.r1, self.r2 = self._solver.make_rdm12s(self.c, norb, self.nelec)

        self.r1 = self.basis.transform_rdm1(np.asarray(self.r1), 'mm,aa')
        self.r2 = self.basis.transform_rdm2(np.asarray(self.r2), 'mmmm,aaaa')

        return self.E, self.r1, self.r2