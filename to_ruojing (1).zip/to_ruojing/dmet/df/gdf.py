from dmet import DMET

from pyscf.df import DF
from pyscf.lib import einsum, logger

import numpy as np

class GDF_DMET(DMET):
    def __init__(self, dmet_obj):
        self.__dict__.update(dmet_obj.__dict__)

        assert hasattr(self.mf, 'with_df') and self.mf.with_df is not None
        assert isinstance(self.mf.with_df, DF)

    def transform_eri(self):
        mf = self.mf

        self.log.note("ERI transform using density fitting")
        from pyscf.lib import unpack_tril, dot

        ## initialize ##
        for f in self.fragments:
            nao = mf.mol.nao
            neo = f.basis.Cao2eo.shape[-1]
            f.h2 = 0
            if self.cache4grad:
                f.eri_aeee = np.zeros((nao,neo,neo,neo))
                f.Lij = np.zeros((mf.with_df.auxmol.nao,neo,neo))

        cput0 = (logger.process_clock(), logger.perf_counter())
        i0 = 0
        for j3c in mf.with_df.loop():
            for ifrag, f in enumerate(self.fragments):
                #Luj = unpack_tril(j3c) @ f.basis.Cao2eo
                Luj = einsum('luv,vi->lui', unpack_tril(j3c), f.basis.Cao2eo)
                Lij = einsum('luj,ui->lij', Luj, f.basis.Cao2eo)
                nblk = Lij.shape[0]

                i1 = i0 + nblk
                if self.cache4grad:
                    f.eri_aeee += einsum('Luj,Lkl->ujkl', Luj, Lij)
                    f.Lij[i0:i1] += Lij
                else:
                    f.h2 += einsum('Lij,Lkl->ijkl', Lij, Lij)

                i0 = i1
        if self.cache4grad:
            for f in self.fragments:
                f.h2 = einsum('ujkl,ui->ijkl', f.eri_aeee, f.basis.Cao2eo)
        self.log.timer(f'ERI transformation total', *cput0)

    make_h2 = transform_eri

    def nuc_grad_method(self, **kwargs):
        from dmet.grad import df 
        return df.gdf.GDF_DMETGradients(self, **kwargs)
