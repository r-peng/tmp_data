from dmet.linalg import unitary_generator
from pyscf.scf.hf import SCF

class DMETSCF(SCF):
    def __init__(self, dmet_obj, canonical=False):
        self.dmet = dmet_obj
        self.dmet.cache4grad = True
        # conv_tol_cphf < 0 will turn off cphf
        self.dmetgrad = self.dmet.nuc_grad_method(conv_tol_cphf=-1)
        self.Edmet = None
        self.init_guess = "HF"

        self.canonical = canonical
        self.get_occ = self.dmet.mf.get_occ

        SCF.__init__(self, self.dmet.mol)

    def get_init_guess(self, mol, key="HF", **kwargs):
        from dmet.exception import SCFNotConvergedError
        assert mol is self.dmet.mf.mol
        if key == "HF":
            mf = self.dmet.mf
            # global mean-field
            if not mf.converged:
                if hasattr(mf, 'with_df') and mf.with_df is not None:
                    mf.with_df.build()
                self.dmet.Ehf = mf.kernel()
            else:
                self.dmet.Ehf = mf.e_tot
            if not mf.converged:
                raise SCFNotConvergedError()
            self.dmet.aodm = mf.make_rdm1()
            self.dmet.aohcore = mf.get_hcore()
            self.dmet.aofock = mf.get_fock() 
            return self.dmet.aodm
        else:
            raise NotImplementedError

    def get_ovlp(self, mol=None):
        if mol is None: mol = self.mol
        else: assert mol is self.dmet.mol
        if self.dmet.basis is not None:
            pass
        else:
            from copy import copy
            # make basis
            basis = self.dmet.lo_method()
            basis.make_ao_lo(self.dmet.mf.get_ovlp())
            self.dmet.basis = basis
            for f in self.dmet.fragments:
                f.basis = copy(basis)

        return self.dmet.basis.ovlp

    def get_hcore(self, mol=None):
        if mol is None: mol = self.mol
        else: assert mol is self.dmet.mol
        if hasattr(self.dmet, 'aohcore') and self.dmet.aohcore is not None:
            pass
        else:
            self.dmet.aohcore = self.dmet.mf.get_hcore(mol)
        return self.dmet.aohcore

    def get_veff(self, mol=None, dm=None, *args, **kwargs):
        if mol is None: mol = self.mol
        else: assert mol is self.mol
        if dm is None: dm = self.make_rdm1()
        return self.get_aoFbar(dm) - self.get_hcore()

    def energy_tot(self, dm=None, h1e=None, vhf=None):
        assert self.dmet.aodm is dm
        assert h1e is self.dmet.aohcore
        # TODO check consistency of vhf with dm
        return self.Edmet

    def get_aoFbar(self, dm=None):
        if dm is None:
            pass
        else:
            '''
            this is basically dmet.kernel()
            but aodm is replaced by the given dm
            '''
            dmet = self.dmet
            dmetgrad = self.dmetgrad
            basis = dmet.basis

            ## make new emb basis with given aodm ##
            dmet.aodm = dm
            dmet.lodm = basis.transform_dm(dm, 'aa,ll')
            for f in dmet.fragments:
                f.basis.make_lo_eo(dmet.lodm, f, bath_tol=dmet.bath_tol)
                f.basis.make_ao_eo()

            ## make new embedding Hamiltonian ##
            dmet.aofock = dmet.aohcore + dmet.mf.get_veff(dm=dm)
            dmet.make_h2()
            dmet.make_h1()
            ## solve impurity problem and comptue energy ##
            dmet.solve_impurity()
            dmet.Edmet_tot = dmet.compute_energy() 
            self.Edmet = dmet.Edmet_tot + self.mol.energy_nuc()

            '''
            this is basically dmetgrad.kernel()
            but we stop before solving cp-hf
            '''
            dmetgrad.grad_solver()
            dmetgrad.grad_lodm()
            dmetgrad.grad_aodm()

        return self.dmetgrad.aoFbar

    def eig(self, fock, s1e):
        if self.canonical:
            return self.dmet.mf.eig(fock, s1e)
        else:
            '''
            instead of diagonalize the full fock with ovlp s1e
            block-diagonalize fock using root-finding 
            '''
            from scipy.optimize import root
            if self.mo_coeff is None:
                self.mo_coeff = self.dmet.mf.mo_coeff.copy()
            moF = self.mo_coeff.T @ fock @ self.mo_coeff
            nao = self.mol.nao
            nocc = sum(self.dmet.mf.mo_occ > 0)
            def obj_func(theta):
                U = unitary_generator(theta, nao, nocc)
                return (U.T @ moF @ U)[nocc:, :nocc].ravel()
            res = root(obj_func, [0]*(nocc*(nao-nocc)))
            U = unitary_generator(res.x, nao, nocc)
            self.mo_coeff = self.mo_coeff @ U
            print("U =", U)
            print("mo_coeff =", self.mo_coeff)
            print("Fvo =", (self.mo_coeff.T @ fock @ self.mo_coeff)[nocc:,:nocc])
            print("mo_coeff - mf.mo_coeff =", self.mo_coeff-self.dmet.mf.mo_coeff)
            # return fake mo_energy to be used in get_occ
            return self.dmet.mf.mo_energy, self.mo_coeff

    def kernel(self, *args, **kwargs):
        if self.canonical:
            self.dmet.log.warn("Canoincal DMET-SCF may never converge. " + \
                                "Consider using orbital optimization versions instead!")
        res = super().kernel(*args, **kwargs)
        if not self.canonical:
            '''
            if not canonical HF, no well-defined orbital energy
            '''
            self.mo_energy = None
        return res
