from dmet.mf_fitting.scf.dmet_scf import DMETSCF

class DMETSCF_LBFGS(DMETSCF):
    def __init__(self, dmet_obj):
        DMETSCF.__init__(self, dmet_obj, canonical=False)

    def kernel(self, init=None, bounds=None):
        from scipy.optimize import minimize
        import scipy.linalg as la
        import numpy as np

        from dmet.exception import DMETSCFNotConvergedError
        from dmet.linalg import unitary_generator
        from pyscf.lib.logger import INFO

        # initialize things in self.dmet and self.dmetgrad
        self.get_ovlp()
        if init is None:
            dm = self.get_init_guess(self.mol)
            C0 = self.dmet.mf.mo_coeff
        else:
            dm = init['dm0']
            C0 = init['C0']
        self.get_hcore(self.mol)
        self.get_veff(dm=dm)

        nocc = sum(self.dmet.mf.mo_occ > 0)
        nvir = self.mol.nao - nocc

        self.cycle = 0

        def obj_func(theta):
            assert theta.size == nocc * nvir
            if self.cycle != 0:
                U = unitary_generator(theta, self.mol.nao, nocc)
                C = C0 @ U
                dm = self.dmet.mf.make_rdm1(mo_coeff=C)
                fock = self.get_aoFbar(dm)
            else:
                C = C0
                fock = self.get_aoFbar()
            g = (2 * C.T @ fock @ C)[nocc:, :nocc] # *2 because restricted rdm =2 CC.T

            self.mo_coeff = C
            self.cycle += 1

            return self.Edmet, 2 * g.ravel() # *2 because g = 2 * F_VO

        self.obj_func = obj_func
        self.mo_occ = self.dmet.mf.mo_occ

        if bounds is not None:
            if type(bounds) is float:
                if bounds > 0:
                    bounds = [[-bounds,bounds]] * (nocc*nvir)
                else:
                    raise Exception("cannot understand given bounds")
            if isinstance(bounds, list) or isinstance(bounds, tuple):
                if len(bounds) == nvir * nocc:
                    pass
                elif len(bounds) == 2:
                    bounds = [[bounds[0],bounds[1]]] * (nocc*nvir)
        res = minimize(obj_func, np.zeros((nvir, nocc)),
                        method='L-BFGS-B', jac=True,
                        bounds=bounds,
                        options={'maxiter': self.max_cycle, 
                                'disp': self.verbose >= INFO,
                                'ftol': self.conv_tol} )
        self.opt_res = res

        if not res.success:
            raise DMETSCFNotConvergedError
        
        return self.Edmet
