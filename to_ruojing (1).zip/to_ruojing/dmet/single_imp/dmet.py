from dmet import DMET, Fragment
import numpy as np

class SingleImpDMET(DMET):
    def __init__(self, mf, fragments, **kwargs):
        if type(fragments) is Fragment:
            fragments = [fragments]
        else:
            assert len(fragments) == 1
        super().__init__(mf, fragments, **kwargs)

    def compute_energy(self):
        f = self.fragments[0]
        Eemb = np.trace(f.r1 @ f.h1.T) + 0.5 * f.r2.ravel() @ f.h2.ravel()
        dm_core = self.aodm - f.basis.transform_dm(f.dm_proj, 'ee,aa')
        vcore = self.mf.get_veff(dm=dm_core)
        Ecore = np.trace(dm_core @ (self.aohcore+0.5*vcore).T) 
        if self.cache4grad:
            f.vcore = vcore
            f.dm_core = dm_core
        return Eemb+Ecore

    def density_fit(self, df="GDF"):
        if df == 'GDF':
            from dmet.df.single_imp.gdf import GDF_SingleImpDMET
            return GDF_SingleImpDMET(self)
        else:
            raise NotImplementedError

    def nuc_grad_method(self, **kwargs):
        from dmet.grad.single_imp.dmet import SingleImpDMETGradients
        return SingleImpDMETGradients(self, **kwargs)
