from dmet.grad.single_imp.dmet import SingleImpDMETGradients

from pyscf.lib import einsum, dot, logger, unpack_tril, current_memory

from scipy import linalg as la
import numpy as np


class GDF_DMETGradients(SingleImpDMETGradients):
    def __init__(self, base, **kwargs):
        SingleImpDMETGradients.__init__(self, base, **kwargs)
        from pyscf import df
        if hasattr(self.base, 'dft'):
            raise NotImplementedError("GDF gradient does not support DFT mean-field")
        if not isinstance(self.base.mf.with_df, df.GDF):
            raise NotImplementedError("GDF gradient only supports molecular systems")

        from dmet.df.single_imp.gdf import GDF_SingleImpDMET
        assert type(self.base) is GDF_SingleImpDMET

    def get_mfgrad_veff(self, df, graddf, dm,
        uvLR=None, pRq=None, auxbasis_response=False):
        if auxbasis_response:
            raise NotImplementedError
        else:
            assert uvLR is None
            assert pRq is None
            blksize = (df.blockdim + graddf.blockdim) // 2
            v = 0
            for Luv, LuRv in zip(df.loop(blksize), graddf.loop(blksize)):
                # Luv has shape (naux, nao_pair)
                # LxuRv has shape (naux, 3, nao, nao)
                Luv = unpack_tril(Luv)
                nL, nao, _ = Luv.shape
                assert nao == _
                #rhoj = einsum('Luv,uv->L', Luv, dm)
                rhoj = Luv.reshape(nL,nao**2) @ dm.ravel()
                # v += einsum('L,Lxuv->xuv', rhoj, LuRv)
                v += LuRv.transpose(1,2,3,0) @ rhoj 
                # v-= (L|uRv) (L|ls) dm_vl
                # Ldm = Luv @ dm 
                Ldm = einsum('Luv,vw->Luw', Luv, dm) # (L|uv) dm_vl = (L|ul)
                v -= 0.5 * einsum('Lxuv,Lsv->xus', LuRv, Ldm)
            return v

    def contract_ao(self, atmlst=None, mmgrad=False):
        # sanity check
        if mmgrad:
            ''' this is for qm/mm '''
            assert hasattr(self.mfgrad, 'grad_nuc_mm')
            assert hasattr(self.base.mf, 'mm_mol')
        # decrease some depth
        mf = self.base.mf
        mfgrad = self.mfgrad
        fragments = self.base.fragments
        f = fragments[0]
        nao = mf.mol.nao
        aodm = self.base.aodm
        aodmbar = self.aodmbar
        moFbar = self.moFbar
        r1sum = f.r1bar + f.r1

        # AO derivatives
        ovlpR = mfgrad.get_ovlp()
        self.base.log.note("ERI deriv transformation using density fitting")
        from pyscf import df
        auxmol = mf.with_df.auxmol
        if self.auxbasis_response:
            raise NotImplementedError("Density fitting auxbasis response")
        else:
            self.base.log.warn("Density fitting grad ignoring auxbasis response")
        if hasattr(mf.with_df, 'low') and mf.with_df.low is not None:
            low = mf.with_df.low
        elif hasattr(mf.with_df, '_low') and mf.with_df._low is not None:
            low = mf.with_df._low
        else:
            j2c = auxmol.intor('int2c2e')
            low = la.cholesky(j2c, lower=True)
        lowinv = la.solve_triangular(low, np.eye(low.shape[0]), check_finite=True, lower=True)
        del low
        
        # build uRvL
        naoaux = auxmol.nao
        max_memory = mf.mol.max_memory - current_memory()[0]
        graddf = df.GDF(mf.mol, auxbasis=mf.with_df.auxmol.basis)
        cput0 = (logger.process_clock(), logger.perf_counter())
        if 3*nao**2*naoaux*8/1e6 < 0.9*max_memory:
            int3c = df.incore.aux_e2(
                mf.mol, auxmol, intor='int3c2e_ip1', aosym='s1', comp=3)
#            uRvL = -la.solve_triangular(low, int3c.reshape(-1,naoaux).T, lower=True).T.\
#                                            reshape(3,nao,nao,naoaux)
#            graddf._cderi = uRvL.transpose(3,0,1,2) # (L, x, uR, v)
            graddf._cderi = einsum('Lp,xuvp->Lxuv', -lowinv, int3c)
            del int3c
        else:
            raise NotImplementedError
        self.base.log.timer(
            f'j3c deriv', *cput0)

        # build f.eri_aeee = f.uRijk which I assume could fit in memory
        cput0 = (logger.process_clock(), logger.perf_counter())
        f.eri_aeee = 0
        Lij = f.Lij
        LuRj = einsum('Lxuv,vj->Lxuj', graddf._cderi, f.basis.Cao2eo)
        f.eri_aeee += einsum('Lxuj,Lkl->xujkl', LuRj, Lij)
        self.base.log.timer(
            f'ERI deriv transformation total', *cput0)

        mfdf = mf.with_df
        vhfR = self.get_mfgrad_veff(mfdf, graddf, aodm)
        self.base.log.timer('vhfR', *cput0)
        gen_hcore = mfgrad.hcore_generator()

        # common useful
        aoslices = mf.mol.aoslice_by_atom()
        occ = mf.mo_occ > 0
        vir = ~occ
        Zuj = mf.mo_coeff[:,vir] @ self.Z
        Zuv  = Zuj @ mf.mo_coeff[:,occ].T
        Zsymm = (Zuv + Zuv.T) / 2                    
        if atmlst is None:
            atmlst = range(mf.mol.natm)
        de = np.zeros((len(atmlst),3))

        # eq 145 1st, eq 156 1st, Ehf(dm_core)
        if not hasattr(self.base, 'dft'):
            r1temp1 = Zuv + aodmbar
            r1temp2 = r1temp1 + f.dm_core         # to be contracted with h1R
            r1temp1 = (r1temp1 + r1temp1.T) / 2   # vhfR only has bra, transpose for ket 
            cput0 = (logger.process_clock(), logger.perf_counter())
            vhftempR = self.get_mfgrad_veff(mfdf, graddf, r1temp1)
            self.base.log.timer('vhftempR', *cput0)
            cput0 = (logger.process_clock(), logger.perf_counter())
            vhfcoreR = self.get_mfgrad_veff(mfdf, graddf, f.dm_core)
            self.base.log.timer('vhfcoreR', *cput0)

            del graddf

            if mmgrad:
                self.de_mm = mfgrad.contract_hcore_mm(r1temp2)
            for k, ia in enumerate(atmlst):
                p0, p1 = aoslices[ia,2:]
                h1ao = gen_hcore(ia)
                de[k] += einsum('xij,ij->x', h1ao, r1temp2)
                # *2 for adding r1_uv V_uvRwx aodm_wx
                de[k] += einsum('xij,ij->x', vhfR[:,p0:p1], r1temp1[p0:p1]) * 2
                # *2 for adding aodm_uv V_uvRwx r1_wx 
                de[k] += einsum('xij,ij->x', vhftempR[:,p0:p1], aodm[p0:p1]) * 2
                # EHF(dm_core)
                de[k] += einsum('xij,ij->x', vhfcoreR[:,p0:p1], f.dm_core[p0:p1]) * 2
            del r1temp1
            del r1temp2
        else:
            # dft as mean-field
            raise NotImplementedError
        del vhftempR
        del vhfcoreR

        # eq 145 1st in cphf
        if hasattr(self.base, 'dft'):
            mf = self.base.dft
        vresp = mf.gen_response(singlet=None, hermi=1)
        Etemp  = einsum('uj,vj,j->uv', Zuj, mf.mo_coeff[:,occ], -mf.mo_energy[occ])
        Etemp -= 0.5 * aodm @ vresp(Zsymm) @ aodm
        # eq 145 2nd
        Etemp -= mf.mo_coeff[:,occ] @ moFbar[np.ix_(occ,occ)] @ mf.mo_coeff[:,occ].T
        # eq 152-154
        Etemp += self.Ebar
        Etemp += Etemp.T            # ovlpR only has bra, transpose for ket 
        for k, ia in enumerate(atmlst):
            p0, p1 = aoslices[ia,2:]
            de[k] += einsum('xij,ij->x', ovlpR[:,p0:p1], Etemp[p0:p1])
        del Etemp

        def rVr(rx, V, ry, Cui):
            '''
            rx_ji V_u^Rjkl ry_kl C_ui
            '''
            veff = self.get_veff(V, ry)
            temp = einsum('xuj,ji->xui', veff, rx)
            return einsum('xui,ui->xu', temp, Cui)
        gtemp = 0
        Cao2eo = f.basis.Cao2eo
        neo = Cao2eo.shape[1]
        eriR = f.eri_aeee
        # eq 156 2nd
        gtemp -= 2 * rVr(r1sum, eriR, f.dm_proj, Cao2eo)
        # eq 156 3rd
        gtemp -= 2 * rVr(f.dm_proj, eriR, r1sum, Cao2eo)
        # eq 157
        r2sum = (f.r2 + f.r2.transpose(1,0,2,3)) / 2
        r2sum = (r2sum + r2sum.transpose(0,1,3,2)) / 2
        r2sum += f.r2bar
        #temp = einsum('ijkl,xujkl->xui', r2sum, eriR)
        temp = eriR.reshape(3,nao,-1) @ r2sum.reshape(neo,-1).T
        gtemp += 2 * einsum('xui,ui->xu', temp, Cao2eo)
        for k, ia in enumerate(atmlst):
            p0, p1 = aoslices[ia,2:]
            de[k] += einsum('xu->x', gtemp[:,p0:p1])
        del gtemp

        self.de = de 
