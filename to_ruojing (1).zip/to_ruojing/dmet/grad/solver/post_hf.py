from dmet.grad.solver.solver import SolverGradients

from pyscf.lib import direct_sum, einsum, logger

from scipy.sparse import linalg as sla
import numpy as np

class PostHFGradients(SolverGradients):
    def __init__(self, base, conv_tol=1e-6, max_cycle=50, verbose=0):
        super().__init__(base, conv_tol, max_cycle, verbose)

    def lambda_size(self):
        return self.mf_lambda_size() + self.corr_lambda_size()

    def check_consistency(self):
        from dmet.solver.post_hf import PostHF
        assert isinstance(self.base, PostHF)

    def clear_cache(self):
        pass

    def dE_dc(self, h1pp, h2w, same_h=False):
        dEdc_corr = self.dE_dc_corr(h1pp, h2w, same_h=same_h)
        dEdc_mf = self.dE_dc_mf(h1pp, h2w, same_h=same_h)
        return np.hstack([dEdc_mf.ravel(), dEdc_corr.ravel()])

    def dot_lambda(self, h1, h2):
        if hasattr(self, 'M') and h1 is self.h1 and h2 is self.h2:
            return self.M

        self.h1 = h1
        self.h2 = h2

        # ldMdc(l) = l_corr dot dM_corr / dc_corr
        self.ldMdc = self.dot_lambda_corr(h1, h2)
        # ldMdU(l) = l_corr dot d M_corr / d U_mf
        self.ldMdU = self.dot_lambda_cross(h1, h2)
        # zdMdU(z) = z_mf dot d M_mf / d U_mf
        self.zdMdU = self.dot_lambda_mf(h1, h2)

        z_size = self.mf_lambda_size()
        # corr_size does not include z
        corr_size = self.corr_lambda_size()

        # (z lcorr) [d M^HF / dU    0      ] = (dE/dU dE/dc)
        #           [dM^corr/dU  dM^corr/dc]

        def ldMdc(lmbda):
            res = np.zeros(z_size+corr_size)
            z = lmbda[:z_size]
            lcorr = lmbda[z_size:]
            res[:z_size] = np.ravel(self.zdMdU(z)) + np.ravel(self.ldMdU(lcorr))
            res[z_size:] = np.ravel(self.ldMdc(lcorr))
            return res

        self.M = ldMdc

        return ldMdc

    def make_rdm12(self, lmbda):
        z_size = self.mf_lambda_size()
        z = lmbda[:z_size]
        lcorr = lmbda[z_size:]

        r1_, r2_ = self.make_rdm12_mf(z)
        r1bar, r2bar = self.make_rdm12_corr(lcorr)

        return r1bar + r1_, r2bar + r2_
        
    def kernel(self, h1pp, h2w, h1, h2, **kwargs):
        same_h = (h1pp is h1 and h2w is h2)
        self.b = self.dE_dc(h1pp, h2w, same_h=same_h)
        self.l = self.solve_lambda(h1, h2, same_h=same_h, **kwargs)
        r1bar, r2bar = self.make_rdm12(self.l)
        return r1bar, r2bar

    def solve_lambda(self, h1, h2, same_h=False, **kwargs):
        assert self.base.mf.converged and \
            self.base.mf.get_hcore() is h1 and \
            self.base.mf._eri is h2
        z_size = self.mf_lambda_size()
        lcorr = self.solve_lambda_corr(h1, h2, self.b[z_size:], same_h=same_h)
        bR = self.b[:z_size] - self.dot_lambda_cross(h1, h2)(lcorr).ravel()
        M = self.dot_lambda_mf(h1, h2)
        M = sla.LinearOperator([z_size]*2, M, dtype=np.float64)
        z, stat = sla.gmres(M, bR, tol=self.conv_tol,
            atol=self.conv_tol*np.linalg.norm(bR), 
            maxiter=self.max_cycle)
        if stat != 0:
            raise Exception('HF solver response not converged')
        return np.hstack([np.ravel(z), np.ravel(lcorr)])

    '''
    Virtual functions
    '''
    def corr_lambda_size(self):
        raise NotImplementedError('virtual function called')
    
    def dE_dc_corr(self, h1pp, h2w, *args, **kwargs):
        '''
        h1pp and h2w are expected to be in EO
        '''
        raise NotImplementedError('virtual function called')

    def solve_lambda_corr(self, h1, h2, b, same_h=False):
        tot_size = self.lambda_size()
        z_size = self.mf_lambda_size()
        corr_size = tot_size - z_size
        M = self.dot_lambda_corr(h1, h2)
        M = sla.LinearOperator([corr_size]*2, M, dtype=np.float64)
        Pinv = self.precond_corr()
        if Pinv is not None:
            Pinv = sla.LinearOperator([corr_size]*2, Pinv, dtype=np.float64)
        else:
            Pinv = None
        lcorr, stat = sla.gmres(M, b, tol=self.conv_tol,
            M = Pinv,
            atol=self.conv_tol*np.linalg.norm(b), 
            maxiter=self.max_cycle)
        if stat != 0:
            raise Exception('Correlation solver response not converged')
        return lcorr

    def dot_lambda_corr(self, h1, h2, *args, **kwargs):
        '''
        h1 and h2 are expected to be in EO
        '''
        raise NotImplementedError('virtual function called')

    def precond_corr(self, *args, **kwargs):
        return None

    def dot_lambda_cross(self, h1, h2, *args, **kwargs):
        '''
        h1 and h2 are expected to be in EO
        '''
        raise NotImplementedError('virtual function called')

    def make_rdm12_corr(self, lcorr, *args, **kwargs):
        raise NotImplementedError('virtual function called')

    '''
    Mean-Field related
    '''

    def mf_lambda_size(self):
        norb = self.base.mf.mo_coeff.shape[0]
        return norb*(norb-1) // 2

    def dE_dc_mf(self, h1pp, h2w, same_h=False):
        '''
        compute d Edmet / d U
        '''
        mo_coeff = self.base.mf.mo_coeff

        h1pp_mo = self.base.basis.transform_h(h1pp, 'aa,mm')
        r1_mo = self.base.basis.transform_dm(self.base.r1, 'aa,mm')
        h2wr2  = einsum('uvls,kvls->uk', h2w, self.base.r2)
        h2wr2 += einsum('uvls,ukls->vk', h2w, self.base.r2)

        res = 2 * h1pp_mo @ r1_mo.T
        res += mo_coeff.T @ h2wr2 @ mo_coeff
        res -= res.T
        tril_indx = np.tril_indices_from(h1pp, k=-1)
        return res[tril_indx].ravel()

    def dot_lambda_mf(self, h1, h2):
        '''
        return a function to compute
             zpq d M^HF_pq / d Urs
        where d / dU_pq is the alias of d/dC_uq C_up
              z is Lagrangian multiplier
        '''
        mf = self.base.mf
        assert h1 is mf.get_hcore()
        assert h2 is mf._eri
        norb = h1.shape[0]
        tril_indx = np.tril_indices_from(h1, k=-1)
        e_diff = direct_sum('p-q->pq', mf.mo_energy, mf.mo_energy)[tril_indx]
        nocc = sum(mf.mo_occ > 0)

        def zdMdU(z):
            '''
            z dot dM/dc
            '''
            cput0 = (logger.process_clock(), logger.perf_counter())
            Z = np.zeros([norb]*2)
            Z[tril_indx] = z
            dm = mf.mo_coeff @ Z @ mf.mo_coeff.T
            v = mf.get_veff(mf.mol, dm + dm.T)
            v_mo = 2 * mf.mo_coeff[:,nocc:].T @ v @ mf.mo_coeff[:,:nocc]
            res = np.zeros([norb]*2)
            res[nocc:,:nocc] = v_mo
            self.base.log.timer('PostHF zdMdU', *cput0)
            return (res[tril_indx] + e_diff * z)

        return zdMdU

    def make_rdm12_mf(self, z):
        '''
        r1bar = -z dM^HF / dh_ij
        r2bar = -2 * z dM^HF / d(ij|kl)
        '''
        norb = self.base.mf.mo_coeff.shape[0]
        zpq = np.zeros([norb]*2)
        tril_indx = np.tril_indices_from(zpq, k=-1)
        zpq[tril_indx] = -z

        r1bar = self.base.basis.transform_dm(zpq, 'mm,aa')

        r2bar =  einsum('uv,wx->uvwx', r1bar, self.base.rhf.r1)
        r2bar -= 0.5 * einsum('ux,vw->uvwx', r1bar, self.base.rhf.r1)
        r2bar += r2bar.transpose(2,3,0,1)

        return r1bar, r2bar
