from dmet.grad.solver.post_hf import PostHFGradients

from pyscf.lib import einsum
from pyscf.cc.ccsd import _ChemistsERIs

import numpy as np

class RCISDGradients(PostHFGradients):
    def corr_dE_dc(self, h1pp, h2w):
        '''
        NOTE h1pp and h2w are expected in emb MO basis
        '''
        aux_eris = _ChemistsERIs()

        nocc = sum(self.base.mf.mo_occ > 0)
        aux_eris.mo_coeff = self.base.mf.mo_coeff
        aux_eris.nocc = nocc
        aux_eris.fock = h1pp + 2 * einsum('pqii->pq', h2w[:,:,:nocc,:nocc]) \
            - einsum('piiq->pq', h2w[:,:nocc,:nocc,:])

        aux_eris.oooo = h2w[:nocc, :nocc, :nocc, :nocc]
        aux_eris.ovoo = h2w[:nocc, nocc:, :nocc, :nocc]
        aux_eris.oovv = h2w[:nocc, :nocc, nocc:, nocc:]
        aux_eris.ovvo = h2w[:nocc, nocc:, nocc:, :nocc]
        aux_eris.ovov = h2w[:nocc, nocc:, :nocc, nocc:]
        aux_eris.ovvv = h2w[:nocc, nocc:, nocc:, nocc:]
        aux_eris.vvvv = h2w[nocc:, nocc:, nocc:, nocc:]

        return self.base._solver.contract(self.base.c, aux_eris)

    def corr_dot_lambda(self, h1, h2):
        assert self.base.mf.converged and \
            self.base.mf.get_hcore() is h1 and \
            self.base.mf._eri is h2
        def ldMdc(lmbda):
            dc = lmbda.ravel()
            cdc = self.base.c.reshape(-1) @ dc
            Mdc = 2 * (cdc * self.base.c)
            Mdc += self.base._solver.contract(lmbda, self.base._solver.eris)
            Mdc -= (self.base.E * dc)
            return Mdc
        return ldMdc

    def cross_dot_lambda(self, h1, h2):
        '''
        l^CI dot dM^CI / dU
        the result has the same shape as U
        '''
        assert self.base.mf.converged and \
            self.base.mf.get_hcore() is h1 and \
            self.base.mf._eri is h2
        h1 = self.base.basis.transform_h(h1, 'aa,mm')
        h2 = self.base.basis.transform_eri(h2, 'aaaa,mmmm')
        tril_indx = np.tril_indices_from(h1, k=-1)
        def ldMdU(lmbda):
            l = lmbda.ravel()
            t_r1 = self.base._solver.trans_rdm1(l, self.base.c)
            t_r2 = self.base._solver.trans_rdm2(l, self.base.c)
            t_r1 += t_r1.T
            t_r2 += t_r2.transpose(1,0,2,3) + \
                    t_r2.transpose(2,1,0,3) + \
                    t_r2.transpose(3,1,2,0)
            res = h1 @ t_r1 + 0.5 * einsum('mjkl,njkl->mn',h2, t_r2)
            return res[tril_indx]
        return ldMdU

    def corr_lambda_size(self):
        return self.base.c.size

    def corr_make_rdm12(self, lcorr):
        lcorr = lcorr.ravel()
        lc = lcorr @ self.base.c
        r1 = self.base._solver.trans_rdm1(lcorr, self.base.c)
        r2 = self.base._solver.trans_rdm2(lcorr, self.base.c)
        r1 = lc * self.base.r1 - r1
        r2 = lc * self.base.r2 - r2
        r1bar = self.base.basis.transform_rdm1(r1, 'mm,aa')
        r2bar = self.base.basis.transform_rdm2(r2, 'mmmm,aaaa')
        return r1bar, r2bar