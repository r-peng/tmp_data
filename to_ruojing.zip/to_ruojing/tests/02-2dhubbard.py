import sys
sys.path.append("../")
import numpy as np
from scipy.optimize import minimize

from dmet import Fragment, DMET
from hubbard import HubbardMole, RHF_SpinHubbard, hubbard_2d_driver_block2
from gwftools import slater_to_fci, get_proj, dmrg_gwf_1site, dmrg_gwf_deriv_1site
from pyblock3.block2.io import MPSTools, MPOTools

lx, ly, t, U = (6, 2, 1, 8)
L = lx * ly
frags = list(); ranges = [[x] for x in range(L)]
for r in ranges:
    mask = np.zeros(L, dtype=bool)
    mask[r] = True
    frag = Fragment(mask)
    frags.append(frag)
    
mol = HubbardMole(lx=lx, ly=ly, t=t, U=U)
mol.nelectron = L
mf = RHF_SpinHubbard(mol)
mf.pbc = True

mol2 = HubbardMole(lx=lx, ly=ly, t=t, U=0)
mol2.nelectron = L
mf2 = RHF_SpinHubbard(mol2)
mf2.pbc = True
mf2.kernel()

mf.converged = True
mf.mo_energy = mf2.mo_energy
mf.mo_coeff = mf2.mo_coeff
mf.mo_occ = mf2.mo_occ
# do a DMET calculation with FCI solver
dmet_solver_ci = DMET(mf, fragments=frags, solver='FCI')
dmet_solver_ci.kernel()

civec_from_fci = frags[0].solver.c
    
# do a DMET calculation with RHF solver
dmet_solver_hf = DMET(mf, fragments=frags, solver='RHF')
dmet_solver_hf.kernel()

mo_coeff = frags[0].solver._solver.mo_coeff
mo_occ = frags[0].solver._solver.mo_occ
mo_coeff_occ = mo_coeff[:,mo_occ>0]
civec_from_rhf = slater_to_fci((mo_coeff_occ, mo_coeff_occ), 2, (1, 1))

proj_0 = get_proj(civec_from_rhf, civec_from_fci, 1)

driver, mpo0 = hubbard_2d_driver_block2(t, 0, lx, ly, L, scratch="./scratch-2d")  # Hartree-Fock solution
ket0 = driver.get_random_mps(tag="KET", bond_dim=300, nroots=1)
bond_dims = [300] * 4 + [600] * 4
noises = [1E-4] * 4 + [1E-5] * 4 + [0]
thrds = [1e-10] * 8

energies = driver.dmrg(mpo0, ket0, n_sweeps=20, bond_dims=bond_dims, noises=noises, thrds=thrds,
            cutoff=0, iprint=1)

ket0 = driver.adjust_mps(ket0, dot=1)[0]
pyket0 = MPSTools.from_block2(ket0) # get the HF solution!

gwf = dmrg_gwf_1site(pyket0, projectors=[proj_0 for _ in range(L)], sites=range(L), normalized=False)
proj_0 = proj_0 * (np.sqrt(gwf @ gwf) ** (-1. / L))
print("projector from DMET: ", proj_0.ravel())
gwf = dmrg_gwf_1site(pyket0, projectors=[proj_0 for _ in range(L)], sites=range(L), normalized=False)
# gwf = dmrg_gwf_1site(pyket0, projectors=[proj_0 for _ in range(L)], sites=range(L), normalized=False)
mpo = hubbard_2d_driver_block2(t, U, lx, ly, L, scratch="./scratch-2d")[1]  # 
pympo = MPOTools.from_block2(mpo.prim_mpo)
e1 = gwf @ (pympo @ gwf)
print("gwf energy from DMET projector: ", e1)


# An example of reloading the functions to optimization problem

def func(x):
    p0, pu, pd, pud = x
    p = np.array([[p0, pu], [pd, pud]])
    projs = np.array([p for _ in range(L)])
    gwf = dmrg_gwf_1site(pyket0, projs, sites=range(L), normalized=False)
    
    return gwf @ (pympo @ gwf) / (gwf @ gwf)

def func_deriv(x):
    p0, pu, pd, pud = x
    p = np.array([[p0, pu], [pd, pud]])
    projs = np.array([p for _ in range(L)])
    gwf = dmrg_gwf_1site(pyket0, projs, sites=range(L), normalized=False)
    h = gwf @ (pympo @ gwf)
    s = gwf @ gwf
    hres, sres = dmrg_gwf_deriv_1site(pyket0, gwf, pympo, sites=range(L))
    pderiv = (hres * s - h * sres).ravel() / (s ** 2)
    deriv = np.zeros(4)
    for i in range(4*L):
        deriv[i%4] += pderiv[i]
        
    return deriv

def constraint(x):
    p0, pu, pd, pud = x
    p = np.array([[p0, pu], [pd, pud]])
    projs = np.array([p for _ in range(L)])
    gwf = dmrg_gwf_1site(pyket0, projs, sites=range(L), normalized=False)
    return gwf @ gwf - 1    

x0 = proj_0.ravel()
res = minimize(func, x0, jac=func_deriv, constraints={"type": "eq", "fun": constraint})
print("projector from DMET: ", x0)
print("projector from GWF optimization: ", res.x)
print("gwf energy from DMET projector: ", e1)
print("gwf energy from optimized projector: ", res.fun)
