from dmet.linalg import EIGH

from scipy.optimize import minimize
import numpy as np


class DMETVFit:
    def __init__(self, dmet_obj, vcorr_tol=1e-5, max_cycle_vfit=200, 
                    vfit="L-BFGS-B", vfit_tol=1e-12):
        # map input vfit into minimizer recognizable
        method_map = {'L-BFGS-B': 'L-BFGS-B', 'LBFGS': 'L-BFGS-B'}
        self.dmet = dmet_obj
        # tol for considering vcorr is converged
        self.vcorr_tol = vcorr_tol
        # max cycle of redoing one-shot DMET
        self.max_cycle_vfit = max_cycle_vfit
        # optimization method to minimize DM loss
        self.vfit = vfit
        # optimization tol for minimizing DM loss
        self.vfit_tol = vfit_tol
        assert self.vcorr_tol >= 0
        assert self.vfit_tol >= 0
        assert self.vfit.upper() in method_map
        self.vfit = method_map[self.vfit]
        self.verbose = self.dmet.verbose

    def has_jac(self):
        '''
        tell me if this loss function has implemented gradient
        '''
        raise NotImplementedError("virtual function called")

    def loss_func(self):
        '''
        also set self.dm while computinng loss
        '''
        raise NotImplementedError("virtual function called")

    def make_rdm1(self, vcorr):
        '''
        make global rdm1 with vcorr
        '''
        # working in LO basis does not need to consider overlap
        fock = self.dmet.lofock + vcorr
        self.fock_eigh = EIGH(fock)
        _, mo_coeff = self.fock_eigh.kernel()
        lodm = self.dmet.mf.make_rdm1(mo_coeff, self.dmet.mf.mo_occ)
        # TODO this is kind of stupid, try to avoid this?
        return self.dmet.basis.transform_dm(lodm, 'll,aa')

    def minimize(self, loss_func, vcorr0=None):
        res = minimize(loss_func, x0=vcorr0,
            jac=self.has_jac(), method=self.vfit, tol=self.vfit_tol,
            options={'disp': self.verbose >= 3})
        if not res.success:
            from dmet.exception import DMETSCFNotConvergedError
            raise DMETSCFNotConvergedError
        return res.x.reshape(self.dmet.aodm.shape), res.fun

    def kernel(self):
        self.Edmet = self.dmet.kernel()
        self.dmet.lofock = \
            self.dmet.basis.transform_h(self.dmet.aofock, 'aa,ll')

        self.converged = False
        vcorr = np.zeros_like(self.dmet.aodm)
        for cycle in range(self.max_cycle_vfit):
            last_vcorr = vcorr
            last_E = self.Edmet
            # self.dm is also set by this function
            vcorr, self.loss = self.minimize(self.loss_func(), vcorr0=last_vcorr)
            dm = self.dm

            '''
            this is basically dmet.kernel()
            but aodm is replaced by the given dm
            '''
            dmet = self.dmet
            basis = dmet.basis

            ## make new emb basis with given aodm ##
            dmet.aodm = dm
            dmet.lodm = basis.transform_dm(dm, 'aa,ll')
            for f in dmet.fragments:
                f.basis.make_lo_eo(dmet.lodm, f, bath_tol=dmet.bath_tol)
                f.basis.make_ao_eo()

            ## make new embedding Hamiltonian ##
            dmet.aofock = dmet.aohcore + dmet.mf.get_veff(dm=dm)
            dmet.make_h2()
            dmet.make_h1()
            ## solve impurity problem and comptue energy ##
            dmet.solve_impurity()
            dmet.Edmet_tot = dmet.compute_energy() 
            self.Edmet = dmet.Edmet_tot + dmet.mol.energy_nuc()

            self.dmet.lofock = \
                self.dmet.basis.transform_h(self.dmet.aofock, 'aa,ll')

            norm_dvcorr = np.linalg.norm(vcorr-last_vcorr)
            self.dmet.log.info('cycle= %d E= %.15g  delta_E= %4.3g |dvcorr|= %4.3g',
                        cycle+1, self.Edmet, self.Edmet-last_E, norm_dvcorr)
            if norm_dvcorr < self.vcorr_tol:
                self.vcorr = vcorr
                self.converged = True
                break

        if not self.converged:
            from dmet.exception import DMETSCFNotConvergedError
            raise DMETSCFNotConvergedError

        return self.Edmet