from dmet.mf_fitting.vcorr.dmet_vfit import DMETVFit

import numpy as np

class DMETVFit_ImpL2(DMETVFit):
    def has_jac(self):
        return True

    def loss_func(self):
        def l2_loss(vcorr):
            # NOTE this also sets self.fock_eigh
            self.dm = self.make_rdm1(vcorr.reshape(self.dmet.aodm.shape))

            l2 = 0
            b = 0
            for f in self.dmet.fragments:
                dm_proj = f.basis.transform_dm(self.dm, 'aa,ee')
                ddm = (dm_proj - f.r1)[:f.nimp, :f.nimp]
                l2 += np.sum(ddm**2)
                # d(...)^2 / d r1 => *2
                temp = 2 * ddm @ f.basis.Ceo2lo[:f.nimp]
                temp = temp.T @ f.basis.Ceo2lo[:f.nimp]
                #b += (temp+temp.T) @ self.fock_eigh.u * self.dmet.mf.mo_occ
                b += 2 * temp @ self.fock_eigh.u * self.dmet.mf.mo_occ
            g = self.fock_eigh.gradient(b, contract='pre')[0]
            return l2, (g+g.T).ravel() / 2
        return l2_loss
