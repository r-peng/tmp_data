from dmet.basis import Basis
from dmet import linalg

import numpy as np
from pyscf.lo import iao, vec_lowdin

class IAOBasis(Basis):
    def make_ao_lo(self, dmet):
        mf = dmet.mf
        if hasattr(dmet, 'minao'):
            self.minao = dmet.minao
        else:
            self.minao = 'minao'
        ovlp = mf.get_ovlp()
        self.pmol = iao.reference_mol(dmet.mol, self.minao)

        C_val = iao.iao(dmet.mol, mf.mo_coeff[:,mf.mo_occ>0], minao=self.minao)
        C_val = vec_lowdin(C_val, ovlp)

        # follow the same procedure in libdmet to get PAO
        B1_labels = mf.mol.ao_labels()
        B2_labels = self.pmol.ao_labels()
        virt_idx = [idx for idx, label in enumerate(B1_labels)\
            if (not label in B2_labels)]
        assert len(B2_labels) + len(virt_idx) == len(B1_labels)
        CCdS = C_val @ C_val.T @ ovlp
        C_virt = (np.eye(len(B1_labels)) - CCdS)[:, virt_idx]
        C_virt = vec_lowdin(C_virt, ovlp)

        Cao2lo = np.hstack([C_val, C_virt])
        Basis.make_ao_lo(self, ovlp, Cao2lo)