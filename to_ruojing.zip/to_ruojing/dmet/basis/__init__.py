from dmet.basis.basis import Basis
from dmet.basis.ubasis import UBasis
from dmet.basis.lowdin import LowdinBasis, ULowdinBasis
from dmet.basis.iao import IAOBasis

lo_dict = {"Lowdin": LowdinBasis, 'uLowdin': ULowdinBasis, 'IAO': IAOBasis}