'''
basis for unrestricted
'''

from dmet.basis.basis import Basis, Literal1
from pyscf.lib import einsum
from pyscf import ao2mo

import numpy as np

class UBasis:
    def __init__(self):
        self.Cao2mo = None
        self.Cmo2ao = None
        self.Cao2lo = None
        self.Clo2ao = None
        self.Clo2eo = None
        self.Cao2eo = None
        self.Ceo2ao = None
        self.Ceo2lo = None
        self.bath_mask = None
        self.ovlp = None
        self.svd = None

    def make_ao_lo(self, ovlp, Cao2lo=None):
        '''
        make basis transformation between AO and LO
        '''
        if Cao2lo is None:
            raise Exception("virtual function called")
        else:
            self.Cao2lo = Cao2lo
            self.Clo2ao = einsum('sui,uv->siv', Cao2lo, ovlp)
            self.ovlp = ovlp

    def make_ao_mo(self, Cao2mo, ovlp=None):
        '''
        make basis transformation between AO and MO
        '''
        if ovlp is None:
            ovlp = self.ovlp
        else:
            self.ovlp = ovlp
        self.Cao2mo = Cao2mo
        self.Cmo2ao = einsum('xui,uv->xiv', Cao2mo, ovlp)

    def make_lo_eo(self, glob_r1, frag, bath_tol=-1):
        assert glob_r1.ndim == 3
        assert len(glob_r1) == 2
        svd = list()
        Clo2eo = list()
        Ceo2lo = list()
        bath_mask = list()
        for r1 in glob_r1:
            Basis.make_lo_eo(self, r1, frag, bath_tol=bath_tol)
            svd.append(self.svd)
            Clo2eo.append(self.Clo2eo)
            Ceo2lo.append(self.Ceo2lo)
            bath_mask.append(self.bath_mask)
        self.svd = svd
        self.Clo2eo = np.asarray(Clo2eo)
        self.Ceo2lo = np.asarray(Ceo2lo)
        self.bath_mask = bath_mask

    def make_ao_eo(self, dmet=None, glob_r1=None, frag=None, bath_tol=-1):
        if self.Cao2lo is None:
            self.make_ao_lo(dmet)
        if self.Clo2eo is None:
            self.make_lo_eo(glob_r1, frag, bath_tol=bath_tol)
        self.Cao2eo = einsum('xui,xip->xup', self.Cao2lo, self.Clo2eo)
        self.Ceo2ao = einsum('xup,uv->xpv', self.Cao2eo, self.ovlp)

    def transform_h(self, h, string):
        if h.ndim == 2:
            h = np.asarray([h] * 2)
        h_dict = \
            {'AE': self.Cao2eo, 'AL': self.Cao2lo, 'EA': self.Ceo2ao, \
            'LE': self.Clo2eo, 'AM': self.Cao2mo, 'MA': self.Cmo2ao, \
            'EL': self.Ceo2lo, \
            'AA': Literal1, 'LL': Literal1, 'EE': Literal1}
        rep1, rep2 = string.upper().split(',')
        assert len(rep1) == len(rep2) == 2
        try:
            b1 = h_dict[rep1[0]+rep2[0]]
            b2 = h_dict[rep1[1]+rep2[1]]
        except KeyError:
            raise NotImplementedError
        if b1 is not Literal1 and b2 is not Literal1:
            return einsum('xui,xuv,xvj->xij', b1, h, b2)
        elif b1 is not Literal1:
            return einsum('xui,xuv->xiv', b1, h)
        elif b2 is not Literal1:
            return einsum('xuv,xvj->xuj', h, b2)
        else:
            return h

    def transform_rdm1(self, r1, string):
        assert r1.ndim == 3
        dm_dict = \
            {'AE': self.Ceo2ao, 'AL': self.Clo2ao, \
            'EA': self.Cao2eo, 'EL': self.Clo2eo, \
            'AM': self.Cmo2ao, 'MA': self.Cao2mo, \
            'LA': self.Cao2lo, 'LE': self.Ceo2lo, \
            'AA': Literal1, 'LL': Literal1, 'EE': Literal1}
        rep1, rep2 = string.upper().split(',')
        assert len(rep1) == len(rep2) == 2
        try:
            b1 = dm_dict[rep1[0]+rep2[0]]
            b2 = dm_dict[rep1[1]+rep2[1]]
        except KeyError:
            raise NotImplementedError
        if b1 is not Literal1 and b2 is not Literal1:
            return einsum('xiu,xuv,xjv->xij', b1, r1, b2)
        elif b1 is not Literal1:
            return einsum('xiu,xuv->xiv', b1, r1)
        elif b2 is not Literal1:
            return einsum('xuv,xjv->xuj', r1, b2)
        else:
            return r1
    
    transform_dm = transform_rdm1

    def transform_rdm2(self, rdm2, string):
        '''
        transform r2_aa, r2_ab, r2_bb using C_aa, C_bb
        '''
        assert rdm2.ndim == 5
        dm_dict = \
            {'AE': self.Ceo2ao, 'AL': self.Clo2ao, \
            'EA': self.Cao2eo, 'EL': self.Clo2eo, \
            'AM': self.Cmo2ao, 'MA': self.Cao2mo, \
            'AA': Literal1, 'LL': Literal1, 'EE': Literal1}
        rep1, rep2 = string.upper().split(',')
        assert len(rep1) == len(rep2) == 4
        for ib, (r1, r2) in enumerate(zip(rep1,rep2)):
            try:
                b_ =dm_dict[r1+r2]
            except KeyError:
                raise NotImplementedError
            if b_ is Literal1:
                pass
            else:
                if ib == 0:
                    rdm2[0] = einsum('ijkl,ai->ajkl', rdm2[0], b_[0])
                    rdm2[1] = einsum('ijkl,ai->ajkl', rdm2[1], b_[0])
                    rdm2[2] = einsum('ijkl,ai->ajkl', rdm2[2], b_[1])
                elif ib == 1:
                    rdm2[0] = einsum('ijkl,aj->iakl', rdm2[0], b_[0])
                    rdm2[1] = einsum('ijkl,aj->iakl', rdm2[1], b_[0])
                    rdm2[2] = einsum('ijkl,aj->iakl', rdm2[2], b_[1])
                elif ib == 2:
                    rdm2[0] = einsum('ijkl,ak->ijal', rdm2[0], b_[0])
                    rdm2[1] = einsum('ijkl,ak->ijal', rdm2[1], b_[1])
                    rdm2[2] = einsum('ijkl,ak->ijal', rdm2[2], b_[1])
                else:
                    rdm2[0] = einsum('ijkl,al->ijka', rdm2[0], b_[0])
                    rdm2[1] = einsum('ijkl,al->ijka', rdm2[1], b_[1])
                    rdm2[2] = einsum('ijkl,al->ijka', rdm2[2], b_[1])
        return rdm2

    def transform_eri(self, eri, string, norbs=None, contract_order=None):
        '''
        return h2_aa h2_ab h2_bb
        '''
        eri_dict = \
            {'AE': self.Cao2eo, 'AL': self.Cao2lo, \
            'LE': self.Clo2eo, 'AM': self.Cao2mo, 'MA': self.Cmo2ao, \
            'AA': Literal1, 'LL': Literal1, 'EE': Literal1}
        rep1, rep2 = string.upper().split(',')
        assert len(rep1) == len(rep2) == 4
        try:
            len(norbs)
        except TypeError:
            norbs = [norbs]*4
        # let's call ao2mo for simplicity at this moment
        b = list()
        for norb, r1, r2 in zip(norbs, rep1,rep2):
            try:
                b_ = eri_dict[r1+r2]
            except KeyError:
                raise NotImplementedError
            if b_ is Literal1:
                b_ = [np.eye(norb)]*2
            b.append(b_)
        if eri.ndim == 5 and len(eri) == 3:
            return np.array([
            ao2mo.general(eri[0], [b[0][0],b[1][0],b[2][0],b[3][0]], compact=False),
            ao2mo.general(eri[1], [b[0][0],b[1][0],b[2][1],b[3][1]], compact=False),
            ao2mo.general(eri[2], [b[0][1],b[1][1],b[2][1],b[3][1]], compact=False) ])
        else:
            return np.array([
            ao2mo.general(eri, [b[0][0],b[1][0],b[2][0],b[3][0]], compact=False),
            ao2mo.general(eri, [b[0][0],b[1][0],b[2][1],b[3][1]], compact=False),
            ao2mo.general(eri, [b[0][1],b[1][1],b[2][1],b[3][1]], compact=False) ])
