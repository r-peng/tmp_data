from dmet.single_imp.dmet import SingleImpDMET
from dmet.df.gdf import GDF_DMET

class GDF_SingleImpDMET(SingleImpDMET, GDF_DMET):
    __init__ = GDF_DMET.__init__
    transform_eri = GDF_DMET.transform_eri
    make_h2 = GDF_DMET.make_h2

    def nuc_grad_method(self, **kwargs):
        from dmet.grad.df.single_imp.gdf import GDF_DMETGradients
        return GDF_DMETGradients(self, **kwargs)