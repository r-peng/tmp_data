from dmet.df.gdf import *

def density_fit(dmet_obj, df="GDF"):
    return dmet_obj.density_fit(df=df)
