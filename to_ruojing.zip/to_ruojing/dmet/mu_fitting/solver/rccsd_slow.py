from dmet.mu_fitting.solver.post_hf import PostHFMuResponse
import numpy as np

class ARCCSDMuResponse(PostHFMuResponse):
    def check_consistency(self):
        from dmet.solver.rccsd_slow import ARCCSD
        assert type(self.base) is ARCCSD