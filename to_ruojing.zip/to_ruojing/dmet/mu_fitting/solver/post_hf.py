from dmet.mu_fitting.solver.solver import SolverMuResponse
import numpy as np
from dmet.exception import SolverNotConvergedError

class PostHFMuResponse(SolverMuResponse):
    def __init__(self, base, nimp, conv_tol=0.0001, max_cycle=20, verbose=0):
        super().__init__(base, nimp, conv_tol, max_cycle, verbose)
        # TODO maybe pass in this solvergrad to cache it since it may be 
        # reused when computing nuclear gradient?
        self.solvergrad = self.base.gradient()

    def dN_dc(self):
        '''
        (dN / dU, dN / dc)
        '''
        # dN / d c_corr
        dNdc = self.dN_dc_corr()
        # dN / d c_mf
        dNdU = self.dN_dc_mf()
        return np.hstack([dNdU.ravel(), dNdc.ravel()])

    def dot_lambda(self):
        '''
        (zpq dFpq / dmu, lP dXP / dmu)
        '''
        if hasattr(self, 'M'):
            return self.M

        self.zdMdmu = self.dot_lambda_mf()
        self.ldMdmu = self.dot_lambda_corr()

        def ldMdmu(l):
            z = l[:self.mf_lambda_size()]
            lcorr = l[self.mf_lambda_size():]
            return self.zdMdmu(z) + self.ldMdmu(lcorr)

        self.M = ldMdmu
        return self.M

    def kernel(self, h1, h2):
        '''
        TODO this block can be put into solver.kernel actually?
        '''
        from scipy.sparse.linalg import LinearOperator, gmres
        ldMdc = self.solvergrad.dot_lambda(h1, h2)
        # TODO conv_tol and max_cycle
        l, stat = gmres(
            LinearOperator([self.solvergrad.lambda_size()]*2, ldMdc, dtype=np.float64),
            self.dN_dc()
            )
        if stat != 0:
            raise SolverNotConvergedError("PostHF response not converged")
        return -self.dot_lambda()(l)

    '''
    To be overwritten by child
    '''
    def dN_dc_corr(self):
        '''
        this is just a slow and lazy way of computing dN_dc
        could be overwritten by the child class
        '''
        norb = self.base.mf.mo_coeff.shape[0]

        fake_h1 = np.zeros((norb,norb))
        fake_h1[(range(self.nimp),range(self.nimp))] = 1
        fake_h2 = np.zeros([norb]*4)
        return self.solvergrad.dE_dc_corr(fake_h1, fake_h2)

    def dot_lambda_corr(self):
        '''
        this is just a slow and lazy way of computing l dMcorr / dmu
        could be overwritten by the child class
        '''
        def ldMdmu(lcorr):
            # - lP d XP / d hij
            r1bar, _ = self.solvergrad.make_rdm12_corr(lcorr, ao_repre=True)
            return np.trace(r1bar[:self.nimp,:self.nimp])
        return ldMdmu

    '''
    Mean-field related
    '''
    def mf_lambda_size(self):
        norb = self.base.mf.mo_coeff.shape[0]
        return (norb * (norb-1)) // 2

    def dN_dc_mf(self):
        '''
        dN / d Upq (p > q)
        '''
        mf = self.base.mf
        rqu = self.base.basis.transform_rdm1(
            self.base.r1, 'aa,ma')
        xpq = (rqu[:,:self.nimp] @ mf.mo_coeff[:self.nimp]).T
        xpq = 2 * (xpq - xpq.T)
        tril_idx = np.tril_indices_from(xpq, k=-1)
        return xpq[tril_idx]

    def dot_lambda_mf(self):
        '''
        zpq d Fpq / d mu (p > q)
        '''
        mf = self.base.mf
        hpq = -mf.mo_coeff[:self.nimp].T @ mf.mo_coeff[:self.nimp]
        tril_idx = np.tril_indices_from(hpq, k=-1)
        hpq = hpq[tril_idx].ravel()
        def zdMdmu(z):
            return z @ hpq
        return zdMdmu