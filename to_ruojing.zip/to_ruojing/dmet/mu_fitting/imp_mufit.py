"""
imp_mufit.py
in the approximate tangent-space situation,
we may need the mu-fit specific of the impurities.
"""

from dmet import Fragment, DMET
import numpy as np
from pyscf.lib import logger
from dmet.exception import *
import sys

class FragmentMufit(Fragment):
    """
    frag: a Fragment object that that the mu-fitting fragment inherits;
    nelec_targ: the supposed number of electrons for this fragment
    """
    def __init__(self, frag:Fragment, nelec_targ, mu0=0, 
                           nelec_tol=5e-6, max_cycle_mufit=50,
                           stepsize=0.02):
        self.__dict__.update(frag.__dict__)
        self.mu = mu0
        self.nelec_tol = nelec_tol
        self.max_cycle_mufit = max_cycle_mufit
        self.nelec_targ = nelec_targ
        assert self.nelec_tol >= 0
        # for secant update
        self.last_mu = None
        self.last_nelec = None
        self.stepsize = stepsize
        # for logger
        self.verbose = logger.INFO
        self.stdout = sys.stdout

    def nelectron_frag(self):
        # the electron number of the fragment
        r1 = np.array(self.r1)
        if r1.ndim == 3:    # unrestricted situ
            r1a, r1b = r1
            r1 = r1a + r1b
        return np.trace(r1[:self.nimp,:self.nimp])
    
    def get_dmu(self, nelec_targ=None): # secant
        nelec = self.nelectron_frag()
        if nelec_targ is None: nelec_targ = self.nelec_targ
        dN = nelec - nelec_targ
        logger.note(self, f"Mu Fitting Iter {self.mufit_iter}:")
        logger.note(self, f"   nelec_targ = {nelec_targ} nelec = {nelec} dNelec = {dN}")
        if abs(dN) < self.nelec_tol:
            logger.note(self, f"    nelec_tol satisfied! ")
            return 0
        else:
            if self.last_mu is None:
                if dN < 0:
                    dmu = abs(self.stepsize)
                else:
                    dmu = -abs(self.stepsize)
            else:
                dNdmu = (nelec - self.last_nelec) / (self.mu - self.last_mu)
                dmu = -dN / dNdmu
            
            self.last_mu = self.mu
            self.last_nelec = nelec
            return dmu


class FragMufitDMET(DMET):
    def __init__(self, dmet_obj, nelec_targs,
                 nelec_tol=1e-4, max_cycle_mufit=50, stepsize=1E-2):
        self.__dict__.update(dmet_obj.__dict__)

        for ifrag, f in enumerate(self.fragments):
            self.fragments[ifrag] = FragmentMufit(f, nelec_targs[ifrag],
                              mu0=1e-2, nelec_tol=nelec_tol,
                              max_cycle_mufit=max_cycle_mufit,
                              stepsize=stepsize)

    def make_h1(self):
        DMET.make_h1(self)
        for f in self.fragments:
            if len(f.h1.shape) == 2:
                f.h1[(range(f.nimp), range(f.nimp))] -= f.mu
            else:
                f.h1[(0, range(f.nimp), range(f.nimp))] -= f.mu
                f.h1[(1, range(f.nimp), range(f.nimp))] -= f.mu

    def solve_impurity(self, **kwargs):
        mf = self.mf
        for ifrag, f in enumerate(self.fragments):
            ## Solve impurity problem ##
            f.mufit_iter = 0
            while True: # write the cycle within each frag
                
                if len(f.dm_proj.shape) == 2:   # rdmet
                    f.solver.nelec = int(round(np.trace(f.dm_proj)/2)) * 2
                elif len(f.dm_proj.shape) == 3: # udmet
                    # print(einsum('xii->x', f.dm_proj))
                    f.solver.nelec = np.array(np.round(np.einsum('xii->x', f.dm_proj)), dtype=int)
                f.Esolv, f.r1, f.r2 = f.solver.kernel(f.h1, f.h2, \
                dm0=f.dm_proj, cache4grad=self.cache4grad, **kwargs)

                dmu = f.get_dmu()
                if dmu == 0:
                    break

                f.mu += dmu
                if len(f.h1.shape) == 2:
                    f.h1[(range(f.nimp), range(f.nimp))] -= f.mu
                else:
                    f.h1[(0, range(f.nimp), range(f.nimp))] -= f.mu
                    f.h1[(1, range(f.nimp), range(f.nimp))] -= f.mu
                # f.h1[(range(f.nimp), range(f.nimp))] -= dmu

                f.mufit_iter += 1
                if f.mufit_iter > f.max_cycle_mufit:
                    logger.warn(f, "Mu not converged.")
                    break
                    # raise MuNotConvergedError()
