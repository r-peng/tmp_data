from dmet.solver import Solver
from dmet.solver.uhf import UHF
from dmet.basis import UBasis

class PostHF(Solver):
    def hf_kernel(self, h1e, eri, **kwargs):
        if self.nelec is None:
            self.nelec = h1e.shape[1:] # restricted and half-filling

        # HF
        if 'hf_conv_tol' in kwargs:
            hf_conv_tol = kwargs.pop('hf_conv_tol')
        elif self.conv_tol is not None:
            hf_conv_tol = 1e-2 * self.conv_tol 
        else:
            hf_conv_tol = None
        if 'hf_max_cycle' in kwargs:
            hf_max_cycle = kwargs.pop('hf_max_cycle')
        elif 'max_cycle' in kwargs:
            hf_max_cycle = kwargs.pop('max_cycle')
        elif self.max_cycle is not None:
            hf_max_cycle = self.max_cycle
        else:
            hf_max_cycle = None

        uhf = UHF(nelec=self.nelec, verbose=self.verbose, 
                conv_tol=hf_conv_tol, max_cycle=hf_max_cycle)
        self.uhf = uhf
        self.Ehf = uhf.kernel(h1e, eri, **kwargs)[0]
        self.mf = uhf._solver

        # define AO to MO basis
        mf = uhf._solver
        self.basis = UBasis()
        self.basis.make_ao_mo(mf.mo_coeff, mf.get_ovlp(mf.mol))