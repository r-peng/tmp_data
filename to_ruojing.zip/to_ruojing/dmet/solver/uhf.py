from dmet.solver import Solver
from dmet.exception import SolverNotConvergedError

from pyscf import scf
from pyscf.lib import einsum
from pyscf.gto import Mole

import numpy as np

class UHF(Solver):
    '''
    restricted HF solver
    '''

    def kernel(self, h1e, eri, dm0=None, **kwargs):
        if self.nelec is None:
            nelec = h1e.shape[1:] #  assume half-filling
        else:
            nelec = self.nelec
        norb = h1e.shape[1]

        mol = Mole()
        mol.nelectron = sum(self.nelec)
        mol.nelec = self.nelec
        if self.verbose is not None:
            mol.verbose = self.verbose
        mol.incore_anyway = True
        mol.build()

        # use a derived class to avoid overwritten warnings
        class _UHF(scf.uhf.UHF):
            get_hcore = lambda *args: h1e
            get_ovlp = lambda *args: np.eye(norb)
            def get_jk(self, mol=None, dm=None, hermi=1):
                assert hermi == 1
                if mol is None:
                    mol = self.mol
                if dm is None:
                    dm = self.make_rdm1()
                eri_aa, eri_ab, eri_bb = self._eri
                dm_a, dm_b = dm
                vjaa = einsum('ijkl,lk->ij', eri_aa, dm_a)
                vjab = einsum('ijkl,lk->ij', eri_ab, dm_b)
                vjbb = einsum('ijkl,lk->ij', eri_bb, dm_b)
                vjba = einsum('ijkl,ji->kl', eri_ab, dm_a)
                vka  = einsum('ilkj,lk->ij', eri_aa, dm_a)
                vkb  = einsum('ilkj,lk->ij', eri_bb, dm_b)
                return np.asarray(((vjaa, vjbb), (vjab, vjba))), np.asarray([vka, vkb])
        mf = _UHF(mol)
        mf._eri = eri
        if self.conv_tol is not None:
            mf.conv_tol = self.conv_tol
        if self.max_cycle is not None:
            mf.max_cycle = self.max_cycle
        if dm0 is None:
            mf.init_guess = '1e'
            self.E = mf.kernel(dump_chk=False) # not dump check to avoid warn
        else:
            self.E = mf.kernel(dm0=dm0, dump_chk=False)
        self._solver = mf
        if not mf.converged:
            raise SolverNotConvergedError()

        self.r1 = mf.make_rdm1()
        r2_aa  = einsum('uv,wx->uvwx', self.r1[0], self.r1[0])
        r2_aa -= einsum('ux,vw->uvwx', self.r1[0], self.r1[0])
        r2_bb  = einsum('uv,wx->uvwx', self.r1[1], self.r1[1])
        r2_bb -= einsum('ux,vw->uvwx', self.r1[1], self.r1[1])
        r2_ab  = einsum('uv,wx->uvwx', self.r1[0], self.r1[1])
        r2_ab += einsum('uv,wx->uvwx', self.r1[1], self.r1[0])
        self.r2 = np.asarray([r2_aa, r2_ab/2, r2_bb])

        return self.E, self.r1, self.r2

    def gradient(self, **kwargs):
        from dmet.grad.solver.rhf import RHFGradients
        return RHFGradients(self, **kwargs)

    def mu_response(self, nimp, **kwargs):
        from dmet.mu_fitting.solver.rhf import RHFMuResponse
        return RHFMuResponse(self, nimp, **kwargs)
