from dmet.solver.solver import Solver
from dmet.solver import fci, rhf, fci_mo, rccsd, rcisd, rccsd_t, rccsd_slow, ufci, ufci_mo
try: 
        from dmet.solver import dmrg, udmrg
except ModuleNotFoundError:
        class Fake:
                pass
        dmrg = Fake(); udmrg = Fake()
        dmrg.DMRG = None; udmrg.UDMRG = None

solver_dict = {"FCI": fci.FCI, "RHF": rhf.RHF, 
        "FCIMO": fci_mo.FCIMO, "FCI_MO": fci_mo.FCIMO,
        "RCCSD": rccsd.RCCSD, 
        "RCCSD_APPROX": rccsd.ARCCSD,
        "APPROX_RCCSD": rccsd.ARCCSD, 
        "ARCCSD": rccsd.ARCCSD, 
        "RCCSD*": rccsd.ARCCSD, 
        "ARCCSD_SLOW": rccsd_slow.ARCCSD, 
        "RCISD": rcisd.RCISD,
        "RCCSD_T": rccsd_t.RCCSD_T, "RCCSD(T)": rccsd_t.RCCSD_T,
        "DMRG": dmrg.DMRG, "UDMRG": udmrg.UDMRG,
        "UFCI": ufci.UFCI, "UFCI_MO": ufci_mo.FCIMO}
