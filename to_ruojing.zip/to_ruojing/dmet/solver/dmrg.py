"""
DMRG Solver for DMET
Added by Shuoxue Li
"""

from dmet.solver import Solver
from pyblock2.driver.core import DMRGDriver, SymmetryTypes
import numpy as np
from pyscf.lib import logger 
import sys

class DMRG(Solver):

    def __init__(self, nelec=None, verbose=None, conv_tol=None, max_cycle=None, 
                scratch='./tmp', n_threads=4, 
                 symm_type=SymmetryTypes.SZ,
                 bond_dim=500,
                 mpstag="GS",
                 stack_mem=int(1*1024**3)
                 ):

        Solver.__init__(self, nelec, verbose, conv_tol, max_cycle)

        # Change: do not create solver during initialization

        self.dmrg_solver_arg_dicts = {
            "scratch": scratch,
            "n_threads": n_threads,
            "stack_mem": stack_mem,
            "n_threads": n_threads,
            "symm_type": SymmetryTypes.SZ
        }

        self.bond_dim = bond_dim
        self.mpstag = mpstag
        self.dmrg_symmtype = symm_type

        self.stdout = sys.stdout

    def make_solver(self, n_sites=None, dnelec_emb=0, dspin_emb=0):
        # build solver and initialize it
        # _solver: the DMRGDriver class
        self._solver = DMRGDriver(**self.dmrg_solver_arg_dicts)

        if isinstance(self.nelec, int):
            nelec = self.nelec
            spin = 0
            if n_sites is None: 
                n_sites = nelec
        else:
            nelec = self.nelec[0] + self.nelec[1]
            spin = self.nelec[0] - self.nelec[1]
            if n_sites is None:
                n_sites = min(self.nelec) * 2

        self.spin = spin
        self.norb = n_sites
        # print('In make_solver: n_sites = ', n_sites)
        self.nelectron = nelec
        # logger.note(self, f"DMRG solver: nsites = {nelec}, nelec = {nelec + dnelec_emb}, spin={spin + dspin_emb}")
        self._solver.initialize_system(n_sites=self.norb, n_elec=self.nelectron+dnelec_emb, spin=self.spin+dspin_emb)
        # self.norb = n_sites
        
    def delete_solver(self):    # delete the solver and release the disk
        del self._solver

    def make_rdm12s(self):
        # make_rdm12s: get the dm1 and dm2 (specific for each spin)
        if self.dmrg_symmtype in [SymmetryTypes.SZ, (SymmetryTypes.SZ | SymmetryTypes.CPX)]:
            dm1a, dm1b = self._solver.get_1pdm(self.dmrg_ket)
            # logger.note(self, f"dm1a.shape = {dm1a.shape}")
            dm2aa, dm2ab, dm2bb = self._solver.get_2pdm(self.dmrg_ket)
            dm2aa = dm2aa.transpose(0,3,1,2)
            dm2ab = dm2ab.transpose(0,3,1,2)
            dm2bb = dm2bb.transpose(0,3,1,2)

            dm1 = (dm1a, dm1b)
            dm2 = (dm2aa, dm2ab, dm2bb) # dm2aa + 2. * dm2ab + dm2bb

        else:
            raise NotImplementedError("Symmetry other than SZ has not been implemented yet.")

        return (dm1, dm2)

    def make_rdm12(self):
        dm1_pack, dm2_pack = self.make_rdm12s()
        dm1 = dm1_pack[0] + dm1_pack[1]
        dm2 = dm2_pack[0] + 2. * dm2_pack[1] + dm2_pack[2]
        # logger.note(self, f"dm1.shape = {dm1.shape}")
        return (dm1, dm2)

    def make_rdm1(self, custom_ket_tag="PDM-KET@TMP", custom_bra_tag="PDM-BRA@TMP"):
        if self.dmrg_symmtype == SymmetryTypes.SZ:
            dm1a, dm1b = self._solver.get_1pdm(self.dmrg_ket)
            dm1 = dm1a + dm1b

        else:
            raise NotImplementedError("Symmetry other than SZ has not been implemented yet.")
        
        return dm1        

    def kernel(self, h1e, eri, dm0=None, cache4grad=None, **kwargs):
        
        self.make_solver(n_sites=h1e.shape[-1], **kwargs)
        # logger.note(self, f"h1e.n = {len(h1e)}, eri.n = {len(eri)}")

        mpo = self._solver.get_qc_mpo(h1e.real, eri.real, ecore=0, iprint=self.verbose//4)

        # The initial bond dimension, accelerating convergence
        bdinit = min(400, self.bond_dim // 2)
        
        logger.note(self, f"Processing DMRG Solver, tag = {self.mpstag} ...")

        ket = self._solver.get_random_mps(tag=self.mpstag, bond_dim=bdinit, nroots=1)
        
        bond_dims =  [bdinit] * 4 + [self.bond_dim] * 4
        noises = [1e-4] * 4 + [1e-5] * 4 + [0]
        thrds = [self.conv_tol]
        self.E = self._solver.dmrg(mpo, ket, n_sweeps=self.max_cycle,
                        bond_dims=bond_dims, noises=noises,
                        thrds=thrds, iprint=self.verbose//4)

        self.dmrg_ket = ket
        # self.norb = self.nelec
        self.r1, self.r2 = self.make_rdm12()

        # delete the solver immediately after the computation
        self.delete_solver()

        return self.E, self.r1, self.r2
