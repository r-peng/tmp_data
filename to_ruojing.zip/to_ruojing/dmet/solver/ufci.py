from dmet.solver import Solver
from dmet.exception import SolverNotConvergedError
from pyscf.fci import direct_uhf

class UFCI(Solver):
    '''
    FCI without alpha/beta degeneracy
    '''
    def __init__(self, **kwargs):
        Solver.__init__(self, **kwargs)
        self._solver = direct_uhf.FCI()
        if self.verbose is not None:
            self._solver.verbose = self.verbose
        if self.conv_tol is not None:
            self._solver.conv_tol = self.conv_tol
        if self.max_cycle is not None:
            self._solver.max_cycle = self.max_cycle

    @property
    def solution(self):
        return self.c

    def make_rdm12(self):
        return self._solver.make_rdm12s(self.c, self.norb, self.nelec)

    def kernel(self, h1e, eri, dm0=None, **kwargs):
        if self.nelec is None:
            nelec = h1e.shape[1:] // 2 # assume half-filling
        else:
            nelec = self.nelec
        norb  = h1e.shape[1]
        if hasattr(self, 'c'):
            c0 = self.c[0][0]
        else:
            c0 = 0
        self.E, self.c = \
            self._solver.kernel(h1e, eri, norb, nelec)
        if not self._solver.converged:
            raise SolverNotConvergedError()

        # TODO TBH this is kind of ugly
        if c0 * self.c[0][0] > 0:
            self.change_sign = False
        else:
            self.change_sign = True

        self.nelec = nelec
        self.norb = norb
        self.r1, self.r2 = self.make_rdm12()

        return self.E, self.r1, self.r2
