'''
TODO
(1) better use CC eris
(2) better way of computing -l_P <P | e^-T E_pq E_rs e^T |0>
(3) avoid *e_ai and *e_ai e_bj
'''
from dmet.grad.solver.post_hf import PostHFGradients

import numpy as np
from pyscf import cc, lib
from pyscf.cc import uccsd_lambda

class ARCCSDGradients(PostHFGradients):
    def check_consistency(self):
        super().check_consistency()
        from dmet.solver.rccsd_slow import ARCCSD
        assert type(self.base) is ARCCSD

    def ov_size(self):
        occ = self.base.mf.mo_occ > 0
        vir = self.base.mf.mo_occ == 0
        nocc = sum(occ)
        nvir = sum(vir)
        return nocc * nvir

    def corr_lambda_size(self):
        ov_size = self.ov_size()
        assert ov_size*(3*ov_size+2) == np.size(self.base.t1) + np.size(self.base.t2)
        return ov_size*(3*ov_size+2)

    def dE_dc_corr(self, h1pp, h2w, same_h=False):
        '''
        return d Lcc(h1pp, h2w) / d t_Q_symm
        when I say d/d t_ijab_symm, I mean
           d/d t_ijab + d/d t_jiba - d/d t_jiab - d/d t_ijba 
           for t2aa and t2bb but not others
        '''
        occ = self.base.mf.mo_occ > 0
        vir = self.base.mf.mo_occ == 0

        t1 = self.base.t1
        t2 = self.base.t2

        # build a fake mf
        uhf = self.base.mf.to_uhf()
        uhf.get_hcore = lambda *args: h1pp
        uhf.get_ovlp = lambda *args: np.eye(self.base.norb)
        uhf._eri = h2w

        # build a fake CC
        _fcc = cc.uccsd.UCCSD(uhf)
        _fcc.t1 = t1
        _fcc.t2 = t2
        eris = _fcc.ao2mo()

        eia_a = lib.direct_sum('i-a->ia', eris.mo_energy[0][occ], eris.mo_energy[0][vir])
        eia_b = lib.direct_sum('i-a->ia', eris.mo_energy[1][occ], eris.mo_energy[1][vir])
        t1n, t2n = _fcc.update_amps(t1, t2, eris)
        l1n, l2n = uccsd_lambda.update_lambda(_fcc, t1, t2, t1, t2, eris, \
            uccsd_lambda.make_intermediates(_fcc, t1, t2, eris))

        # <Q | e^-T Hw e^T |0>
        dLdt1a_ = (t1n[0] - t1[0]) * eia_a
        dLdt1b_ = (t1n[1] - t1[1]) * eia_b
        dLdt2aa = (t2n[0] - t2[0]) # * lib.direct_sum('ia,jb->ijab', eia_a, eia_a)
        dLdt2ab = (t2n[1] - t2[1]) # * lib.direct_sum('ia,jb->ijab', eia_a, eia_b)
        dLdt2bb = (t2n[2] - t2[2]) # * lib.direct_sum('ia,jb->ijab', eia_b, eia_b)
        
        # t_P <P - Q |  e^-T Hw e^T | 0>
        dLdt1a = dLdt1a_ - np.einsum('ijab,jb->ia', t2[0], dLdt1a_)
        dLdt1a -=  np.einsum('ijab,jb->ia', t2[1], dLdt1b_)
        dLdt1b = dLdt1b_ - np.einsum('ijab,jb->ia', t2[2], dLdt1b_)
        dLdt1b -=  np.einsum('ijab,jb->ia', t2[1], dLdt1a_)

        # (<0| + t_P <P|) e^-T Hw e^T | Q>
        dLdt1a += (l1n[0] - t1[0]) * eia_a
        dLdt1b += (l1n[1] - t1[1]) * eia_b
        dLdt2aa += (l2n[0] - t2[0]) # * lib.direct_sum('ia,jb->ijab', eia_a, eia_a)
        dLdt2ab += (l2n[1] - t2[1]) # * lib.direct_sum('ia,jb->ijab', eia_a, eia_b)
        dLdt2bb += (l2n[2] - t2[2]) # * lib.direct_sum('ia,jb->ijab', eia_b, eia_b)

        dLdt2aa *= lib.direct_sum('ia,jb->ijab', eia_a, eia_a)
        dLdt2ab *= lib.direct_sum('ia,jb->ijab', eia_a, eia_b)
        dLdt2bb *= lib.direct_sum('ia,jb->ijab', eia_b, eia_b)

        return np.hstack([dLdt1a.ravel(), dLdt1b.ravel(), \
            dLdt2aa.ravel(), dLdt2ab.ravel(), dLdt2bb.ravel()])

    def dot_lambda_corr(self, h1, h2):
        '''
        return a function to compute
        d l_P <P | e^-T H e^T | 0> / d t_Q_symm
        = l_P A_PQ 
        where A_PQ is CC Jacobian = <P | e^-T H e^T | Q> - Ecc \delta_PQ
        '''
        assert h1 is self.base.mf.get_hcore()
        assert h2 is self.base.mf._eri
        occ = self.base.mf.mo_occ > 0
        vir = self.base.mf.mo_occ == 0
        ov_size = self.ov_size()
        mcc = self.base._solver
        t1 = mcc.t1 
        t2 = mcc.t2

        eris = mcc.ao2mo()
        eia_a = lib.direct_sum('i-a->ia', eris.mo_energy[0][occ], eris.mo_energy[0][vir])
        eia_b = lib.direct_sum('i-a->ia', eris.mo_energy[1][occ], eris.mo_energy[1][vir])

        # d Ecc / d tsymm
        t1a, t1b = t1
        t2aa, t2ab, t2bb = t2
        dEdt1a = np.zeros_like(t1a)
        dEdt1b = np.zeros_like(t1b)
        dEdt2aa = np.zeros_like(t2aa)
        dEdt2ab = np.zeros_like(t2ab)
        dEdt2bb = np.zeros_like(t2bb)
        dEdt1a += eris.focka[np.ix_(occ,vir)]
        dEdt1b += eris.fockb[np.ix_(occ,vir)]
        dEdt1a += np.einsum('jb,iajb->ia', t1a, eris.ovov)
        dEdt1a -= np.einsum('jb,ibja->ia', t1a, eris.ovov)
        dEdt1a += np.einsum('jb,iajb->ia', t1b, eris.ovOV)
        dEdt1b += np.einsum('jb,iajb->ia', t1b, eris.ovov)
        dEdt1b -= np.einsum('jb,ibja->ia', t1b, eris.ovov)
        dEdt1b += np.einsum('jb,iajb->ia', t1a, eris.ovOV)
        dEdt2aa +=      np.einsum('iajb->ijab', eris.ovov)
        dEdt2aa -=      np.einsum('ibja->ijab', eris.ovov)
        dEdt2bb +=      np.einsum('iajb->ijab', eris.OVOV)
        dEdt2bb -=      np.einsum('ibja->ijab', eris.OVOV)
        dEdt2ab += np.einsum('iaJB->iJaB', eris.ovOV)

        imds = uccsd_lambda.make_intermediates(mcc, t1, t2, eris)

        def ldMdc(l):
            l1 = l[:2*ov_size].reshape([2, *t1[0].shape])
            l2 = l[2*ov_size:].reshape([3, *t2[0].shape])
            l1n, l2n = uccsd_lambda.update_lambda(mcc, t1, t2, l1, l2, eris, imds)
            dLdt1a = (l1n[0] - l1[0]) * eia_a                               # (<0|+<T|) Hbar-Ecc | ia>
            dLdt1b = (l1n[1] - l1[1]) * eia_b                               # (<0|+<T|) Hbar-Ecc | ia>
            dLdt2aa = (l2n[0] - l2[0]) * lib.direct_sum('ia,jb->ijab', eia_a, eia_a)    # (<0|+<T|) Hbar-Ecc | ijab>
            dLdt2ab = (l2n[1] - l2[1]) * lib.direct_sum('ia,jb->ijab', eia_a, eia_b)    # (<0|+<T|) Hbar-Ecc | ijab>
            dLdt2bb = (l2n[2] - l2[2]) * lib.direct_sum('ia,jb->ijab', eia_b, eia_b)    # (<0|+<T|) Hbar-Ecc | ijab>
            dLdt1a -= dEdt1a
            dLdt1b -= dEdt1b
            dLdt2aa -= dEdt2aa
            dLdt2ab -= dEdt2ab
            dLdt2bb -= dEdt2bb
            return np.hstack([np.ravel([dLdt1a,dLdt1b]), \
                np.ravel([dLdt2aa,dLdt2ab,dLdt2bb])])
        return ldMdc

    def dot_lambda_cross(self, h1, h2):
        '''
        return a function to compute
        l_P d <P| e^-T H e^T | 0> / d U_ai
        '''
        assert h1 is self.base.mf.get_hcore()
        assert h2 is self.base.mf._eri
        h1_mo = self.base.basis.transform_h(h1, 'aa,mm')
        h2_mo = self.base.basis.transform_eri(h2, 'aaaa,mmmm')
        tril_indx = np.tril_indices_from(h1, k=-1)

        def ldMdU(l):
            r1, r2 = self.make_rdm12_corr(l, ao_repre=False)
            # NOTE make_rdm12_corr computes -l_P <P| e^-T Epq Ers e^T | 0> 
            res = - 2 * h1_mo @ r1.T
            res -= np.einsum('tqrs,pqrs->tp', h2_mo, r2)
            res -= np.einsum('qtrs,qprs->tp', h2_mo, r2)
            res -= res.T
            return res[tril_indx] 

        return ldMdU

    def make_rdm12_corr(self, l, ao_repre=True):
        '''
        -l_P <P | e^-T E_pq e^T |0>
        -l_P <P | e^-T E_pq E_rs e^T |0>
        '''
        t1 = self.base.t1
        t2 = self.base.t2
        ov_size = self.ov_size()
        l1 = l[:2*ov_size].reshape([2, *t1[0].shape])
        l2 = l[2*ov_size:].reshape([3, *t2[0].shape])
        def make_rdm1(t1, t2, l1, l2):
            return sum(self.base._solver.make_rdm1(t1,t2,l1,l2))
        def make_rdm2(t1, t2, l1, l2):
            r2aa, r2ab, r2bb = self.base._solver.make_rdm2(t1,t2,l1,l2)
            return r2aa + r2bb + r2ab + r2ab.transpose(2,3,0,1)
        r1 = make_rdm1(t1, t2, l1, l2) - \
             make_rdm1(t1, t2, np.zeros_like(t1), np.zeros_like(t2))
        r2 = make_rdm2(t1, t2, l1, l2) - \
             make_rdm2(t1, t2, np.zeros_like(t1), np.zeros_like(t2))
        if ao_repre:
            return self.base.basis.transform_rdm1(-r1, 'mm,aa'), \
                   self.base.basis.transform_rdm2(-r2, 'mmmm,aaaa')
        else:
            return -r1, -r2