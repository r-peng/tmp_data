'''
TODO
(1) better use CC eris
(2) better way of computing -l_P <P | e^-T E_pq E_rs e^T |0>
(3) better way of computing lP <P | e^-T H e^T | Q>
(4) avoid *e_ai and *e_ai e_bj
'''
from dmet.grad.solver.post_hf import PostHFGradients

import numpy as np
from pyscf import cc, lib, scf
from pyscf.cc import rccsd_lambda

class ARCCSDGradients(PostHFGradients):
    def check_consistency(self):
        super().check_consistency()
        from dmet.solver.rccsd import ARCCSD
        assert type(self.base) is ARCCSD

    def ov_size(self):
        occ = self.base.mf.mo_occ > 0
        vir = self.base.mf.mo_occ == 0
        nocc = sum(occ)
        nvir = sum(vir)
        return nocc * nvir

    def corr_lambda_size(self):
        ov_size = self.ov_size()
        assert ov_size*(ov_size+1) == self.base.t1.size + self.base.t2.size
        return ov_size + ov_size**2

    def dEcc_dt(self, t1, t2, eris):
        # d Ecc / d tsymm
        # see pyscf.cc.ccsd.energy()
        occ = self.base.mf.mo_occ > 0
        vir = self.base.mf.mo_occ == 0
        dEdt1 = np.zeros_like(t1)
        dEdt2 = np.zeros_like(t2)
        dEdt1 += 2 * eris.fock[np.ix_(occ,vir)]
        dEdt1 += 4 * lib.einsum('jb,iabj->ia', t1, eris.ovvo)
        dEdt1 -= 2 * lib.einsum('jb,jabi->ia', t1, eris.ovvo)
        dEdt2 += 2 * eris.ovvo.transpose(0, 3, 1, 2)
        dEdt2 -=     eris.ovvo.transpose(3, 0, 1, 2)
        return dEdt1, dEdt2

    def dE_dc_corr(self, h1pp, h2w, same_h=False):
        '''
        return d Lcc(h1pp, h2w) / d t_Q_symm
        when I say d/d t_ijab_symm, I mean
           1/2 (d/d t_ijab + d/d t_jiba)
        '''

        ov_size = self.mf_lambda_size()
        occ = self.base.mf.mo_occ > 0
        vir = self.base.mf.mo_occ == 0
        mf = self.base.mf

        t1 = self.base.t1
        t2 = self.base.t2

        if not same_h:
            # build a fake mf
            class _RHF(scf.rhf.RHF):
                get_hcore = lambda *args: h1pp
                get_ovlp = lambda *args: np.eye(self.base.norb)
            fmf = _RHF(mf.mol)
            fmf._eri = h2w
            fmf.mo_coeff = mf.mo_coeff
            fmf.mo_occ = mf.mo_occ

            # build a fake CC
            fcc = cc.ccsd.CCSD(fmf)
            fcc.t1 = t1
            fcc.t2 = t2
            eris = fcc.ao2mo()
        else:
            fmf  = mf
            fcc  = self.base._solver
            eris = self.base.eris

        eia = lib.direct_sum('i-a->ia', eris.mo_energy[occ], eris.mo_energy[vir])
        t1n, t2n = fcc.update_amps(t1, t2, eris)
        imds = rccsd_lambda.make_intermediates(fcc, t1, t2, eris)
        l1n, l2n = rccsd_lambda.update_lambda(fcc, t1, t2, t1, t2, eris, imds)

        # <Q | e^-T Hw e^T |0>
        dLdt1_ = 2 * (t1n - t1) * eia
        dLdt2 = 2 * (t2n - t2)

        # tP <P - Q | e^-T Hw e^T |0>
        dLdt1 = dLdt1_ - 2 * lib.einsum('ijab,jb->ia', t2, dLdt1_)
        dLdt1 += lib.einsum('jiab,jb->ia', t2, dLdt1_)

        # (<0| + tP <P|) e^-T Hw e^T | Q>
        dLdt1 += 2 * (l1n - t1) * eia
        dLdt2 += 2 * (l2n - t2)

        dLdt2 -= 0.5 * dLdt2.transpose(1,0,2,3)
        dLdt2 *= lib.direct_sum('ia,jb->ijab', eia, eia)

        return np.hstack([dLdt1.ravel(), dLdt2.ravel()])

    def dot_lambda_corr(self, h1, h2):
        '''
        return a function to compute
        d l_P <P | e^-T H e^T | 0> / d t_Q_symm
        = l_P A_PQ 
        where A_PQ is CC Jacobian = <P | e^-T H e^T | Q> - Ecc \delta_PQ
        '''
        assert h1 is self.base.mf.get_hcore()
        assert h2 is self.base.mf._eri
        occ = self.base.mf.mo_occ > 0
        vir = self.base.mf.mo_occ == 0
        ov_size = self.ov_size()
        mcc = self.base._solver
        t1 = mcc.t1 
        t2 = mcc.t2

        if hasattr(self.base, 'eris'):
            eris = self.base.eris
        else:
            eris = None
        if eris is None:
            eris = mcc.ao2mo()
        eia = lib.direct_sum('i-a->ia', 
            eris.mo_energy[occ], eris.mo_energy[vir])

        # d Ecc / d tsymm
        dEdt1, dEdt2 = self.dEcc_dt(t1, t2, eris)

        if hasattr(self, 'imds'):
            imds = self.imds
        else:
            imds = rccsd_lambda.make_intermediates(mcc, t1, t2, eris)

        def ldMdc(l):
            cput0 = (lib.logger.process_clock(), lib.logger.perf_counter())
            l1 = l[:ov_size].reshape(t1.shape)
            l2 = l[ov_size:].reshape(t2.shape)
            l1n, l2n = rccsd_lambda.update_lambda(mcc, t1, t2, l1, l2, eris, imds)
            dLdt1 = 2 * (l1n - l1) * eia
            dLdt2 = 2 * (l2n - l2) * lib.direct_sum('ia,jb->ijab', eia, eia)
            dLdt2 -= 0.5 * dLdt2.transpose(1,0,2,3)
            dLdt1 -= dEdt1
            dLdt2 -= dEdt2
            self.base.log.timer('ARCCSD ldMdc', *cput0)
            return np.hstack([dLdt1.ravel(), dLdt2.ravel()])
        return ldMdc

    def precond_corr(self):
        ov_size = self.ov_size()
        t1 = self.base.t1
        t2 = self.base.t2
        occ = self.base.mf.mo_occ > 0
        vir = self.base.mf.mo_occ == 0
        mo_energy = self.base.mf.mo_energy
        eia = lib.direct_sum('i-a->ia', mo_energy[occ], mo_energy[vir])

        def Pinv(b):
            b1 = b[:ov_size].reshape(t1.shape)
            b2 = b[ov_size:].reshape(t2.shape)
            Pinvb1 = np.zeros_like(b1)
            Pinvb2 = np.zeros_like(b2)
            Pinvb1 = -b1 / eia / 2
            Pinvb2 = -(2/3 * b2 + 1/3 * b2.transpose(1,0,2,3)) \
            / lib.direct_sum('ia,jb->ijab', eia, eia)
            return np.hstack([Pinvb1.ravel(), Pinvb2.ravel()])
        return Pinv

    def dot_lambda_cross(self, h1, h2):
        '''
        return a function to compute
        l_P d <P| e^-T H e^T | 0> / d U_ai
        '''
        assert h1 is self.base.mf.get_hcore()
        assert h2 is self.base.mf._eri
        h1_mo = self.base.basis.transform_h(h1, 'aa,mm')
        h2_mo = self.base.basis.transform_eri(h2, 'aaaa,mmmm')
        tril_indx = np.tril_indices_from(h1, k=-1)

        def ldMdU(l):
            r1, r2 = self.make_rdm12_corr(l, ao_repre=False)
            # NOTE make_rdm12_corr computes -l_P <P| e^-T Epq Ers e^T | 0> 
            res = - 2 * h1_mo @ r1.T
            res -= lib.einsum('tqrs,pqrs->tp', h2_mo, r2)
            res -= lib.einsum('qtrs,qprs->tp', h2_mo, r2)
            res -= res.T
            return res[tril_indx] 

        return ldMdU

    def make_rdm12_corr(self, l, ao_repre=True):
        '''
        -l_P <P | e^-T E_pq e^T |0>
        -l_P <P | e^-T E_pq E_rs e^T |0>
        '''
        t1 = self.base.t1
        t2 = self.base.t2
        ov_size = self.ov_size()
        l1 = l[:ov_size].reshape(t1.shape)
        l2 = l[ov_size:].reshape(t2.shape)
        make_rdm1 = lambda *args: self.base._solver.make_rdm1(*args)
        make_rdm2 = lambda *args: self.base._solver.make_rdm2(*args)
        r1 = make_rdm1(t1, t2, l1, l2) - \
             make_rdm1(t1, t2, np.zeros_like(t1), np.zeros_like(t2))
        r2 = make_rdm2(t1, t2, l1, l2) - \
             make_rdm2(t1, t2, np.zeros_like(t1), np.zeros_like(t2))
        if ao_repre:
            return self.base.basis.transform_rdm1(-r1, 'mm,aa'), \
                   self.base.basis.transform_rdm2(-r2, 'mmmm,aaaa')
        else:
            return -r1, -r2

    def clear_cache(self):
        self.base.clear_cache()
        if hasattr(self, 'imds'):
            del self.imds

#class RCCSDGradients(PostHFGradients):
#    def check_consistency(self):
#        PostHFGradients.check_consistency(self)
#        from dmet.solver.rccsd import RCCSD
#        assert type(self.base) is RCCSD
#
#    ov_size = ARCCSDGradients.ov_size
#    corr_lambda_size = ARCCSDGradients.corr_lambda_size
#    dEcc_dt = ARCCSDGradients.dEcc_dt
#    dot_lambda_cross = ARCCSDGradients.dot_lambda_cross
#
#    def dE_dc_corr(self, h1, h2, same_h=False):
#        if not same_h:
#            raise NotImplementedError
#        dEdt1, dEdt2 = self.dEcc_dt(self.base.t1, self.base.t2, self.base.eris)
#        return np.hstack([dEdt1.ravel(), dEdt2.ravel()])
#
#    def solve_lambda_corr(self, h1, h2, b, same_h=False):
#        if not same_h:
#            raise NotImplementedError
#        l1, l2 = self.base._solver.solve_lambda(
#            t1=self.base.t1, t2=self.base.t2, 
#            l1=self.base.t1, l2=self.base.t2, eris=self.base.eris)
#        return -np.hstack([l1.ravel(), l2.ravel()])
