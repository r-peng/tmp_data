from dmet.grad.dmet import DMETGradients
from pyscf.lib import einsum, logger, current_memory
import numpy as np

class SingleImpDMETGradients(DMETGradients):
    def grad_solver(self, **kwargs):
        '''
        for each fragment
        compute r1bar and r2bar such that
        dEdmet/dc * dc/dR = r1bar * dh1/dR + r2bar * dh2/dR
        where c is the solver solution
        '''
        f = self.base.fragments[0]
        f.r1bar, f.r2bar = f.solvergrad.kernel(\
            f.h1, f.h2, f.h1, f.h2, **kwargs)
        f.solvergrad.clear_cache()
        f.r1bar = (f.r1bar + f.r1bar.T) / 2
        f.r2bar = (f.r2bar + f.r2bar.transpose(1,0,2,3)) / 2
        f.r2bar = (f.r2bar + f.r2bar.transpose(0,1,3,2)) / 2

    def grad_lodm(self):
        '''
        DMET gradient due to LO DM change
        Fkl \defeq dEdmet/dlodm 
        preD = dEdmet / dC_AO_EO
        eq numbers are ones in Post HF notes
        '''
        # decrease some depth
        mf = self.base.mf
        nao = mf.mol.nao
        f = self.base.fragments[0]
        get_veff = self.base.get_veff
        aofock = self.base.aofock
        aodm = self.base.aodm
        aohcore = self.base.aohcore

        neo = f.basis.Cao2eo.shape[1]

        r1sum = f.r1bar + f.r1
        f.vlocbar = get_veff(f.h2, r1sum)
        # eq 37 1st of 1st
        Fae = f.basis.transform_h(aofock, 'aa,ae')
        # eq 37 3rd of 1st
        Fae -= get_veff(f.eri_aeee, f.dm_proj)
        f.preD = einsum('jt,bj->bt', r1sum, Fae)

        # eq 37 4th of 1st
        vtemp = get_veff(f.eri_aeee, r1sum)
        f.preD -= einsum('jt,bj->bt', f.dm_proj, vtemp)

        # eq 37 2nd of 1st
        dmtemp = f.basis.transform_dm(aodm, 'aa,ae')
        dmtemp = einsum('ui,uv->vi', dmtemp, f.basis.ovlp)
        f.preD -= einsum('jt,bj->bt', f.vlocbar, dmtemp)
        
        # end of eq 37 1st
        f.preD *= 2

        # eq 37 2nd
        r2sum = (f.r2 + f.r2.transpose(1,0,2,3)) / 2
        r2sum = (r2sum + r2sum.transpose(0,1,3,2)) / 2
        r2sum += f.r2bar
        #f.preD += 2 * einsum('tjkl,bjkl->bt', r2sum, f.eri_aeee)
        f.preD += 2 * f.eri_aeee.reshape(nao,-1) @ r2sum.reshape(neo,-1).T

        # eq 37 3rd i.e. eq 38
        self.P = f.basis.Ceo2ao.T @ f.basis.Cao2eo.T
        Fcore = aohcore + f.vcore
        temp = Fcore.T @ f.basis.Cao2eo
        temp = aodm @ self.P @ temp
        f.preD -= 2 * f.basis.ovlp.T @ temp
        temp = f.basis.ovlp @ f.basis.Cao2eo
        temp = self.P.T @ aodm.T @ temp
        f.preD -= 2 * Fcore @ temp

        # dE / dC_LO_EO = (dE / dC_AO_EO) @ C_AO_LO
        preD = f.basis.transform_h(f.preD, 'ae,le')
        f.Fkl = f.basis.svd.gradient(
            preD[f.env,f.nimp:], contract='pre', mask=f.basis.bath_mask)[0]

    def grad_aodm(self):
        '''
        DMET gradient due to AO DM change
        Fbar \defeq dEdmet/daodm 
        eq numbers are ones in Post HF notes
        '''
        from pyscf.scf import cphf

        # decrease some depth
        mf = self.base.mf
        f = self.base.fragments[0]
        aohcore = self.base.aohcore

        # eq 40 1st term
        r1sum = f.r1bar + f.r1
        self.aodmbar = f.basis.transform_dm(r1sum, 'ee,aa')
        aoFbar = mf.get_veff(dm=self.aodmbar)

        # eq 40 2nd term
        aoFbar -= f.basis.transform_h(f.vlocbar, 'ee,aa')

        # eq 40 3rd & 4th
        aoFbar += (aohcore + f.vcore)
        aoFbar -= self.P @ (aohcore + f.vcore) @ self.P.T

        # eq 39
        aoFbar += einsum('kl,ku,lv->uv', f.Fkl, 
                f.basis.Clo2ao[f.env], f.basis.Clo2ao[f.imp])

        aoFbar = (aoFbar + aoFbar.T) / 2

        # CP-HF
        self.aoFbar = aoFbar
        self.moFbar = mf.mo_coeff.T @ aoFbar @ mf.mo_coeff
        self.moFbar *= 2 # *2 because 2-electron occ each orb for restricted

        if hasattr(self.base, 'dft'):
            mf = self.base.dft
        occ = mf.mo_occ > 0
        vir = ~occ
        vresp = mf.gen_response(singlet=None, hermi=1)
        if self.conv_tol_cphf is None or self.conv_tol_cphf > 0:
            Fvo = self.moFbar[np.ix_(vir,occ)]
            def fvind(dm_mo_VO):
                dm = mf.mo_coeff[:, vir] @ dm_mo_VO @ mf.mo_coeff.T[occ]
                dm = dm + dm.T
                v = vresp(dm)
                v_mo = mf.mo_coeff.T[vir] @ v @ mf.mo_coeff[:,occ]
                return v_mo * 2
            if self.conv_tol_cphf is not None:
                self.Z = cphf.solve(fvind, mf.mo_energy, mf.mo_occ, 2*Fvo, 
                        tol=self.conv_tol_cphf)[0]
            else:
                self.Z = cphf.solve(fvind, mf.mo_energy, mf.mo_occ, 2*Fvo)[0]
        else:
            self.Z = np.zeros((sum(vir), sum(occ)))

    def grad_ovlp(self):
        '''
        DMET gradient due to AO overlap change
        Ebar \defeq dEdmet/dovlp
        eq numbers are ones in Post HF notes
        '''
        DMETGradients.grad_ovlp(self)
        # eq 42 2nd
        f = self.base.fragments[0]
        temp = - 2 * f.basis.transform_h(self.base.aohcore+f.vcore, 'aa,ea')
        temp = temp @ self.P.T @ self.base.aodm.T
        self.Ebar += temp.T @ f.basis.Cao2eo.T

    def contract_ao(self, atmlst=None, mmgrad=False):
        '''
        eq numbers > 100 are ones of DMET Notes
        '''
        # sanity check
        if mmgrad:
            ''' this is for qm/mm '''
            assert hasattr(self.mfgrad, 'grad_nuc_mm')
            assert hasattr(self.base.mf, 'mm_mol')
        # decrease some depth
        mf = self.base.mf
        mfgrad = self.mfgrad
        fragments = self.base.fragments
        f = fragments[0]
        nao = mf.mol.nao
        aodm = self.base.aodm
        aodmbar = self.aodmbar
        moFbar = self.moFbar
        r1sum = f.r1bar + f.r1

        # AO derivatives
        ovlpR = mfgrad.get_ovlp()
        # NOTE f.eri_aeee will be replaced by its deriv
        max_memory = mf.mol.max_memory - current_memory()[0]
        if mf._eri is not None and 3*nao**4*8/1e6 < 0.9*max_memory:
            self.base.log.note("ERI deriv transformation using incore")
            mf._eri = None  # to save some space
            aoeriR = -mf.mol.intor('int2e_ip1')
            for ifrag, f in enumerate(fragments):
                cput0 = (logger.process_clock(), logger.perf_counter())
                neo = f.basis.Cao2eo.shape[1]
                f.eri_aeee = np.zeros((3,nao,neo,neo,neo))
                for k in range(3):
                    f.eri_aeee[k] = \
                        f.basis.transform_eri(aoeriR[k], 'aaaa,aeee',
                                norbs=nao, contract_order=[3,0,1,2])
                self.base.log.timer(
                    f'ERI deriv transformation of fragment {ifrag}', *cput0)
            # keeping this aoeriR and using self.get_veff with explcit ERI
            # will be faster than mfgrad.get_veff
            #del aoeriR
        else: 
            self.base.log.note("ERI deriv transformation using outcore")
            from pyscf.ao2mo import general
            for ifrag, f in enumerate(fragments):
                cput0 = (logger.process_clock(), logger.perf_counter())
                C = f.basis.Cao2eo
                neo = C.shape[1]
                f.eri_aeee = -general(\
                    mf.mol, (np.eye(nao),C,C,C), intor='int2e_ip1', 
                    comp=3, aosym='s2kl', compact=False)
                f.eri_aeee = f.eri_aeee.reshape(3,nao*neo,neo,neo)
                f.eri_aeee = f.eri_aeee.reshape(3,nao,neo,neo,neo)
                self.base.log.timer(
                    f'ERI deriv transformation of fragment {ifrag}', *cput0)

        try:
            cput0 = (logger.process_clock(), logger.perf_counter())
            vhfR = self.get_veff(aoeriR, aodm)    # V_u^Rvwx aodm_wx
            self.base.log.timer('vhfR', *cput0)
        except:
            vhfR = mfgrad.get_veff()    # V_u^Rvwx aodm_wx
        gen_hcore = mfgrad.hcore_generator()

        # common useful
        aoslices = mf.mol.aoslice_by_atom()
        occ = mf.mo_occ > 0
        vir = ~occ
        Zuj = mf.mo_coeff[:,vir] @ self.Z
        Zuv  = Zuj @ mf.mo_coeff[:,occ].T
        Zsymm = (Zuv + Zuv.T) / 2                    
        if atmlst is None:
            atmlst = range(mf.mol.natm)
        de = np.zeros((len(atmlst),3))

        # eq 145 1st, eq 156 1st, Ehf(dm_core)
        if not hasattr(self.base, 'dft'):
            r1temp = Zuv + aodmbar
            r1temp1 = (r1temp + r1temp.T) / 2   # vhfR only has bra, transpose for ket 
            r1temp2 = r1temp + f.dm_core       # to be contracted with h1R
            try:
                cput0 = (logger.process_clock(), logger.perf_counter())
                vhftempR = self.get_veff(aoeriR, r1temp1)
                self.base.log.timer('vhftempR', *cput0)
                cput0 = (logger.process_clock(), logger.perf_counter())
                vhfcoreR = self.get_veff(aoeriR, f.dm_core)
                self.base.log.timer('vhfcoreR', *cput0)
            except:
                vhftempR = mfgrad.get_veff(dm=r1temp1)
                vhfcoreR = mfgrad.get_veff(dm=f.dm_core)

            if mmgrad:
                self.de_mm = mfgrad.contract_hcore_mm(r1temp2)
            for k, ia in enumerate(atmlst):
                p0, p1 = aoslices[ia,2:]
                h1ao = gen_hcore(ia)
                de[k] += einsum('xij,ij->x', h1ao, r1temp2)
                # *2 for adding r1_uv V_uvRwx aodm_wx
                de[k] += einsum('xij,ij->x', vhfR[:,p0:p1], r1temp1[p0:p1]) * 2
                # *2 for adding aodm_uv V_uvRwx r1_wx 
                de[k] += einsum('xij,ij->x', vhftempR[:,p0:p1], aodm[p0:p1]) * 2
                # EHF(dm_core)
                de[k] += einsum('xij,ij->x', vhfcoreR[:,p0:p1], f.dm_core[p0:p1]) * 2
            del r1temp
            del r1temp1
            del r1temp2
        else:
            from dmet.utils.grad.rks import get_veff_ket
            # if dft used as mean-field
            # fock in BR of eq 145 is not the same as fock in eq 156
            r1temp2 = Zuv + aodmbar + f.dm_core          # hcore no need for transpose
            aodmbar = (aodmbar + aodmbar.T) / 2          # in case aodmbar not symmetrized
            # TODO reduce duplicated vj (and potentially vk) in veffR and vhfR
            veffR = self.dftgrad.get_veff(dm=self.base.aodm) 
            vefftempR = get_veff_ket(self.dftgrad, dm=Zsymm)
            try:
                cput0 = (logger.process_clock(), logger.perf_counter())
                vhftempR = self.get_veff(aoeriR, aodmbar)
                self.base.log.timer('vhftempR', *cput0)
                cput0 = (logger.process_clock(), logger.perf_counter())
                vhfcoreR = self.get_veff(aoeriR, f.dm_core)
                self.base.log.timer('vhfcoreR', *cput0)
            except:
                vhftempR = mfgrad.get_veff(dm=aodmbar)
                vhfcoreR = mfgrad.get_veff(dm=f.dm_core)

            if mmgrad:
                self.de_mm = mfgrad.contract_hcore_mm(r1temp2)
            for k, ia in enumerate(atmlst):
                p0, p1 = aoslices[ia,2:]
                h1ao = gen_hcore(ia)
                # hcore in eq 145, 156
                de[k] += einsum('xij,ij->x', h1ao, r1temp2)
                # *2 for ket; eq 145 cphf
                de[k] += einsum('xij,ij->x', veffR[:,p0:p1], Zsymm[p0:p1]) * 2
                de[k] += einsum('xij,ij->x', vefftempR[:,p0:p1], aodm[p0:p1]) * 2
                # *2 for ket; eq 156
                de[k] += einsum('xij,ij->x', vhfR[:,p0:p1], aodmbar[p0:p1]) * 2
                de[k] += einsum('xij,ij->x', vhftempR[:,p0:p1], aodm[p0:p1]) * 2
                # EHF(dm_core)
                de[k] += einsum('xij,ij->x', vhfcoreR[:,p0:p1], f.dm_core[p0:p1]) * 2
            del r1temp2
            del veffR
            del vefftempR
        del vhftempR
        del vhfcoreR
        try:
            del aoeriR
        except:
            pass

        # eq 145 1st in cphf
        if hasattr(self.base, 'dft'):
            mf = self.base.dft
        vresp = mf.gen_response(singlet=None, hermi=1)
        Etemp  = einsum('uj,vj,j->uv', Zuj, mf.mo_coeff[:,occ], -mf.mo_energy[occ])
        Etemp -= 0.5 * aodm @ vresp(Zsymm) @ aodm
        # eq 145 2nd
        Etemp -= mf.mo_coeff[:,occ] @ moFbar[np.ix_(occ,occ)] @ mf.mo_coeff[:,occ].T
        # eq 152-154
        Etemp += self.Ebar
        Etemp += Etemp.T            # ovlpR only has bra, transpose for ket 
        for k, ia in enumerate(atmlst):
            p0, p1 = aoslices[ia,2:]
            de[k] += einsum('xij,ij->x', ovlpR[:,p0:p1], Etemp[p0:p1])
        del Etemp

        def rVr(rx, V, ry, Cui):
            '''
            rx_ji V_u^Rjkl ry_kl C_ui
            '''
            veff = self.get_veff(V, ry)
            temp = einsum('xuj,ji->xui', veff, rx)
            return einsum('xui,ui->xu', temp, Cui)
        gtemp = 0
        Cao2eo = f.basis.Cao2eo
        neo = Cao2eo.shape[1]
        eriR = f.eri_aeee
        # eq 156 2nd
        gtemp -= 2 * rVr(r1sum, eriR, f.dm_proj, Cao2eo)
        # eq 156 3rd
        gtemp -= 2 * rVr(f.dm_proj, eriR, r1sum, Cao2eo)
        # eq 157
        r2sum = (f.r2 + f.r2.transpose(1,0,2,3)) / 2
        r2sum = (r2sum + r2sum.transpose(0,1,3,2)) / 2
        r2sum += f.r2bar
        #temp = einsum('ijkl,xujkl->xui', r2sum, eriR)
        temp = eriR.reshape(3,nao,-1) @ r2sum.reshape(neo,-1).T
        gtemp += 2 * einsum('xui,ui->xu', temp, Cao2eo)
        for k, ia in enumerate(atmlst):
            p0, p1 = aoslices[ia,2:]
            de[k] += einsum('xu->x', gtemp[:,p0:p1])
        del gtemp

        self.de = de 
