from dmet.grad.dmet import DMETGradients

from pyscf.lib import einsum, dot, logger, unpack_tril

from scipy import linalg as la
import numpy as np


class GDF_DMETGradients(DMETGradients):
    def __init__(self, base, **kwargs):
        DMETGradients.__init__(self, base, **kwargs)

        from dmet.df.gdf import GDF_DMET
        assert isinstance(self.base, GDF_DMET)

    def contract_ao(self, atmlst=None):
        # decrease some depth
        mf = self.base.mf
        mfgrad = self.mfgrad
        fragments = self.base.fragments
        nao = mf.mol.nao
        aodm = self.base.aodm
        new_aodm = self.base.new_aodm
        aodmbar = self.aodmbar
        moFbar = self.moFbar

        # AO derivatives
        ovlpR = mfgrad.get_ovlp()
        # TODO DFT MF
        # NOTE f.eri_aeee will be replaced by its deriv
        self.base.log.note("ERI deriv transformation using density fitting")
        from pyscf import df
        auxmol = mf.with_df.auxmol
        if self.auxbasis_response:
            raise NotImplementedError("Density fitting auxbasis response")
        else:
            self.base.log.warn("Density fitting grad ignoring auxbasis response")
        if hasattr(mf.with_df, 'low') and mf.with_df.low is not None:
            low = mf.with_df.low
        elif hasattr(mf.with_df, '_low') and mf.with_df._low is not None:
            low = mf.with_df._low
        else:
            j2c = auxmol.intor('int2c2e')
            low = la.cholesky(j2c, lower=True)
        # TODO do this chunk by chunk as it was done in GDF.build()
        # if memory is not enough
        naoaux = auxmol.nao
        if isinstance(mf.with_df, df.GDF):
            int3c = df.incore.aux_e2(
                mf.mol, auxmol, intor='int3c2e_ip1', aosym='s1', comp=3)
        else:
            raise NotImplementedError("only molecular GDF supported for grad")
        uRvL = -la.solve(low, int3c.reshape(-1,naoaux).T).T.\
                                            reshape(3,nao,nao,naoaux)
        # NOTE aoeriR is not really needed, but the current pyscf mfgrad.get_veff
        # with df only works for SCF dm, so to avoid calling mfgrad.get_veff in 
        # below, I'll keep this aoeriR and use self.get_veff with explcit ERI
        cput0 = (logger.process_clock(), logger.perf_counter())
        aoeriR = 0 
        i0 = 0
        for f in fragments:
            f.eri_aeee = 0
        for j3c in mf.with_df.loop():
            i1 = i0 + len(j3c)
            #aoeriR += einsum('xuvL,Lwz->xuvwz', uRvL[i0:i1], unpack_tril(j3c))
            aoeriR += unpack_tril(dot(uRvL[...,i0:i1].reshape(-1,naoaux), j3c)).\
                                         reshape(3,nao,nao,nao,nao)
            for ifrag, f in enumerate(fragments):
                Lij = f.Lij[i0:i1]
                uRjL = f.basis.Cao2eo.T @ uRvL[...,i0:i1] # TODO use lib.dot instead?
                f.eri_aeee += einsum('xujL,Lkl->xujkl', uRjL, Lij)
            i0 = i1
        self.base.log.timer(
            f'ERI deriv transformation total', *cput0)

        try:
            cput0 = (logger.process_clock(), logger.perf_counter())
            vhfR = self.get_veff(aoeriR, aodm)    # V_u^Rvwx aodm_wx
            self.base.log.timer('vhfR', *cput0)
            cput0 = (logger.process_clock(), logger.perf_counter())
            new_vhfR = self.get_veff(aoeriR, new_aodm)
            self.base.log.timer('new_vhfR', *cput0)
        except:
            vhfR = mfgrad.get_veff()    # V_u^Rvwx aodm_wx
            new_vhfR = mfgrad.get_veff(dm=new_aodm)
        gen_hcore = mfgrad.hcore_generator()

        # common useful
        aoslices = mf.mol.aoslice_by_atom()
        occ = mf.mo_occ > 0
        vir = ~occ
        Zuj = mf.mo_coeff[:,vir] @ self.Z
        Zuv  = Zuj @ mf.mo_coeff[:,occ].T
        if atmlst is None:
            atmlst = range(mf.mol.natm)
        de = np.zeros((len(atmlst),3))

        # eq 145 1st, eq 156 1st, eq 158 1st
        r1temp = Zuv + aodmbar
        r1temp1 = (r1temp + r1temp.T) / 2     # vhfR only has bra, transpose for ket 
        r1temp2 = r1temp + self.base.new_aodm # hcore no need for transpose
        try:
            cput0 = (logger.process_clock(), logger.perf_counter())
            vhftempR = self.get_veff(aoeriR, r1temp1)
            self.base.log.timer('vhftempR', *cput0)
        except:
            vhftempR = mfgrad.get_veff(dm=r1temp1)

        for k, ia in enumerate(atmlst):
            p0, p1 = aoslices[ia,2:]
            h1ao = gen_hcore(ia)
            de[k] += einsum('xij,ij->x', h1ao, r1temp2)
            # *2 for adding r1_uv V_uvRwx aodm_wx
            de[k] += einsum('xij,ij->x', vhfR[:,p0:p1], r1temp1[p0:p1]) * 2
            # *2 for adding aodm_uv V_uvRwx r1_wx 
            de[k] += einsum('xij,ij->x', vhftempR[:,p0:p1], aodm[p0:p1]) * 2
            # *2 for adding aodm'_uv V_uvRwx aodm'_wx
            # 1/2 in eq 158 
            # *2 for adding aodm'_uv V_uvwRx aodm'_wx + aodm'_uv V_uvwxR aodm'_wx
            de[k] += einsum('xij,ij->x', new_vhfR[:,p0:p1], new_aodm[p0:p1]) * 2
        del r1temp
        del r1temp1
        del r1temp2

        # eq 145 1st 
        Etemp  = einsum('uj,vj,j->uv', Zuj, mf.mo_coeff[:,occ], -mf.mo_energy[occ])
        Etemp -= 0.5 * aodm @ mf.get_veff(dm=(Zuv+Zuv.T)/2) @ aodm
        # eq 145 2nd
        Etemp -= mf.mo_coeff[:,occ] @ moFbar[np.ix_(occ,occ)] @ mf.mo_coeff[:,occ].T
        # eq 152-154
        Etemp += self.Ebar
        Etemp += Etemp.T            # ovlpR only has bra, transpose for ket 
        for k, ia in enumerate(atmlst):
            p0, p1 = aoslices[ia,2:]
            de[k] += einsum('xij,ij->x', ovlpR[:,p0:p1], Etemp[p0:p1])
        del Etemp

        def rVr(rx, V, ry, Cui):
            '''
            rx_ji V_u^Rjkl ry_kl C_ui
            '''
            veff = self.get_veff(V, ry)
            temp = einsum('xuj,ji->xui', veff, rx)
            return einsum('xui,ui->xu', temp, Cui)
        gtemp = 0
        for f in fragments:
            Cao2eo = f.basis.Cao2eo
            neo = Cao2eo.shape[1]
            eriR = f.eri_aeee
            # eq 156 2nd
            gtemp -= 2 * rVr(f.r1bar, eriR, f.dm_proj, Cao2eo)
            # eq 156 3rd
            gtemp -= 2 * rVr(f.dm_proj, eriR, f.r1bar, Cao2eo)
            # eq 157
            #temp = einsum('ijkl,xujkl->xui', f.r2sum, eriR)
            temp = eriR.reshape(3,nao,-1) @ f.r2sum.reshape(neo,-1).T
            gtemp += 2 * einsum('xui,ui->xu', temp, Cao2eo)
            # eq 158 2nd
            gtemp -= rVr(f.r1w, eriR, f.r1, Cao2eo)
            # eq 158 3rd
            gtemp -= rVr(f.r1, eriR, f.r1w, Cao2eo)
        for k, ia in enumerate(atmlst):
            p0, p1 = aoslices[ia,2:]
            de[k] += einsum('xu->x', gtemp[:,p0:p1])
        del gtemp

        self.de = de 
